#!/usr/bin/env python3
"""Build and run isolated dedicated-server borderless checks and a real restart.
Supply --accept-eula only after reading https://aka.ms/MinecraftEULA.
"""
import argparse, importlib.util, json, os, pathlib, re, shutil, subprocess, zipfile
ROOT=pathlib.Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--java-home',required=True)
parser.add_argument('--deps',default=str(ROOT/'.build-deps'))
parser.add_argument('--accept-eula',action='store_true')
args=parser.parse_args()
if not args.accept_eula:parser.error('Read https://aka.ms/MinecraftEULA and supply --accept-eula to launch the isolated local test server')
java_home=pathlib.Path(args.java_home).resolve();deps=pathlib.Path(args.deps).resolve()
args.java_home=str(java_home);args.deps=str(deps)
spec=importlib.util.spec_from_file_location('direct',ROOT/'build-direct.py');direct=importlib.util.module_from_spec(spec);spec.loader.exec_module(direct);direct.build(args)
cp=os.pathsep.join(str(p) for folder in [deps/'server',deps/'loader',deps/'api'] for p in folder.rglob('*.jar'))+os.pathsep+str(deps/'fabric-loader.jar')
ext='.exe' if os.name=='nt' else ''
classes=ROOT/'build/server-qa';classes.mkdir(parents=True,exist_ok=True)
subprocess.run([str(java_home/'bin'/('javac'+ext)),'-proc:none','--release','25','-cp',cp+os.pathsep+str(ROOT/'build/classes'),'-d',str(classes),*[str(p) for p in (ROOT/'src/integration/java').rglob('*.java')]],check=True)
run=ROOT/'build/borderless-checks';mods=run/'mods';mods.mkdir(parents=True,exist_ok=True)
for old in mods.glob('*.jar'):old.unlink()
shutil.copy2(deps/'fabric-api.jar',mods);shutil.copy2(ROOT/'build/libs/mubbles-borderless-0.1.0.jar',mods)
with zipfile.ZipFile(mods/'borderless-checks.jar','w',zipfile.ZIP_DEFLATED) as z:
    for p in classes.rglob('*.class'):z.write(p,str(p.relative_to(classes)))
    z.writestr('fabric.mod.json',json.dumps({'schemaVersion':1,'id':'borderless_checks','version':'1.0','environment':'server','entrypoints':{'main':['dev.mubble.borderless.test.BorderlessChecks']},'depends':{'mubble_borderless':'*'}}))
(run/'eula.txt').write_text('eula=true\n')
(run/'server.properties').write_text('server-ip=127.0.0.1\nserver-port=25589\nonline-mode=false\nwhite-list=false\nlevel-type=minecraft:normal\ngenerate-structures=false\nspawn-protection=0\nview-distance=2\nsimulation-distance=2\nmax-players=1\npause-when-empty-seconds=-1\nlevel-name=test-world\n')
for restart in [False,True]:
    log=ROOT/('restart-validation.log' if restart else 'server-validation.log')
    with log.open('w') as out:
        result=subprocess.run([str(java_home/'bin'/('java'+ext)),'-Xmx3072M','-Dborderless.test.restart='+str(restart).lower(),'-Dfabric.gameJarPath='+str(deps/'server/26.3/server-26.3.jar'),'-cp',cp,'net.fabricmc.loader.impl.launch.knot.KnotServer','nogui'],cwd=run,stdout=out,stderr=subprocess.STDOUT,timeout=180)
    text=log.read_text();marker='BORDERLESS RESTART CHECKS PASSED' if restart else 'BORDERLESS SERVER CHECKS PASSED'
    if result.returncode or 'BORDERLESS CHECKS FAILED' in text or marker not in text:raise SystemExit('Integration failed exit='+str(result.returncode)+'; inspect '+str(log))
    count=re.search(marker+r' (\d+)',text).group(1)
    print(count+(' restart' if restart else ' dedicated-server')+' checks passed')
