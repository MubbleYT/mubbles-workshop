# Validation for 0.1.0

Minecraft Java 26.3, Fabric Loader 0.19.5, Java 25.0.2. Test fixtures use Fabric API 0.161.0+26.3; the playable JAR uses no Fabric API entrypoints.

- 103 dedicated-server checks passed. Real terrain chunks generated beyond ±30 million and at approximately ±32 million; placement, reads, heightmaps, light and brightness checked. Border position, chunk and box acceptance, collision, clamp, warnings and damage checked in all three dimensions. Entity snapping and serialized reload retain far coordinates; expanded dimension codec encoding succeeds.
- 80 checks passed after a real server restart, including blocks at Y −2032 and 2031, both far coordinate directions, high/low far-coordinate blocks and lighting.
- 44 graphical-client checks passed on Mesa llvmpipe OpenGL 4.6. Four phases tested actual placement and mining packets, server acknowledgement, client lighting, synchronized chunks, player tick and teleport positions. Locations: X +30,000,032 at Y100; X −30,000,032 at Y1024; Z +32,000,032 at Y2030/2031; Z −32,000,032 at Y−2032/−2031.

An initial placement fixture attempted to place a block inside the player's body; the fixture was corrected to stand beside it. Earlier graphical starts encountered local X keyboard/native runtime problems. No production changes were needed for these fixture/environment issues.

No claim of infinite height, working packed coordinates beyond 33.55 million, shader/Sodium/Voxy compatibility, performance benchmarks or every block/entity mechanic. Expanded dimension height is 4064 blocks. Existing terrain noise settings remain unchanged; newly configured flat worlds may use the expanded minimum as their floor.

The test mods are separate and excluded from the playable JAR. Validation logs are included.
