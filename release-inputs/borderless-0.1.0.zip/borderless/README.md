# Mubble's Borderless 0.1.0

Fabric mod for Minecraft Java 26.3, Java 25 and Fabric Loader 0.19.5+. Install the JAR in `mods` on the server and every client. Fabric API is used only by the separate test fixtures; the playable mod does not require it.

## Behavior

- Disables the visible world border, border collision, border damage and warning tint/distances in every dimension. Existing `/worldborder` settings are retained in saves but do not restrict gameplay while this mod is installed.
- Removes the vanilla 30-million-block player tick, network movement, entity snap/load and world bounds restrictions, along with the corresponding heightmap, local brightness and `/forceload` restrictions. `/tp`, building, mining and chunk generation work outside the former border within the underlying engine's supported coordinate format.
- Expands actual dimension/chunk build storage to **Y −2032 through 2031 inclusive** (4,064 blocks tall) in every dimension. Existing terrain generators retain their configured noise heights; this adds room for construction, not deeper natural caves or taller natural mountains. Nether portal logical heights retain their original behavior.
- Does not add a replacement horizontal border. Invalid network numbers, ordinary reach checks, vertical network safeguards, maximum force-loaded chunk counts and world-height storage bounds remain validated.

## Engine limits

This is **not infinite-coordinate or infinite-height Minecraft**. Packed block coordinates still support X/Z −33,554,432 through 33,554,431 and Y −2048 through 2047. The supported dimension codec/build range is slightly smaller vertically. Traveling beyond the packed horizontal range can break lighting, position-dependent systems and world data. There is no automatic barrier at that threshold. The tested horizontal locations are just beyond ±30 million and approximately ±32 million; do not interpret them as proof that every mod or distant-coordinate system works.

Expanded chunks can use more memory and processing time. Test shader, Sodium, Voxy and other world-generation/rendering combinations separately; compatibility with those combinations has not been claimed. Back up an existing world before adding or removing a dimension-height mod. Keep the mod installed to retain blocks outside the vanilla height range: removing it can cause those sections to be ignored or lost on later saves.

## Build

`python3 build-direct.py --java-home /path/to/jdk25 --deps /path/to/deps`

The builder obtains the official unobfuscated 26.3 binaries and Fabric dependencies, verifies published download checksums where available, and produces a deterministic JAR. Minecraft binaries are not redistributed in this source or the mod.

`python3 run-integration.py --java-home /path/to/jdk25 --deps /path/to/deps --accept-eula`

Read the Minecraft EULA before launching a test server. Integration checks run in their own world and never in a user's world. Test fixture mods are excluded from the playable JAR.

MIT license. Created with ChatGPT for Mubble.
