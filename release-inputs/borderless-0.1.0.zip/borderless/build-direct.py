#!/usr/bin/env python3
"""Build without Gradle/Loom: 26.3 ships unobfuscated names, so no remapping is needed.

Usage: python build-direct.py --java-home /path/to/jdk25 [--deps /path/to/deps]
Downloads Mojang/Fabric dependencies when the dependency directory is empty.
No Minecraft binaries are included in the source archive or playable mod.
"""
import argparse, concurrent.futures, hashlib, json, os, pathlib, subprocess, urllib.request, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
VERSION = '0.1.0'
MC = '26.3'
LOADER = '0.19.5'
API = '0.161.0+26.3'

def download(url, target, sha1=None):
    target = pathlib.Path(target)
    if not target.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        print('Downloading', target.name, flush=True)
        with urllib.request.urlopen(url, timeout=120) as response:
            data = response.read()
        if sha1 and hashlib.sha1(data).hexdigest() != sha1:
            raise ValueError('Checksum mismatch: ' + target.name)
        target.write_bytes(data)
    if sha1 and hashlib.sha1(target.read_bytes()).hexdigest() != sha1:
        raise ValueError('Checksum mismatch: ' + target.name)
    return target

def setup(deps):
    meta = json.loads(download('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json', deps/'manifest.json').read_text())
    entry = next(v for v in meta['versions'] if v['id'] == MC)
    version = json.loads(download(entry['url'], deps/'version.json', entry['sha1']).read_text())
    client = version['downloads']['client']
    download(client['url'], deps/'client.jar', client['sha1'])
    server = version['downloads']['server']
    jar = download(server['url'], deps/'server.jar', server['sha1'])
    with zipfile.ZipFile(jar) as archive:
        for name in archive.namelist():
            if name.startswith(('META-INF/versions/', 'META-INF/libraries/')) and name.endswith('.jar'):
                target = deps/'server'/name.split('/', 2)[2]
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
    maven = 'https://maven.fabricmc.net/'
    loader_path = f'net/fabricmc/fabric-loader/{LOADER}/fabric-loader-{LOADER}.jar'
    api_path = f'net/fabricmc/fabric-api/fabric-api/{API}/fabric-api-{API}.jar'
    for path, name in [(loader_path, 'fabric-loader.jar'), (api_path, 'fabric-api.jar')]:
        sha = urllib.request.urlopen(maven+path+'.sha1', timeout=60).read().decode().strip().split()[0]
        download(maven+path, deps/name, sha)
    with zipfile.ZipFile(deps/'fabric-api.jar') as archive:
        for name in archive.namelist():
            if name.endswith('.jar'):
                target = deps/'api'/pathlib.Path(name).name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
    loader_meta = json.loads(download(f'https://meta.fabricmc.net/v2/versions/loader/{MC}/{LOADER}', deps/'loader-meta.json').read_text())
    def library(lib):
        group, artifact, version = lib['name'].split(':')
        filename = f'{artifact}-{version}.jar'
        url = lib['url'] + group.replace('.', '/') + '/' + artifact + '/' + version + '/' + filename
        download(url, deps/'loader'/filename, lib.get('sha1'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(library, loader_meta['launcherMeta']['libraries']['common']))

def build(args):
    deps = pathlib.Path(args.deps).resolve()
    if not (deps/'server'/MC/f'server-{MC}.jar').exists():
        setup(deps)
    java_home = pathlib.Path(args.java_home)
    ext = '.exe' if os.name == 'nt' else ''
    javac = str(java_home/'bin'/('javac'+ext))
    java = str(java_home/'bin'/('java'+ext))
    classpath = os.pathsep.join(str(p) for p in deps.rglob('*.jar') if p.name != 'server.jar')
    classes = ROOT/'build'/'classes'; classes.mkdir(parents=True, exist_ok=True)
    sources = [str(p) for p in (ROOT/'src/main/java').rglob('*.java')]
    subprocess.run([javac, '-proc:none', '--release', '25', '-cp', classpath, '-d', str(classes), *sources], check=True)
    output = ROOT/'build'/'libs'/f'mubbles-borderless-{VERSION}.jar'; output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix('.jar.tmp')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(classes.rglob('*.class')):
            entry=zipfile.ZipInfo(str(p.relative_to(classes)),(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(entry,p.read_bytes())
        resources = ROOT/'src/main/resources'
        for p in sorted(resources.rglob('*')):
            if p.is_file():
                entry=zipfile.ZipInfo(str(p.relative_to(resources)),(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
                archive.writestr(entry,p.read_bytes().replace(b'${version}', VERSION.encode()) if p.suffix == '.json' else p.read_bytes())
        entry=zipfile.ZipInfo('LICENSE',(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(entry,(ROOT/'LICENSE').read_bytes())
    temporary.replace(output)
    print('Built', output)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--java-home', default=os.environ.get('JAVA_HOME'))
    parser.add_argument('--deps', default=str(ROOT/'.build-deps'))
    args = parser.parse_args()
    if not args.java_home: parser.error('provide --java-home pointing to a Java 25 JDK')
    build(args)
