package dev.mubble.borderless.test;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.storage.*;
import net.minecraft.nbt.*;
import java.lang.reflect.Method;
public class BorderlessChecks implements ModInitializer {
 private int tick,passed;private boolean failed;
 private final BlockPos[] positions={new BlockPos(30000032,100,4),new BlockPos(-30000032,100,4),new BlockPos(4,100,30000032),new BlockPos(4,100,-30000032),new BlockPos(32000032,100,4),new BlockPos(4,100,-32000032),new BlockPos(8,2031,8),new BlockPos(8,-2032,8),new BlockPos(30000032,1024,4),new BlockPos(-30000032,-1024,4)};
 private void check(boolean v,String n){if(!v)throw new AssertionError(n);passed++;System.out.println("BORDERLESS PASS "+n);}
 private void cmd(MinecraftServer s,String c){s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),c);}
 public void onInitialize(){ServerTickEvents.END_SERVER_TICK.register(s->{if(failed)return;try{run(s);}catch(Throwable e){failed=true;System.out.println("BORDERLESS CHECKS FAILED");e.printStackTrace();s.halt(false);}});}
 private void run(MinecraftServer s)throws Exception{
  tick++;var l=s.overworld();boolean restart=Boolean.getBoolean("borderless.test.restart");
  if(tick==1){for(BlockPos p:positions)cmd(s,"forceload add "+p.getX()+" "+p.getZ());}
  if(tick==20){
   for(var level:s.getAllLevels()){
    var b=level.getWorldBorder();b.setCenter(0,0);b.setSize(16);b.setDamagePerBlock(100);b.setWarningBlocks(1000);
    check(b.getCollisionShape().isEmpty(),"no border collision "+level.dimension());
    check(b.getDamagePerBlock()==0&&b.getWarningBlocks()==0&&b.getWarningTime()==0,"damage/warnings disabled "+level.dimension());
    check(level.getMinY()==-2032&&level.getMaxY()==2031&&level.getSectionsCount()==254,"expanded real chunk height "+level.dimension());
    check(b.isWithinBounds(new BlockPos(32000032,100,32000032))&&b.isWithinBounds(new Vec3(-32000032,100,-32000032))&&b.isWithinBounds(new ChunkPos(2000002,-2000002))&&b.isWithinBounds(new AABB(32000031,90,0,32000034,100,2)),"border position/vec/chunk/box accepted "+level.dimension());
    check(b.clampVec3ToBound(32000032,1024,-32000032).equals(new Vec3(32000032,1024,-32000032)),"border no longer clamps "+level.dimension());
    check(Double.isInfinite(b.getDistanceToBorder(32000032,-32000032)),"unbounded distance "+level.dimension());
   }
   Method clamp=net.minecraft.server.network.ServerGamePacketListenerImpl.class.getDeclaredMethod("clampHorizontal",double.class);clamp.setAccessible(true);
   check((double)clamp.invoke(null,32000032.75)==32000032.75&&(double)clamp.invoke(null,-32000032.75)==-32000032.75,"network movement clamp removed");
   for(BlockPos p:positions){
    check(l.isInWorldBounds(p)&&l.isInValidBounds(p)&&Level.isInSpawnableBounds(p),"world bounds accept "+p);
    var chunk=l.getChunkAt(p);check(chunk.getPos().equals(new ChunkPos(p.getX() >> 4,p.getZ() >> 4)),"real chunk generated/loaded "+p);
    if(restart){check(l.getBlockState(p).is(Blocks.SEA_LANTERN),"saved block survived restart "+p);}
    else{l.setBlockAndUpdate(p,Blocks.AIR.defaultBlockState());check(l.setBlockAndUpdate(p,Blocks.SEA_LANTERN.defaultBlockState()),"placement beyond original bounds "+p);check(l.getBlockState(p).is(Blocks.SEA_LANTERN),"block readable "+p);check(l.getHeight(Heightmap.Types.WORLD_SURFACE,p.getX(),p.getZ())>=p.getY(),"heightmap usable "+p);}
   }
   check(!l.isInWorldBounds(new BlockPos(8,2032,8))&&!l.isInWorldBounds(new BlockPos(8,-2033,8)),"storage bounds retained beyond supported height");
   if(!restart){
    ArmorStand a=new ArmorStand(l,32000033.5,100,-32000033.5);a.absSnapTo(32000033.5,100,-32000033.5);check(a.getX()==32000033.5&&a.getZ()==-32000033.5,"entity snap retains position");
    var out=TagValueOutput.createWithContext(net.minecraft.util.ProblemReporter.DISCARDING,l.registryAccess());a.saveWithoutId(out);var tag=out.buildResult();ArmorStand loaded=new ArmorStand(l,0,100,0);loaded.load(TagValueInput.create(net.minecraft.util.ProblemReporter.DISCARDING,l.registryAccess(),tag));check(loaded.getX()==a.getX()&&loaded.getZ()==a.getZ(),"entity load retains far coordinates");
    check(net.minecraft.world.level.dimension.DimensionType.DIRECT_CODEC.encodeStart(net.minecraft.resources.RegistryOps.create(net.minecraft.nbt.NbtOps.INSTANCE,l.registryAccess()),l.dimensionType()).isSuccess(),"expanded dimension settings encode for save/network");
   }
  }
  if(tick==60){for(BlockPos p:positions){check(l.getBlockState(p).is(Blocks.SEA_LANTERN),"block persisted while ticking "+p);check(l.getBrightness(net.minecraft.world.level.LightLayer.BLOCK,p)==15,"block lighting works "+p);check(l.getMaxLocalRawBrightness(p)>0,"brightness query works "+p);}
   System.out.println("BORDERLESS "+(restart?"RESTART":"SERVER")+" CHECKS PASSED "+passed);s.halt(false);}
 }
}
