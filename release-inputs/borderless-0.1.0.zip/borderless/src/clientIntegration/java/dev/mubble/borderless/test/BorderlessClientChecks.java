package dev.mubble.borderless.test;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.core.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
public final class BorderlessClientChecks implements ClientModInitializer {
 private boolean requested,failed;private int tick,passed;private final AtomicBoolean ready=new AtomicBoolean();
 private final BlockPos[] bases={new BlockPos(30000032,100,4),new BlockPos(-30000032,1024,4),new BlockPos(4,2030,32000032),new BlockPos(4,-2032,-32000032)};
 private int phase;private BlockPos placed;
 private void check(boolean b,String n){if(!b)throw new AssertionError(n);passed++;System.out.println("BORDERLESS CLIENT PASS "+n);}
 public void onInitializeClient(){ClientTickEvents.END_CLIENT_TICK.register(c->{if(failed)return;try{run(c);}catch(Throwable e){failed=true;System.out.println("BORDERLESS CLIENT CHECKS FAILED");e.printStackTrace();c.stop();}});}
 private void prepare(Minecraft c){ready.set(false);tick=0;var pos=bases[phase];placed=pos.above();c.getSingleplayerServer().execute(()->{try{var s=c.getSingleplayerServer();var l=s.overworld();l.getChunkAt(pos);l.setBlockAndUpdate(pos,Blocks.STONE.defaultBlockState());l.setBlockAndUpdate(pos.above(),Blocks.AIR.defaultBlockState());l.setBlockAndUpdate(pos.west(),Blocks.STONE.defaultBlockState());var b=l.getWorldBorder();b.setSize(16);b.setDamagePerBlock(100);var p=s.getPlayerList().getPlayers().getFirst();p.setGameMode(GameType.CREATIVE);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.SEA_LANTERN));p.teleportTo(l,pos.getX()-.5,pos.getY()+2.5,pos.getZ()+.5,Set.of(),0,45,false);ready.set(true);}catch(Throwable e){failed=true;System.out.println("BORDERLESS CLIENT CHECKS FAILED");e.printStackTrace();c.execute(c::stop);}});}
 private void run(Minecraft c){
  if(c.gui.screen() instanceof net.minecraft.client.gui.screens.AccessibilityOnboardingScreen screen)screen.onClose();
  if(c.level==null||c.player==null||!c.hasSingleplayerServer())return;
  if(!requested){requested=true;c.options.pauseOnLostFocus=false;c.options.renderDistance().set(2);c.options.framerateLimit().set(30);prepare(c);}
  if(!ready.get())return;
  tick++;
  if(tick==100){var p=bases[phase];check(c.level.getMinY()==-2032&&c.level.getMaxY()==2031,"client receives expanded height phase "+phase);check(Math.abs(c.player.getX()-(p.getX()-.5))<1&&Math.abs(c.player.getZ()-(p.getZ()+.5))<1,"teleport/network/player tick retains far position "+phase);check(c.level.getBlockState(p).is(Blocks.STONE),"client receives far/high chunk "+phase);check(c.level.getWorldBorder().getCollisionShape().isEmpty(),"client has no border collision "+phase);c.player.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.SEA_LANTERN));var hit=new BlockHitResult(new Vec3(p.getX()+.5,p.getY()+1,p.getZ()+.5),Direction.UP,p,false);check(c.gameMode.useItemOn(c.player,InteractionHand.MAIN_HAND,hit).consumesAction(),"real placement accepted "+phase);}
  if(tick==130){check(c.level.getBlockState(placed).is(Blocks.SEA_LANTERN),"placement synchronized "+phase);check(c.level.getBrightness(net.minecraft.world.level.LightLayer.BLOCK,placed)==15,"client light works "+phase);var p=placed;c.getSingleplayerServer().execute(()->check(c.getSingleplayerServer().overworld().getBlockState(p).is(Blocks.SEA_LANTERN),"server accepted real use-item packet "+phase));check(c.gameMode.startDestroyBlock(placed,Direction.UP),"real breaking accepted "+phase);}
  if(tick==160){check(c.level.getBlockState(placed).isAir(),"breaking synchronized "+phase);var p=placed;c.getSingleplayerServer().execute(()->check(c.getSingleplayerServer().overworld().getBlockState(p).isAir(),"server accepted real break packet "+phase));}
  if(tick==180){if(++phase<bases.length)prepare(c);else{System.out.println("BORDERLESS CLIENT CHECKS PASSED "+passed);c.stop();}}
 }
}
