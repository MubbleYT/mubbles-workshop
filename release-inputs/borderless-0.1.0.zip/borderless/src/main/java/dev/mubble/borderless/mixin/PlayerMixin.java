package dev.mubble.borderless.mixin;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(Player.class)
public abstract class PlayerMixin {
 @Redirect(method="tick",at=@At(value="INVOKE",target="Lnet/minecraft/util/Mth;clamp(DDD)D"),require=2)
 private double borderless$position(double value,double min,double max){return value;}
}
