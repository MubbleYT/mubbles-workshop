package dev.mubble.borderless.mixin;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ServerGamePacketListenerImpl.class)
public abstract class ServerMovementMixin {
 @Inject(method="clampHorizontal",at=@At("HEAD"),cancellable=true)
 private static void borderless$move(double value,CallbackInfoReturnable<Double> cir){cir.setReturnValue(value);}
}
