package dev.mubble.borderless.mixin;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(Entity.class)
public abstract class EntityMixin {
 @Redirect(method="absSnapTo(DDD)V",at=@At(value="INVOKE",target="Lnet/minecraft/util/Mth;clamp(DDD)D"),require=2)
 private double borderless$snap(double value,double min,double max){return value;}
 @Redirect(method="load",at=@At(value="INVOKE",target="Lnet/minecraft/util/Mth;clamp(DDD)D"),require=3)
 private double borderless$load(double value,double min,double max){return min==-30000512.0&&max==30000512.0?value:Mth.clamp(value,min,max);}
}
