package dev.mubble.borderless.mixin;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Level.class)
public abstract class LevelMixin {
 @Inject(method="isInWorldBoundsHorizontal",at=@At("HEAD"),cancellable=true)
 private static void borderless$horizontal(CallbackInfoReturnable<Boolean> cir){cir.setReturnValue(true);}
 @ModifyConstant(method="getHeight",constant=@Constant(intValue=-30000000),require=2)
 private int borderless$min(int old){return Integer.MIN_VALUE;}
 @ModifyConstant(method="getHeight",constant=@Constant(intValue=30000000),require=2)
 private int borderless$max(int old){return Integer.MAX_VALUE;}
}
