package dev.mubble.borderless.mixin;
import net.minecraft.world.level.LevelReader;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(LevelReader.class)
public interface LevelReaderMixin {
 @ModifyConstant(method="getMaxLocalRawBrightness(Lnet/minecraft/core/BlockPos;I)I",constant=@Constant(intValue=-30000000),require=2)
 private int borderless$min(int old){return Integer.MIN_VALUE;}
 @ModifyConstant(method="getMaxLocalRawBrightness(Lnet/minecraft/core/BlockPos;I)I",constant=@Constant(intValue=30000000),require=2)
 private int borderless$max(int old){return Integer.MAX_VALUE;}
}
