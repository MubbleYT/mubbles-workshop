package dev.mubble.borderless.mixin;
import net.minecraft.server.commands.ForceLoadCommand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(ForceLoadCommand.class)
public abstract class ForceLoadMixin {
 @ModifyConstant(method="changeForceLoad",constant=@Constant(intValue=-30000000),require=2)
 private static int borderless$min(int old){return Integer.MIN_VALUE;}
 @ModifyConstant(method="changeForceLoad",constant=@Constant(intValue=30000000),require=2)
 private static int borderless$max(int old){return Integer.MAX_VALUE;}
}
