package dev.mubble.borderless.mixin;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
/** Border settings remain saved, but have no gameplay effect while installed. */
@Mixin(WorldBorder.class)
public abstract class WorldBorderMixin {
 @Inject(method="isWithinBounds",at=@At("HEAD"),cancellable=true)
 private void borderless$inside(CallbackInfoReturnable<Boolean> cir){cir.setReturnValue(true);}
 @Inject(method={"getMinX","getMinZ"},at=@At("HEAD"),cancellable=true)
 private void borderless$min(CallbackInfoReturnable<Double> cir){cir.setReturnValue(Double.NEGATIVE_INFINITY);}
 @Inject(method={"getMaxX","getMaxZ"},at=@At("HEAD"),cancellable=true)
 private void borderless$max(CallbackInfoReturnable<Double> cir){cir.setReturnValue(Double.POSITIVE_INFINITY);}
 @Inject(method="getDistanceToBorder",at=@At("HEAD"),cancellable=true)
 private void borderless$distance(CallbackInfoReturnable<Double> cir){cir.setReturnValue(Double.POSITIVE_INFINITY);}
 @Inject(method="getCollisionShape",at=@At("HEAD"),cancellable=true)
 private void borderless$collision(CallbackInfoReturnable<VoxelShape> cir){cir.setReturnValue(Shapes.empty());}
 @Inject(method="isInsideCloseToBorder",at=@At("HEAD"),cancellable=true)
 private void borderless$near(CallbackInfoReturnable<Boolean> cir){cir.setReturnValue(false);}
 @Inject(method="clampVec3ToBound(DDD)Lnet/minecraft/world/phys/Vec3;",at=@At("HEAD"),cancellable=true)
 private void borderless$clamp(double x,double y,double z,CallbackInfoReturnable<Vec3> cir){cir.setReturnValue(new Vec3(x,y,z));}
 @Inject(method="getDamagePerBlock",at=@At("HEAD"),cancellable=true)
 private void borderless$damage(CallbackInfoReturnable<Double> cir){cir.setReturnValue(0.0);}
 @Inject(method={"getWarningBlocks","getWarningTime"},at=@At("HEAD"),cancellable=true)
 private void borderless$warning(CallbackInfoReturnable<Integer> cir){cir.setReturnValue(0);}
}
