package dev.mubble.borderless.mixin;
import net.minecraft.client.renderer.WorldBorderRenderer;
import net.minecraft.client.renderer.state.level.WorldBorderRenderState;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(WorldBorderRenderer.class)
public abstract class WorldBorderRendererMixin {
 @Inject(method="extract",at=@At("HEAD"),cancellable=true)
 private void borderless$extract(WorldBorder border,float partial,Vec3 camera,double range,WorldBorderRenderState state,CallbackInfo ci){state.reset();state.alpha=0;ci.cancel();}
 @Inject(method={"prepare","render","renderOit"},at=@At("HEAD"),cancellable=true)
 private void borderless$render(CallbackInfo ci){ci.cancel();}
}
