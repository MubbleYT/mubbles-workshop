package dev.mubble.borderless.mixin;
import net.minecraft.world.level.dimension.DimensionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/** Expand actual chunk storage, not just the placement check. Portal logical heights stay unchanged. */
@Mixin(DimensionType.class)
public abstract class DimensionHeightMixin {
 @Inject(method="minY",at=@At("HEAD"),cancellable=true)
 private void borderless$min(CallbackInfoReturnable<Integer> cir){cir.setReturnValue(-2032);}
 @Inject(method="height",at=@At("HEAD"),cancellable=true)
 private void borderless$height(CallbackInfoReturnable<Integer> cir){cir.setReturnValue(4064);}
}
