package dev.mubble.borderless.mixin;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(MinecraftServer.class)
public abstract class ServerSizeMixin {
 @Inject(method="getAbsoluteMaxWorldSize",at=@At("HEAD"),cancellable=true)
 private void borderless$size(CallbackInfoReturnable<Integer> cir){cir.setReturnValue(Integer.MAX_VALUE);}
}
