#version 330 compatibility

out vec2 texcoord;
out vec2 lightUV;
out vec4 glcolor;

out vec3 surfaceNormal;
uniform mat4 gbufferModelViewInverse;
void main() {
    surfaceNormal=normalize(mat3(gbufferModelViewInverse)*(gl_NormalMatrix*gl_Normal));
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lightUV = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
}
