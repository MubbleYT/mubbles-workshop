#version 430 compatibility
/* DRAWBUFFERS:0 */

#define COLORED_LIGHTS 1 // [0 1 2] 0=off, 1=nearby, 2=wide
#define LIGHT_OCCLUSION 1 // [0 1] Off / Screen-space shadowing
#define SMOKE_STYLE 2 // [0 1 2] Vanilla, Vanilla+, Volumetric
#define SMOKE_SIZE 1.15 // overall puff size multiplier (1.0 = small puffs, raise for fatter smoke)
#define SMOKE_START_DELAY 3.0 // seconds a freshly placed campfire stays smokeless before its first puff

#define LIGHT_VIEW_DISTANCE 96 // [24 48 64 96 128]
const float voxelDistance = LIGHT_VIEW_DISTANCE;
uniform sampler2D colortex0;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform mat4 gbufferModelView;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;
uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
uniform mat4 dhProjectionInverse;
#endif
in vec2 texcoord;
layout(std430, binding = 0) buffer NearbyLights {
    uint count;
    uint seen[8192];
    vec4 positions[256];
    vec4 colors[256];
    float screenWet;
    float pad0;
    vec4 lingeringSmoke[16];
    vec4 smokeBirth[16];
} lights;

layout(std430, binding = 1) buffer SceneVoxels {
    uint occupiedCount;
    uint bits[65536];
} voxels;

bool insideVoxelGrid(ivec3 cell) {
    return all(greaterThanEqual(cell, ivec3(0))) && all(lessThan(cell, ivec3(128)));
}

bool occupiedBlock(ivec3 worldCell) {
    ivec3 cell = worldCell - ivec3(floor(cameraPosition)) + ivec3(64);
    if (!insideVoxelGrid(cell)) return false;
    uint index = uint(cell.x) | (uint(cell.y) << 7u) | (uint(cell.z) << 14u);
    return (voxels.bits[index >> 5u] & (1u << (index & 31u))) != 0u;
}

vec3 worldAt(vec2 uv, float depth, mat4 inverseProjection) {
    vec4 view = inverseProjection * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return (gbufferModelViewInverse * vec4(view.xyz / view.w, 1.0)).xyz + cameraPosition;
}

// A direct light ray is blocked if it passes behind foreground geometry in
// the camera depth buffer. Rays outside the view remain an approximation.
float linearDepth(float d);
float directLightVisibility(vec3 source, vec3 receiver) {
#if LIGHT_OCCLUSION == 0
    return 1.0;
#else
    vec3 path = receiver - source;
    if (dot(path, path) < 0.65) return 1.0;
    ivec3 sourceCell = ivec3(floor(source));
    ivec3 receiverCell = ivec3(floor(receiver));
    ivec3 sourceGrid = sourceCell - ivec3(floor(cameraPosition)) + ivec3(64);
    ivec3 receiverGrid = receiverCell - ivec3(floor(cameraPosition)) + ivec3(64);
    if (voxels.occupiedCount > 0u && insideVoxelGrid(sourceGrid) &&
        insideVoxelGrid(receiverGrid)) {
        int samples = clamp(int(ceil(length(path) * 2.0)), 2, 32);
        for (int sampleIndex = 1; sampleIndex < samples; ++sampleIndex) {
            ivec3 cell = ivec3(floor(source + path * (float(sampleIndex) / float(samples))));
            if (all(equal(cell, sourceCell)) || all(equal(cell, receiverCell))) continue;
            if (occupiedBlock(cell)) return 0.0;
        }
        return 1.0;
    }
    // Fall back to visible depth only when the ray leaves the voxel grid.
    for (int stepIndex = 1; stepIndex <= 6; ++stepIndex) {
        vec3 point = source + path * (float(stepIndex) / 7.0);
        vec4 view = gbufferModelView * vec4(point - cameraPosition, 1.0);
        if (view.z > -near) continue;
        vec4 clip = gbufferProjection * view;
        vec2 uv = clip.xy / clip.w * 0.5 + 0.5;
        if (any(lessThan(uv, vec2(0.001))) || any(greaterThan(uv, vec2(0.999)))) continue;
        float blockerDepth = texture(depthtex0, uv).r;
        if (blockerDepth >= 0.99999) continue;
        float blockerDistance = linearDepth(blockerDepth);
        if (-view.z > blockerDistance + 0.42) return 0.0;
    }
    return 1.0;
#endif
}

float linearDepth(float d) {
    return (2.0 * near * far) / (far + near - (d * 2.0 - 1.0) * (far - near));
}

float hash11(float n) { return fract(sin(n) * 43758.5453123); }
float hash13(vec3 p) { return fract(sin(dot(p, vec3(12.9898, 78.233, 37.719))) * 43758.5453); }

float burnPhaseFlicker(vec3 lightPos) {
    float seed = hash13(floor(lightPos));
    float t = frameTimeCounter + seed * 1000.0;
    float period = 5.0 + hash11(seed * 17.3) * 5.0;
    float localT = mod(t, period);
    float eventId = floor(t / period) + seed * 31.0;
    float shape = hash11(eventId * 3.7);
    float start = 0.5 + hash11(eventId * 9.1) * (period - 2.8);
    float dur = 1.4 + shape * 1.2;
    float u = (localT - start) / dur;
    float intensity = 1.0;
    if (u >= 0.0 && u <= 1.0) {
        float dimTarget = 0.72 + shape * 0.08;
        float brightTarget = 1.12 + shape * 0.10;
        if (u < 0.40) {
            float e = u / 0.40; e = e * e * (3.0 - 2.0 * e);
            intensity = mix(1.0, dimTarget, e);
        } else if (u < 0.60) {
            float e = (u - 0.40) / 0.20; e = e * e * (3.0 - 2.0 * e);
            intensity = mix(dimTarget, brightTarget, e);
        } else {
            float e = (u - 0.60) / 0.40; e = e * e * (3.0 - 2.0 * e);
            intensity = mix(brightTarget, 1.0, e);
        }
        intensity += 0.015 * sin(t * (5.0 + shape * 3.0) + eventId);
    } else {
        intensity = 0.97 + 0.03 * sin(t * 0.9 + seed * 18.0)
                  + 0.015 * sin(t * 2.4 + seed * 7.0);
    }
    return clamp(intensity, 0.70, 1.22);
}

bool isFlameLight(float kind, vec3 baseColor) {
    // Lanterns glow steadily; only exposed flames flicker and spark.
    return (kind > 4.5 && kind < 5.5) || (kind > 19.5 && kind < 20.5) || (kind > 11.5 && kind < 12.5)
        || (kind > 16.5 && kind < 19.5);
}

vec3 flameAndSparks(vec3 receiver, vec3 lightPos, float kind, float depth) {
    vec3 contrib = vec3(0.0);
    float dist = length(lightPos - receiver);
    if (dist > 4.0) return contrib;
    float seed = hash13(floor(lightPos));
    float t = frameTimeCounter;
    for (int s = 0; s < 5; ++s) {
        float fh = float(s) * 0.18;
        vec3 flamePos = lightPos + vec3(
            0.08 * sin(t * 6.0 + seed * 10.0 + fh * 4.0),
            0.15 + fh,
            0.08 * cos(t * 5.2 + seed * 8.0 + fh * 3.5)
        );
        float d = length(receiver - flamePos);
        float core = exp(-d * d * 28.0);
        float outer = exp(-d * d * 10.0);
        bool soul = (kind > 16.5 && kind < 17.5) || (kind > 18.5 && kind < 19.5);
        vec3 flameCol = soul ? mix(vec3(0.06, 0.32, 1.0), vec3(0.38, 0.85, 1.0), fh * 0.8)
                             : mix(vec3(1.0, 0.35, 0.05), vec3(1.0, 0.85, 0.25), fh * 0.8);
        float flicker = 0.7 + 0.3 * sin(t * 11.0 + seed * 20.0 + fh * 7.0);
        contrib += flameCol * core * 0.12 * flicker;
        contrib += (soul ? vec3(0.1, 0.52, 1.0) : vec3(1.0, 0.55, 0.15)) * outer * 0.025 * flicker;
    }
    for (int k = 0; k < 6; ++k) {
        float pk = float(k) + seed * 7.0;
        float life = fract(t * 0.35 + hash11(pk * 3.1));
        float rise = life * 1.8;
        float drift = sin(pk * 12.0 + t * 2.0) * 0.25 * life;
        vec3 sparkPos = lightPos + vec3(drift, 0.2 + rise, drift * 0.7);
        float sd = length(receiver - sparkPos);
        float spark = exp(-sd * sd * 90.0) * (1.0 - life);
        contrib += ((kind > 16.5 && kind < 17.5) || (kind > 18.5 && kind < 19.5)
                    ? vec3(0.30, 0.65, 1.0) : vec3(1.0, 0.7, 0.25)) * spark * 0.12;
    }
    return contrib * smoothstep(4.0, 1.2, dist);
}



bool isSmokeSource(float kind) {
    // Only lit campfire classes produce shader smoke; lanterns are lamps.
    return (kind > 11.5 && kind < 12.5) || (kind > 16.5 && kind < 19.5);
}

bool isCampfireKind(float kind) {
    return (kind > 11.5 && kind < 12.5) || (kind > 16.5 && kind < 17.5)
        || (kind > 17.5 && kind < 18.5) || (kind > 18.5 && kind < 19.5);
}

bool isSignalCampfire(float kind) {
    return (kind > 17.5 && kind < 18.5) || (kind > 18.5 && kind < 19.5);
}

// Smoke slot bookkeeping (lights.lingeringSmoke / lights.smokeBirth share an index):
//   slots 0..11  campfires. .w of smokeBirth = time the fire was placed
//   slots 12..15 torches (short linger only, no placement tracking)
// A campfire slot is "continuous" while it was refreshed on the previous frames;
// a gap longer than CAMP_GAP means the fire was removed and placed again.
const float CAMP_LINGER = 4.5;
const float CAMP_GAP = 0.5;
bool campSlotContinuous(float expiry) {
    return expiry > frameTimeCounter
        && frameTimeCounter - (expiry - CAMP_LINGER) < CAMP_GAP;
}
// Seconds since a slot's campfire was placed (frameTimeCounter wraps every 3600 s)
float slotAge(int slot) {
    float a = frameTimeCounter - lights.smokeBirth[slot].w;
    return a < 0.0 ? a + 3600.0 : a;
}



// Rising smoke puffs — many small blobs that travel upward with random sizes & patterns
// (same event-driven randomness style as burnPhaseFlicker on the light)
//
// age = seconds since the emitter was switched on (campfire placement). Every puff
// runs a repeating climb cycle; a cycle only exists if it started at least
// SMOKE_START_DELAY seconds after placement, so a new fire is smokeless for a few
// seconds and then its column builds up from the bottom like vanilla smoke does.
float plumeDensity(vec3 samplePos, vec3 lightPos, float seed, float kind, float age) {
    float h = samplePos.y - lightPos.y;
    bool camp = isCampfireKind(kind);
    bool signal = isSignalCampfire(kind);
    float maxH = signal ? 28.0 : (camp ? 15.0 : 5.5);
    if (h < 0.05 || h > maxH) return 0.0;

    float baseR = signal ? 0.22 : (camp ? 0.16 : 0.11);
    float widen = signal ? 0.050 : (camp ? 0.035 : 0.050);

    // Cheap horizontal cull: bound of radius + wind/gust lean + per-puff swirl.
    float rMax = (baseR + (h + 1.8) * widen + 0.05) * 2.4 * SMOKE_SIZE;
    float lim = 0.29 * (h + 1.8) + 1.0 + 1.5 * rMax;
    vec2 dxz = samplePos.xz - lightPos.xz;
    if (dot(dxz, dxz) > lim * lim) return 0.0;

    float t = frameTimeCounter;

    // Shared slow wind, plus a second chaotic gust layer
    vec2 wind = vec2(
        sin(t * 0.30 + seed * 4.0),
        cos(t * 0.25 + seed * 2.5)
    ) * 0.12;
    vec2 gust = vec2(
        sin(t * 0.55 + seed * 9.1) * cos(t * 0.18 + seed * 3.3),
        cos(t * 0.48 + seed * 7.7) * sin(t * 0.22 + seed * 5.1)
    ) * 0.08;

    float dens = 0.0;
    int puffs = 8;
    for (int i = 0; i < 8; ++i) {
        if (i >= puffs) break;
        float puffSeed = seed + float(i) * 19.7;

        // Per-puff climb rate (random, like flicker period)
        float climbMul = 0.70 + hash11(puffSeed * 2.3) * 0.70; // 0.70–1.40
        float climb = (camp ? 1.15 : 0.85) * climbMul;
        float rate = climb * 0.08;

        // Phase 0→1: puff travels from fire to top, then respawns
        float phase = fract(t * rate + puffSeed * 0.17 + float(i) * 0.13);
        float puffH = phase * maxH;

        // Cheap rejects first: puff is far from this sample, or this climb cycle
        // began before the fire existed / while it was still in its start delay.
        float dh = h - puffH;
        if (abs(dh) > 1.8 * SMOKE_SIZE) continue;
        if (age - phase / rate < SMOKE_START_DELAY) continue;

        // Event-driven size / density bursts (mirrors burnPhaseFlicker events)
        float period = 4.5 + hash11(puffSeed * 11.0) * 6.5; // 4.5–11s
        float localT = mod(t + puffSeed * 40.0, period);
        float eventId = floor((t + puffSeed * 40.0) / period) + puffSeed * 17.0;
        float shape = hash11(eventId * 3.7);
        float sizeEvent = 0.75 + shape * 0.85; // 0.75–1.60 overall scale for this cycle
        float densEvent = 0.65 + hash11(eventId * 5.9) * 0.90; // 0.65–1.55 density
        // Occasional fat billow in the middle of a cycle
        float start = 0.25 + hash11(eventId * 9.1) * 0.35;
        float dur = 1.2 + shape * 1.8;
        float u = (localT - start) / dur;
        float billow = 1.0;
        if (u >= 0.0 && u <= 1.0) {
            float e = u < 0.5 ? (u / 0.5) : (1.0 - (u - 0.5) / 0.5);
            e = e * e * (3.0 - 2.0 * e);
            billow = mix(1.0, 1.15 + shape * 0.55, e);
        }

        // Soft vertical blob — small, randomized per puff + event, grows a little with height
        float sizeMul = (0.55 + hash11(puffSeed * 8.4) * 0.95) * sizeEvent * billow;
        float puffSize = min((0.32 + phase * 0.35) * sizeMul, 1.2) * SMOKE_SIZE;
        float vert = exp(-(dh * dh) / (puffSize * puffSize * 0.55));
        if (vert < 0.02) continue;

        // Horizontal spread: thin column, base + height + random per-puff fattening
        float radius = (baseR + puffH * widen + phase * 0.05) * (0.70 + hash11(puffSeed * 4.1) * 0.80) * sizeEvent * SMOKE_SIZE;
        // Drift pattern varies: some puffs lean left, some right, some spiral
        float lean = hash11(puffSeed * 13.2) * 6.28318;
        float spiral = (hash11(puffSeed * 15.7) - 0.5) * 1.4;
        vec2 drift = (wind + gust) * puffH + vec2(
            sin(puffSeed * 6.0 + t * (0.35 + hash11(puffSeed) * 0.45) + lean) * phase * (0.25 + shape * 0.35),
            cos(puffSeed * 5.0 - t * (0.30 + hash11(puffSeed * 1.7) * 0.40) + lean * 0.7) * phase * (0.22 + shape * 0.30)
        ) + vec2(cos(phase * 6.28318 * spiral + lean), sin(phase * 6.28318 * spiral + lean)) * phase * 0.18 * spiral;
        vec2 offset = (samplePos.xz - lightPos.xz) - drift;
        float radial = length(offset);
        float core = exp(-(radial * radial) / (radius * radius * 0.50));

        // Fade near top / birth; lifetime stretch is also a bit random
        float birthEnd = 0.08 + hash11(puffSeed * 6.6) * 0.10;
        float deathStart = 0.68 + hash11(puffSeed * 7.2) * 0.18;
        float birth = smoothstep(0.0, birthEnd, phase);
        float death = 1.0 - smoothstep(deathStart, 1.0, phase);
        // Local turbulence — higher frequency noise for irregular edges
        float turb = 0.55 + 0.45 * sin(samplePos.x * (2.5 + shape * 2.0) * 2.5 + t * (0.8 + densEvent * 0.4) + puffSeed)
                   * cos(samplePos.z * (2.0 + shape * 1.5) * 2.5 - t * 0.6 + puffSeed * 1.3);

        dens += vert * core * birth * death * turb * densEvent;
    }

    // Small puffs cover far less of the ray, so the density is pushed up to stay readable
    float boost = signal ? 5.95 : (camp ? 4.85 : 3.0);
    return dens * boost;
}


// rgb = visible smoke, a = transmittance through campfire plume.
vec4 volumetricSmoke(vec3 rayOrigin, vec3 rayDir, float maxDist) {
#if SMOKE_STYLE == 0
    return vec4(0.0, 0.0, 0.0, 1.0);
#else
    vec3 smokeAccum = vec3(0.0);
    float transmittance = 1.0;
    uint nearbyCount = min(lights.count, 256u);
    // A maximum of four plumes can affect a pixel. Per-source ray-sphere
    // intersection skips all density work for rays that cannot hit a plume.
    int found = 0;
    for (int i = 0; i < 256 && found < 4; ++i) {
        if (uint(i) >= nearbyCount) break;
        float kind = lights.positions[i].w;
        if (kind < 0.5) kind = lights.colors[i].a;
        if (!isSmokeSource(kind)) continue;
        vec3 lp = lights.positions[i].xyz;
        bool signal = isSignalCampfire(kind);
        float midH = signal ? 14.0 : 7.5;
        float bound = signal ? 17.0 : 8.5;
        vec3 delta = lp + vec3(0.0, midH, 0.0) - rayOrigin;
        float nearest = clamp(dot(delta, rayDir), 0.0, maxDist);
        float d2 = dot(delta - rayDir * nearest, delta - rayDir * nearest);
        if (d2 > bound * bound) continue;
        found++;
        float age = 0.0;
        float fade = 1.0;
        bool live = false;
        for (int j = 0; j < 12; ++j) {
            vec4 slot = lights.lingeringSmoke[j];
            if (length(slot.xyz - lp) < 0.75 && campSlotContinuous(slot.w)) {
                age = slotAge(j);
                live = true;
                break;
            }
        }
        if (!live) continue;
        float halfSpan = sqrt(max(bound * bound - d2, 0.0));
        float beginT = max(0.0, nearest - halfSpan);
        float endT = min(maxDist, nearest + halfSpan);
        float stepLen = (endT - beginT) / float(SMOKE_STYLE == 1 ? 6 : 10);
        if (stepLen < 0.001) continue;
        float jitter = fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)) * 52.9829189);
        float seed = hash13(floor(lp));
        for (int j = 0; j < (SMOKE_STYLE == 1 ? 6 : 10); ++j) {
            vec3 p = rayOrigin + rayDir * (beginT + (float(j) + jitter) * stepLen);
            float dens = plumeDensity(p, lp, seed, kind, age);
            float absorb = clamp(1.0 - exp(-dens * stepLen * (SMOKE_STYLE == 1 ? 0.55 : 1.0)), 0.0, 0.45);
            vec3 smokeCol = signal ? vec3(0.16, 0.15, 0.14) : vec3(0.32, 0.31, 0.30);
            smokeAccum += smokeCol * absorb * transmittance;
            transmittance *= 1.0 - absorb * 0.88;
        }
    }
    return vec4(smokeAccum, transmittance);
#endif
}



void main() {
    vec3 color = texture(colortex0, texcoord).rgb;
    float depth = texture(depthtex0, texcoord).r;
    bool hasSurf = depth < 0.99999;
    vec3 receiver = cameraPosition;
    float sceneDist = 40.0;
    if (hasSurf) {
        receiver = worldAt(texcoord, depth, gbufferProjectionInverse);
        sceneDist = length(receiver - cameraPosition);
    }
#ifdef DISTANT_HORIZONS
    if (!hasSurf) {
        float distantDepth = texture(dhDepthTex0, texcoord).r;
        if (distantDepth < 0.99999) {
            receiver = worldAt(texcoord, distantDepth, dhProjectionInverse);
            sceneDist = length(receiver - cameraPosition);
            hasSurf = true;
        }
    }
#endif

    // View ray for volumetric smoke (works in air and against surfaces)
    vec4 ndc = vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
    vec4 viewFar = gbufferProjectionInverse * ndc;
    viewFar /= viewFar.w;
    vec3 rayDir = normalize((gbufferModelViewInverse * vec4(viewFar.xyz, 0.0)).xyz);

#if COLORED_LIGHTS > 0
    // World-space surface orientation and texture color are shared by all
    // emitters. Calculate derivatives before the nonuniform surface branch.
    vec3 geometric = cross(dFdx(receiver), dFdy(receiver));
    float normalLength = length(geometric);
    vec3 normal = normalLength > 0.00001 ? geometric / normalLength : vec3(0.0, 1.0, 0.0);
    vec4 meshNormal=texture(colortex5,texcoord);
    if (meshNormal.a>0.5) normal=normalize(meshNormal.xyz*2.0-1.0);
    if (dot(normal, cameraPosition - receiver) < 0.0) normal = -normal;
    vec4 material = texture(colortex4, texcoord);
    vec3 surfaceColor = material.a > 0.01 ? material.rgb : color;
    if (hasSurf) {
        vec4 lightLevel = texture(colortex3, texcoord);
        float vanillaGate = lightLevel.a > 0.5 ?
            smoothstep(0.02, 0.14, lightLevel.r) : 1.0;
        vec3 lightSum = vec3(0.0);
        vec3 fxSum = vec3(0.0);
        uint nearbyCount = min(lights.count, 256u);
        for (uint i = 0u; i < nearbyCount; ++i) {
            vec3 lightPos = lights.positions[i].xyz;
            float kind = lights.positions[i].w;
            if (kind < 0.5) kind = lights.colors[i].a;
            vec3 baseCol = lights.colors[i].rgb;
            vec3 delta = receiver - lightPos;
            float d2 = dot(delta, delta);
            float range = COLORED_LIGHTS == 1 ? 10.0 : 14.0;
            if (d2 < range * range) {
                float window = max(1.0 - pow(d2 / (range * range), 2.0), 0.0);
                float falloff = window / sqrt(1.0 + d2 * 0.18);
                float flicker = isFlameLight(kind, baseCol) ? burnPhaseFlicker(lightPos) : 1.0;
                float strength = 1.0;
                // Campfire / fire: softer so they don't nuke the scene
                if ((kind > 11.5 && kind < 12.5) || (kind > 19.5 && kind < 20.5)) strength = 0.40;
                if (kind > 16.5 && kind < 17.5) strength = 0.40;
                float visible = vanillaGate > 0.001 ?
                    directLightVisibility(lightPos, receiver) * vanillaGate : 0.0;
                vec3 towardLight = -delta * inversesqrt(max(d2, 0.0001));
                float facing = material.a > 0.01 ? max(dot(normal, towardLight), 0.0) : 0.5;
                // Soft ambient bounce allows a little color on edges, while
                // front-facing texture detail carries the direct light.
                float incidence = 0.08 + 0.92 * facing;
                lightSum += baseCol * falloff * falloff * flicker * strength * visible * incidence;
            }
            if (isFlameLight(kind, baseCol)) {
                fxSum += flameAndSparks(receiver, lightPos, kind, depth);
            }
        }

        for (int hand=0; hand<2; ++hand) {
            int id=hand==0?heldItemId:heldItemId2;
            float held=float(hand==0?heldBlockLightValue:heldBlockLightValue2);
            // Soul/copper torches are recognized even when a renderer reports zero emission.
            if (id==100 || id==102 || id==104) held=max(held,14.0);
            if (id==101) held=max(held,10.0);
            if (id==103) held=max(held,7.0);
            if (held<=0.5) continue;
            vec3 offset=vec3(hand==0?0.30:-0.30,-0.20,-0.35);
            vec3 handPos=cameraPosition+(gbufferModelViewInverse*vec4(offset,0.0)).xyz;
            vec3 delta=handPos-receiver;
            float distanceToHand=length(delta), range=held*0.85;
            float window=max(1.0-pow(distanceToHand/range,4.0),0.0);
            float falloff=window/sqrt(1.0+distanceToHand*distanceToHand*0.18);
            vec3 torchCol=id==101?vec3(0.20,0.65,1.0):id==102?vec3(0.28,1.0,0.43):
                id==103?vec3(1.0,0.12,0.18):id==104?vec3(0.90,0.95,1.0):vec3(1.0,0.48,0.18);
            float facing=max(dot(normal,delta/max(distanceToHand,0.001)),0.0);
            float visible=directLightVisibility(handPos,receiver);
            float flicker=(id==100 || id==101 || id==102)?burnPhaseFlicker(vec3(17.3+float(hand),9.0,4.0)):1.0;
            lightSum+=torchCol*falloff*falloff*flicker*visible*(0.12+0.88*facing);
        }

        if (material.a > 0.01) {
            // Replace the neutral Minecraft block-light share where a colored
            // emitter actually reaches this surface. Preserve daylight and
            // uncovered terrain so blue lamps do not sit in a white halo.
            float neutralBlock = max(pow(lightLevel.r, 1.45) - pow(lightLevel.g, 1.35), 0.0);
            float coloredCoverage = clamp(max(max(lightSum.r, lightSum.g), lightSum.b) * 1.35, 0.0, 1.0);
            color -= surfaceColor * neutralBlock * coloredCoverage * 0.78;
        }
        color += surfaceColor * min(lightSum * 0.72, vec3(0.72));
        color += min(fxSum, vec3(0.28));
    }
#endif


    // Refresh / allocate lingering smoke slots from active campfires (once per frame)
    if (texcoord.x < 1.5 / viewWidth && texcoord.y < 1.5 / viewHeight) {
        float now = frameTimeCounter;
        uint nearbyCount = min(lights.count, 256u);
        for (uint i = 0u; i < nearbyCount; ++i) {
            float kind = lights.positions[i].w;
            if (kind < 0.5) kind = lights.colors[i].a;
            if (!isSmokeSource(kind)) continue;
            if (!isCampfireKind(kind)) continue;
            // Only linger campfires (and briefly torches)
            bool camp = true;
            vec3 lp = lights.positions[i].xyz;
            float linger = camp ? CAMP_LINGER : 1.2; // seconds after break
            // Campfires own slots 0..11, torches 12..15, so torches can never crowd fires out
            int lo = camp ? 0 : 12;
            int hi = camp ? 12 : 16;
            int slot = -1;
            int empty = -1;
            for (int s = lo; s < hi; ++s) {
                vec4 L = lights.lingeringSmoke[s];
                if (L.w <= now && empty < 0) empty = s;
                if (length(L.xyz - lp) < 0.75) { slot = s; break; }
            }
            bool continuous = camp && slot >= 0 && campSlotContinuous(lights.lingeringSmoke[slot].w);
            if (slot < 0) slot = empty;
            if (slot >= 0) {
                if (camp) {
                    float birth;
                    if (continuous) {
                        // Same fire as last frame. Age is capped so it never wraps with the clock.
                        birth = now - min(slotAge(slot), 120.0);
                    } else if (length(lp - cameraPosition) > 8.0) {
                        // Appeared far away (entered range / chunk loaded): already burning
                        birth = now - 120.0;
                    } else {
                        // Appeared right next to the player: just placed
                        birth = now;
                    }
                    lights.smokeBirth[slot] = vec4(lp, birth);
                }
                lights.lingeringSmoke[slot] = vec4(lp, now + linger);
            }
        }
    }

#if SMOKE_STYLE > 0
    // Rising grey plume: darkens behind + visible smoke body
    vec4 smoke = volumetricSmoke(cameraPosition, rayDir, min(sceneDist, 28.0));
    // Fade linger intensity near expiry
    color = color * smoke.a + smoke.rgb;
#endif

    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
