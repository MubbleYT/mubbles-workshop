#version 430 compatibility
/* DRAWBUFFERS:0 */
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
#endif
in vec2 texcoord;
#include "/lib/antialias.glsl"
void main(){gl_FragData[0]=vec4(resolveEdges(texcoord),1.0);}
