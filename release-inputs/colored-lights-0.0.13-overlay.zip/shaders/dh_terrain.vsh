#version 330 compatibility
out vec4 terrainColor;
out vec2 lightUV;
out vec3 surfaceNormal;
uniform mat4 gbufferModelViewInverse;
void main() {
    surfaceNormal=normalize(mat3(gbufferModelViewInverse)*(gl_NormalMatrix*gl_Normal));
    gl_Position = ftransform();
    terrainColor = gl_Color;
    lightUV = (gl_TextureMatrix[1] * gl_MultiTexCoord2).xy;
}
