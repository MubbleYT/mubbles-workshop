#version 330 compatibility

/* DRAWBUFFERS:012345 */
uniform sampler2D gtexture;
uniform vec4 entityColor;
#include "/lib/strict_lighting.glsl"

in vec2 texcoord;
in vec2 lightUV;
in vec4 glcolor;

in vec3 surfaceNormal;
void main() {
    gl_FragData[5]=vec4(normalize(surfaceNormal)*0.5+0.5,1.0);
    vec4 color = texture(gtexture, texcoord) * glcolor;
    if (color.a < 0.1) discard;
    color.rgb=mix(color.rgb,entityColor.rgb,entityColor.a);
    gl_FragData[1]=vec4(0.0);
    gl_FragData[2]=vec4(0.0);
    vec2 levels=clamp((lightUV-vec2(1.0/32.0))*(32.0/30.0),0.0,1.0);
    gl_FragData[3]=vec4(levels.x,levels.y,0.0,1.0);
    gl_FragData[4]=vec4(color.rgb,1.0);
    color.rgb *= mubbleSurfaceLight(lightUV);
    gl_FragData[0] = color;
}
