"""Execute the actual deferred shader against controlled material and shadow textures.
Synthetic GPU fixtures, not Minecraft screenshots or a Vitrail gameplay test.
"""
from pathlib import Path
exec(Path(__file__).with_name('render_lighting.py').read_text().split('outputs=[target]')[0])
p=pipeline(vertex,expand(S/'deferred.fsh',{},{}));use(p)
identity=np.eye(4,dtype=np.float32)
for name in ['gbufferProjectionInverse','gbufferModelViewInverse','shadowModelView','shadowProjection']:
 matrix(loc(p,name.encode()),1,0,identity.ctypes.data)
u3(loc(p,b'cameraPosition'),0,0,0)
u3(loc(p,b'sunPosition'),0,1,-1);u3(loc(p,b'shadowLightPosition'),0,1,-1)
ui(loc(p,b'hasSkylight'),1);ui(loc(p,b'hasCeiling'),0)
viewport(0,0,N,N)
# Unlit material with three textured bands: stone, grass, warm wood.
y,x=np.mgrid[:N,:N];noise=0.92+0.08*((x//3+y//3)%2)
material=np.ones((N,N,4),np.float32)
for i,c in enumerate([[0.65,0.65,0.65],[0.28,0.52,0.17],[0.52,0.32,0.17]]):
 rows=slice(i*N//3,(i+1)*N//3);material[rows,:,:3]=np.array(c)*noise[rows,:,None]
def render(sky=1,block=0,shadow=1,day=0.25,rain=0,alpha=1,depthInput=None):
 use(p);u1(loc(p,b'sunAngle'),day);u1(loc(p,b'rainStrength'),rain)
 u3(loc(p,b'shadowLightPosition'),0,1,-1 if day==0.25 else 1)
 m=material.copy();m[:,:,3]=alpha
 shadowData=np.full((N,N,4),shadow,np.float32) if np.isscalar(shadow) else shadow
 inputs={'colortex0':[0.12,0.18,0.23,1],'colortex1':[0,0,0,0],'colortex3':[block,sky,0,1],'colortex4':m,'colortex5':[0.5,0.5,0,1],'depthtex0':[0.65]*4 if depthInput is None else depthInput,'shadowtex0':shadowData}
 for unit,(name,value) in enumerate(inputs.items()):
  d=np.empty((N,N,4),np.float32);d[:]=value
  active(0x84C0+unit);bindTex(0x0DE1,texture(d));ui(loc(p,name.encode()),unit)
 draw(4,0,3);return pixels()[:,:,:3]
interior=(slice(N//4,3*N//4),slice(N//4,3*N//4))
lit=render();shade=render(shadow=0);cave=render(sky=0);night=render(day=0.75);rain=render(rain=1)
assert lit[interior].mean()>shade[interior].mean()*1.30
assert cave.max()==0
assert night[interior].mean()<shade[interior].mean()*0.50
assert rain[interior].mean()<lit[interior].mean()
# Same stone albedo: shadow has a higher blue/red ratio than direct sunlight.
stone=(slice(N//8,N//4),slice(N//4,3*N//4))
assert (shade[stone][:,:,2]/shade[stone][:,:,0]).mean()>(lit[stone][:,:,2]/lit[stone][:,:,0]).mean()
# Invalid/translucent material must pass through untouched; prevents replacing composites.
transparent=render(alpha=0.4);assert np.allclose(transparent,[0.12,0.18,0.23])
edgeData=np.ones((N,N,4),np.float32);edgeData[:,:N//2]=0
edge=render(shadow=edgeData);stoneY=N//6
assert np.any((edge[stoneY,N//2-2:N//2+2,0]>shade[stoneY,N//2,0]+0.001)&(edge[stoneY,N//2-2:N//2+2,0]<lit[stoneY,N//2,0]-0.001))
unstableDepth=np.ones((N,N,4),np.float32);unstableDepth[:]=np.where((x+y)%2==0,0.6,0.9)[:,:,None]
meshStable=render(depthInput=unstableDepth);assert np.allclose(meshStable,lit,atol=0.000001)
report={'mesh_normal_lighting_independent_of_neighbor_depth':True,'actual_deferred_gpu_shader':True,'lit_mean':float(lit[interior].mean()),'shadow_mean':float(shade[interior].mean()),'unlit_cave_max':float(cave.max()),'night_mean':float(night[interior].mean()),'rain_mean':float(rain[interior].mean()),'shadows_cooler_than_direct_sun':True,'filtered_shadow_edge':True,'translucent_material_passthrough':True,'gameplay_tested':False}
Path(__file__).with_name('daylight-results.json').write_text(json.dumps(report,indent=2)+'\n')
from PIL import Image,ImageDraw
panels=[('Direct sunlight',lit),('Cast shadow',shade),('Filtered edge',edge),('Rain',rain),('Night',night),('Unlit cave',cave)]
canvas=Image.new('RGB',(768,570),(24,24,28));d=ImageDraw.Draw(canvas)
d.text((12,8),'Synthetic GPU fixtures — actual lighting shader; not Minecraft screenshots',fill='white')
for i,(label,pixels_) in enumerate(panels):
 xx=(i%3)*256;yy=30+(i//3)*270
 canvas.paste(Image.fromarray((np.clip(pixels_,0,1)*255).astype('uint8')[::-1]).resize((256,240)),(xx,yy))
 d.text((xx+8,yy+245),label,fill='white')
import io
buffer=io.BytesIO();canvas.save(buffer,format='PNG');Path(__file__).with_name('daylight-fixtures.png').write_bytes(buffer.getvalue())
print('Deferred GPU lighting: cast shadows, cool sky fill, rain, night, black caves, filtered edges and transparent passthrough passed.')
