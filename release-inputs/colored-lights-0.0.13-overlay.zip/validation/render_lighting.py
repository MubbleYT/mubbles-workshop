from pathlib import Path
"""GPU tests for foreground entity material buffers and main/offhand illumination."""
exec(Path(__file__).with_name('render_clouds.py').read_text().split('checks=[];images=[]')[0])
drawBuffers=gl('glDrawBuffers',None,[I,ptr]);readBuffer=gl('glReadBuffer',None,[U]);disable=gl('glDisable',None,[U]);disable(0x0BE2)
def pipeline(vs,fs):
 v=raw(vs,0x8B31);f=raw(fs,0x8B30);p=program();attach(p,v);attach(p,f);link(p);ok=I();pstatus(p,0x8B82,C.byref(ok));assert ok.value;delete(v);delete(f);return p
def pixels():
 r=np.empty((N,N,4),np.float32);read(0,0,N,N,0x1908,0x1406,r.ctypes.data);assert np.isfinite(r).all();return r
outputs=[target]+[texture(np.full((N,N,4),0.9,np.float32)) for _ in range(5)]
for i,tid in enumerate(outputs):attachTex(0x8D40,0x8CE0+i,0x0DE1,tid,0)
bufs=(U*6)(*[0x8CE0+i for i in range(6)]);drawBuffers(6,bufs)
entity=np.empty((N,N,4),np.float32);entity[:]=[0.2,0.6,0.8,1.0];tid=texture(entity)
ev=vertex.replace('out vec2 texcoord;','out vec2 texcoord; out vec2 lightUV; out vec4 glcolor; out vec3 surfaceNormal;').replace('texcoord=p;','texcoord=p;surfaceNormal=vec3(0,0,-1);lightUV=vec2(0.96875);glcolor=vec4(1.0);')
p=pipeline(ev,expand(S/'gbuffers_entities.fsh',{},{}));use(p);active(0x84C0);bindTex(0x0DE1,tid);ui(loc(p,b'gtexture'),0);u1(loc(p,b'sunAngle'),0.25);viewport(0,0,N,N);draw(4,0,3)
readBuffer(0x8CE4);albedo=pixels();assert np.allclose(albedo,entity)
readBuffer(0x8CE0);display=pixels();assert np.allclose(display,entity)
for i in [1,2]:readBuffer(0x8CE0+i);assert np.max(np.abs(pixels()))==0
pdelete(p)
drawBuffers(1,(U*1)(0x8CE0));readBuffer(0x8CE0)
genBuffer=gl('glGenBuffers',None,[I,ptr]);bindBuffer=gl('glBindBuffer',None,[U,U]);dataBuffer=gl('glBufferData',None,[U,C.c_ssize_t,ptr,U]);bindBase=gl('glBindBufferBase',None,[U,U,U])
for binding,size in [(0,41600),(1,262148)]:
 b=U();genBuffer(1,C.byref(b));bindBuffer(0x90D2,b);zeros=np.zeros(size,np.uint8);dataBuffer(0x90D2,size,zeros.ctypes.data,0x88E8);bindBase(0x90D2,binding,b)
settings={'SMOKE_STYLE':0,'COLORED_LIGHTS':1}
p=pipeline(vertex,expand(S/'composite.fsh',settings,{}));use(p)
values={'colortex0':[0,0,0,1],'colortex3':[0,0,0,1],'colortex4':[0.5,0.5,0.5,1],'colortex5':[0.5,0.5,0,1],'depthtex0':[0.5,0.5,0.5,0.5]}
for unit,(name,value) in enumerate(values.items()):
 active(0x84C0+unit);d=np.empty((N,N,4),np.float32);d[:]=value;tid=texture(d);bindTex(0x0DE1,tid);ui(loc(p,name.encode()),unit)
identity=np.eye(4,dtype=np.float32)
for name in ['gbufferProjectionInverse','gbufferModelViewInverse','gbufferProjection','gbufferModelView']:matrix(loc(p,name.encode()),1,0,identity.ctypes.data)
for name,value in [('viewWidth',N),('viewHeight',N),('near',0.05),('far',256)]:u1(loc(p,name.encode()),value)
u3(loc(p,b'cameraPosition'),0,0,0)
def held(main,off):
 ui(loc(p,b'heldItemId'),main);ui(loc(p,b'heldItemId2'),off)
 ui(loc(p,b'heldBlockLightValue'),14 if main==100 else 0);ui(loc(p,b'heldBlockLightValue2'),14 if off==100 else 0)
 draw(4,0,3);return pixels()[:,:,:3]
dark=held(-1,-1);main=held(100,-1);off=held(-1,100);soul=held(101,-1)
assert dark.max()==0 and main.mean()>0.001 and off.mean()>0.001
assert soul[:,:,2].mean()>soul[:,:,0].mean()
Path(__file__).with_name('lighting-results.json').write_text(json.dumps({'foreground_entity_albedo_exact':True,'foreground_entity_color_exact':True,'stale_emission_and_position_cleared':True,'empty_hands_max':float(dark.max()),'main_torch_mean':float(main.mean()),'offhand_torch_mean':float(off.mean()),'soul_blue_greater_than_red':True},indent=2))
print('Entity MRT and integer main/offhand held-light GPU fixtures passed.')
