# V0.0.9 validation

Passed on Mesa 25.2.8 OpenGL 4.5 compatibility context:

- **135 compile/link variants:** all supplied fragment/compute programs; all six
  quality profiles in both dimension folders; four cloud styles with height and
  distance changes; nine End skies with Earth/Venus; VHS and added camera controls;
  water styles/wave modes; Distant Horizons compile paths.
- **Actual cloud-library GPU fixtures:** all four styles visible above and below;
  time changes the image; foreground depth removes clouds; frozen animation/density
  produces identical images.
- **Actual entity fragment GPU fixture:** foreground albedo/color written correctly;
  old terrain emission and position cleared.
- **Actual composite GPU fixtures:** integer held-light uniforms; empty hands black;
  main/offhand torches illuminate dark material; soul torch is bluer than red.
- **Audit:** every profile value and screen control exists, include/texture paths
  exist, held uniform types match Iris, only Earth/Venus exposed, Fog absent.
- **Locked End library:** whole file byte-identical to base, including projection
  functions, call sites and 1.428148 constant.
- Release ZIP integrity and packaged PNG/JSON checks.

Reproduction (Python, NumPy, Pillow, Mesa EGL/OpenGL):

```sh
python validation/compile.py
python validation/render_clouds.py
python validation/render_lighting.py
python validation/audit.py
```

Results are JSON files under validation. Cloud fixture rows: Volumetric, Minecraft
Earth, Layered Vanilla, Dungeons. Columns: below, above, later time. These are
synthetic scenes, not game screenshots.

Still needs in-game verification: Iris loading/patching on the user's 26.3 install,
profile switching in the UI, rain/snow meshes while moving/turning, translucent
entities/armor, resource packs, Voxy integration and hardware performance. Iris
translucent entity routing depends on the installed build. No gameplay pass is
claimed. Distant Horizons water uses simpler distant shading.

Suggested checks: VHS then each quality preset; normal/soul/copper torch in either
hand; fly through/above each cloud style; opaque mob against bright terrain and
behind glass; rotate during rain/snow; Bloom Off; each water/cloud/camera control.

Implementation references: Iris ID uniforms, item.properties, gbuffers,
rendering/blending and entity ordering documentation at shaders.properties.
