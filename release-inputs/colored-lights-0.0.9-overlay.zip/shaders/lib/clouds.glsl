// World-space, depth-limited cloud layer. Both ray directions are supported.
#define CLOUD_HEIGHT 192.0 // [96.0 128.0 160.0 192.0 224.0 256.0 320.0 384.0]
#define CLOUD_DISTANCE 2400.0 // [512.0 1024.0 1600.0 2400.0 3200.0 4800.0]
#define CLOUD_SPEED 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0]
#define DYNAMIC_CLOUDS 1 // [0 1]
#define DYNAMIC_CLOUD_DENSITY 1 // [0 1]

float cloudNoiseStable(vec3 p) {
    vec3 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float result = 0.0;
    for (int z=0; z<2; ++z) for (int y=0; y<2; ++y) for (int x=0; x<2; ++x) {
        vec3 corner = vec3(x,y,z);
        vec3 weight = mix(1.0-f, f, corner);
        result += hash2((i+corner).xz + (i.y+corner.y)*vec2(17.13,43.71)) * weight.x*weight.y*weight.z;
    }
    return result;
}

float dynamicCoverage() {
    float coverage = CLOUD_COVERAGE;
#if DYNAMIC_CLOUD_DENSITY == 1
    // Slow variation independent of wind; a stable weather field travels with clouds.
    float cycle = sin(frameTimeCounter*0.0031)*0.065 + sin(frameTimeCounter*0.0013+1.8)*0.035;
    coverage = mix(coverage+cycle, 0.90, weatherStrength());
#endif
    return clamp(coverage, 0.05, 0.98);
}

vec4 stableClouds(vec2 uv) {
#if CLOUD_STEPS == 0
    return vec4(0.0);
#else
    vec3 ray = normalize((gbufferModelViewInverse * vec4(viewRay(uv),0.0)).xyz);
    float bottom = CLOUD_HEIGHT - 36.0, top = CLOUD_HEIGHT + 36.0;
    float start, finish;
    if (abs(ray.y) < 0.00001) {
        if (cameraPosition.y < bottom || cameraPosition.y > top) return vec4(0.0);
        start=0.0; finish=CLOUD_DISTANCE;
    } else {
        float a=(bottom-cameraPosition.y)/ray.y, b=(top-cameraPosition.y)/ray.y;
        start=max(0.0,min(a,b)); finish=min(CLOUD_DISTANCE,max(a,b));
    }
    // Reconstruct radial distance rather than clipping with view-space Z.
    float depth = texture(depthtex0,uv).r;
    if (depth < 0.99999) {
        vec4 v=gbufferProjectionInverse*vec4(uv*2.0-1.0,depth*2.0-1.0,1.0);
        finish=min(finish,length(v.xyz/v.w));
    }
#ifdef DISTANT_HORIZONS
    else if (texture(dhDepthTex0,uv).r < 0.99999) {
        finish=min(finish,sceneDistance(uv)/max(abs(viewRay(uv).z),0.001));
    }
#endif
    if (finish<=start) return vec4(0.0);
    vec2 wind=vec2(0.52,0.21)*frameTimeCounter*CLOUD_SPEED*float(DYNAMIC_CLOUDS);
    float coverage=dynamicCoverage();
    vec3 light=normalize((gbufferModelViewInverse*vec4(sunPosition,0.0)).xyz);
    float day=smoothstep(-0.15,0.20,light.y);
    vec3 bright=mix(vec3(0.19,0.23,0.34),vec3(1.0,0.98,0.93),day);
    bright=mix(bright,vec3(0.19,0.22,0.27),weatherStrength()*0.78);
    float stepLength=(finish-start)/float(CLOUD_STEPS);
    vec3 accum=vec3(0.0); float opacity=0.0;
    for (int i=0; i<CLOUD_STEPS; ++i) {
        float t=start+(float(i)+0.5)*stepLength;
        vec3 p=cameraPosition+ray*t; p.xz+=wind;
        float h=clamp((p.y-bottom)/72.0,0.0,1.0);
        float envelope=smoothstep(0.0,0.18,h)*(1.0-smoothstep(0.75,1.0,h));
        vec3 q=p*vec3(0.0055,0.013,0.0055);
        float shape=cloudNoiseStable(q)*0.72+cloudNoiseStable(q*2.03+vec3(9.1,2.7,17.3))*0.28;
#if CLOUD_STYLE == 1
        // Rectangular Minecraft Earth clusters, anchored in world space.
        vec2 cell=floor(p.xz/48.0), local=fract(p.xz/48.0)-0.5;
        float seed=hash2(cell);
        shape=mix(0.0,0.85,step(seed,coverage))*
            (1.0-smoothstep(0.30,0.47,max(abs(local.x),abs(local.y))));
#elif CLOUD_STYLE == 2
        shape=cloudNoiseStable(vec3(p.xz*0.009,0.0));
        envelope*=0.55+0.45*cos((h-0.5)*12.56637)*cos((h-0.5)*12.56637);
#elif CLOUD_STYLE == 3
        shape=cloudNoiseStable(q*0.65)*0.8+cloudNoiseStable(q*1.3+7.0)*0.2;
#endif
        float density=smoothstep(0.76-coverage*0.48,0.90-coverage*0.48,shape)*envelope;
        float alpha=1.0-exp(-density*stepLength*0.028);
        alpha*=1.0-smoothstep(CLOUD_DISTANCE*0.70,CLOUD_DISTANCE,t);
        float shade=mix(0.46,1.0,h)*(1.0-density*0.17);
        accum+=(1.0-opacity)*alpha*bright*shade;
        opacity+=(1.0-opacity)*alpha;
        if (opacity>0.99) break;
    }
    return vec4(accum,opacity);
#endif
}
