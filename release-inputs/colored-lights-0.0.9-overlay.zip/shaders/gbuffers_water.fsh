#version 330 compatibility

#define WATER_STYLE 0 // [0 1 2] Natural / Clear / Vanilla
#define WATER_WAVINESS 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0]
#define WATER_WAVES 1 // [0 1 2] 0=calm, 1=natural, 2=windy
#define WATER_REFLECTION 0.70 // [0.35 0.55 0.70 0.85 1.0 0.90]
#define WATER_TINT_R 0.05 // [0.0 0.05 0.10 0.25 0.50 0.75 1.0]
#define WATER_TINT_G 0.28 // [0.0 0.05 0.10 0.28 0.50 0.75 1.0]
#define WATER_TINT_B 0.30 // [0.0 0.05 0.10 0.30 0.50 0.75 1.0]
#define WATER_TINT_STRENGTH 0.0 // [0.0 0.25 0.50 0.75 1.0]
#define WATER_OPACITY 1.0 // [0.5 0.75 1.0 1.25]

uniform sampler2D gtexture;
#include "/lib/strict_lighting.glsl"
uniform sampler2D depthtex1;
uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;
uniform float frameTimeCounter;
uniform vec3 sunPosition;
uniform vec3 skyColor;
uniform float rainStrength;
uniform mat4 gbufferModelView;

in vec2 texcoord;
in vec2 lightUV;
in vec4 glcolor;
in vec3 waterWorldPos;
in vec3 waterViewPos;
in vec3 waterNormal;
flat in float isWater;

float linearDepth(float d) {
    return (2.0 * near * far) / (far + near - (d * 2.0 - 1.0) * (far - near));
}

void main() {
    vec4 texel = texture(gtexture, texcoord) * glcolor;
    if (isWater < 0.5) {
        texel.rgb *= mubbleSurfaceLight(lightUV);
        gl_FragData[0] = texel;
        return;
    }

    vec3 p = waterWorldPos;
    float t = frameTimeCounter;
    // Independent wave trains travel in three world-space directions.
    // Their derivatives form a continuously changing liquid surface normal.
    vec2 d0 = normalize(vec2(0.91, 0.42));
    vec2 d1 = normalize(vec2(-0.78, 0.62));
    vec2 d2 = normalize(vec2(0.24, -0.97));
    float a = dot(p.xz, d0) * 1.35 - t * 1.55;
    float b = dot(p.xz, d1) * 2.15 - t * 1.90;
    float c = dot(p.xz, d2) * 4.80 - t * 2.60;
    vec2 slope = d0 * cos(a) * 0.12 + d1 * cos(b) * 0.09 + d2 * cos(c) * 0.035;
    float waveStrength = clamp(float(WATER_WAVES), 0.0, 1.0)*WATER_WAVINESS;
    waveStrength *= 1.0 + 0.40 * max(float(WATER_WAVES - 1), 0.0);
    vec3 waveSlope = mat3(gbufferModelView) * vec3(-slope.x, 0.0, -slope.y);
    vec3 normal = normalize(waterNormal + waveSlope * waveStrength*abs(waterNormal.y));
    vec3 viewDir = normalize(-waterViewPos);
    float ndv = max(dot(normal, viewDir), 0.0);
    float fresnel = 0.025 + 0.975 * pow(1.0 - ndv, 5.0);

    // A translucent water body lets the already rendered riverbed remain visible.
    vec3 deep = vec3(0.015, 0.16, 0.21);
    vec3 shallow = vec3(0.045, 0.28, 0.30);
    vec2 screenUV = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    float bedDepth = linearDepth(texture(depthtex1, screenUV).r);
    float surfaceDepth = linearDepth(gl_FragCoord.z);
    float thickness = max(0.0, bedDepth - surfaceDepth);
    float shallowFactor = 1.0 - smoothstep(0.25, 8.0, thickness);
    vec3 absorption = mix(deep, shallow, shallowFactor);
    vec3 tint = vec3(WATER_TINT_R, WATER_TINT_G, WATER_TINT_B);
    vec3 waterBody = mix(mix(absorption, tint, WATER_TINT_STRENGTH), texel.rgb,
                         0.14 * (1.0 - WATER_TINT_STRENGTH));

    vec3 sky = max(skyColor, vec3(0.08, 0.12, 0.17));
    vec3 reflection = mix(sky * vec3(0.72, 0.89, 1.08), vec3(0.62, 0.76, 0.88), 0.16);
    vec3 sunDir = normalize(sunPosition);
    vec3 reflectedView = reflect(-viewDir, normal);
    float glint = pow(max(dot(reflectedView, sunDir), 0.0), 96.0);
    glint *= (1.0 - rainStrength * 0.65) * (0.35 + 0.65 * WATER_REFLECTION);
    vec3 color = mix(waterBody, reflection, fresnel * WATER_REFLECTION);
    color += vec3(1.0, 0.87, 0.66) * glint * 0.7;

    // Soft rippled foam only where opaque blocks meet shallow water.
    float ripple = sin(a * 3.2 + b * 1.3) * sin(c * 1.7 - a * 0.9);
    float foam = (1.0 - smoothstep(0.05, 1.35, thickness)) * smoothstep(0.35, 0.85, ripple);
    color = mix(color, vec3(0.77, 0.91, 0.91), foam * 0.33);
    color *= mubbleSurfaceLight(lightUV);

    float alpha = mix(0.36, 0.84, 1.0 - exp(-thickness * 0.17));
    alpha = mix(alpha, 0.91, fresnel * WATER_REFLECTION);
#if WATER_STYLE == 1
    alpha*=0.55;
#elif WATER_STYLE == 2
    color=mix(texel.rgb,vec3(WATER_TINT_R,WATER_TINT_G,WATER_TINT_B),WATER_TINT_STRENGTH)*mubbleSurfaceLight(lightUV);
    alpha=texel.a;
#endif
    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), clamp(alpha * WATER_OPACITY, 0.18, 0.98));
}
