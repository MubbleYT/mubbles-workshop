#version 330 compatibility
/* DRAWBUFFERS:01234 */

// Shared Iris options with final.fsh: the chosen color applies to both
// world-space emitters and their screen-space glow.
#define LIGHT_COLOR_MODE 14 // [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14]
#define CUSTOM_LIGHT_R 1.0 // [0.0 0.25 0.50 0.75 1.0]
#define CUSTOM_LIGHT_G 0.50 // [0.0 0.25 0.50 0.75 1.0]
#define CUSTOM_LIGHT_B 0.25 // [0.0 0.25 0.50 0.75 1.0]

/*
const int colortex1Format = RGBA16F;
const int colortex2Format = RGBA32F;
*/
const bool colortex1Clear = true;
const bool colortex2Clear = true;
const bool colortex3Clear = true;
const bool colortex4Clear = true;
const vec4 colortex1ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex2ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex3ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex4ClearColor = vec4(0.0, 0.0, 0.0, 0.0);

uniform sampler2D gtexture;
uniform float frameTimeCounter;
#include "/lib/strict_lighting.glsl"

in vec2 texcoord;
in vec2 lightUV;
in vec4 glcolor;
flat in int emitterType;
flat in int oreType;
in vec3 emitterWorld;

vec3 sourcePalette(vec3 position) {
#if LIGHT_COLOR_MODE == 0
    return vec3(0.40, 1.00, 0.42);
#elif LIGHT_COLOR_MODE == 1
    return vec3(0.74, 0.42, 1.00);
#elif LIGHT_COLOR_MODE == 2
    return vec3(1.00, 0.88, 0.35);
#elif LIGHT_COLOR_MODE == 4
    return vec3(0.45, 0.72, 1.00);
#elif LIGHT_COLOR_MODE == 5
    return vec3(0.19, 0.35, 0.72);
#elif LIGHT_COLOR_MODE == 6
    return vec3(0.32);
#elif LIGHT_COLOR_MODE == 7
    return vec3(1.65);
#elif LIGHT_COLOR_MODE == 8
    return vec3(0.62, 0.35, 0.17);
#elif LIGHT_COLOR_MODE == 9
    return vec3(1.00, 0.24, 0.20);
#elif LIGHT_COLOR_MODE == 10
    return vec3(1.00, 0.58, 0.75);
#elif LIGHT_COLOR_MODE == 11
    return vec3(1.00, 0.15, 0.58);
#elif LIGHT_COLOR_MODE == 12
    vec3 cell = floor(position);
    float h = fract(sin(dot(cell, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
    return 0.45 + 0.55 * vec3(0.5 + 0.5 * sin(h * 6.283 + 0.0),
                               0.5 + 0.5 * sin(h * 6.283 + 2.1),
                               0.5 + 0.5 * sin(h * 6.283 + 4.2));
#elif LIGHT_COLOR_MODE == 13
    return vec3(CUSTOM_LIGHT_R, CUSTOM_LIGHT_G, CUSTOM_LIGHT_B);
#else
    return vec3(1.0);
#endif
}

void main() {
    vec4 color = texture(gtexture, texcoord) * glcolor;
    if (color.a<0.1) discard;
    
    // Mild warm tint
    color.rgb = mix(color.rgb, color.rgb * vec3(1.08, 0.97, 0.90), 0.35);
    // Separate texture color from Minecraft's baked light levels so colored
    // sources can illuminate dark blocks without painting a flat color over them.
    gl_FragData[4] = vec4(color.rgb, color.a);
    color.rgb *= mubbleSurfaceLight(lightUV);
    
    gl_FragData[0] = color;

    vec3 emission = vec3(0.0);
        float flicker = 1.0;
    if (emitterType == 5 || emitterType == 12) {
        float seed = fract(sin(dot(floor(emitterWorld), vec3(12.9898, 78.233, 37.719))) * 43758.5453);
        float t = frameTimeCounter + seed * 1000.0;
        float period = 5.0 + fract(sin(seed * 17.3) * 43758.5453) * 5.0;
        float localT = mod(t, period);
        float eventId = floor(t / period) + seed * 31.0;
        float shape = fract(sin(eventId * 3.7) * 43758.5453);
        float start = 0.5 + fract(sin(eventId * 9.1) * 43758.5453) * (period - 2.8);
        float dur = 1.2 + shape * 1.0;
        float u = (localT - start) / dur;
        if (u >= 0.0 && u <= 1.0) {
            float dimTarget = 0.72 + shape * 0.08;
            float brightTarget = 1.12 + shape * 0.10;
            if (u < 0.35) {
                float e = u / 0.35; e = e * e * (3.0 - 2.0 * e);
                flicker = mix(1.0, dimTarget, e);
            } else if (u < 0.55) {
                float e = (u - 0.35) / 0.20; e = e * e * (3.0 - 2.0 * e);
                flicker = mix(dimTarget, brightTarget, e);
            } else {
                float e = (u - 0.55) / 0.45; e = e * e * (3.0 - 2.0 * e);
                flicker = mix(brightTarget, 1.0, e);
            }
        } else {
            flicker = 0.97 + 0.03 * sin(t * 0.8 + seed * 20.0);
        }
        flicker = clamp(flicker, 0.70, 1.22);
    }
    if (emitterType == 1) emission = vec3(1.00, 0.12, 0.18);
    if (emitterType == 2) emission = vec3(0.15, 0.27, 1.00);
    if (emitterType == 3) emission = vec3(0.26, 0.76, 1.00);
    if (emitterType == 4) emission = vec3(1.00, 0.78, 0.33);
    if (emitterType == 5) emission = vec3(1.00, 0.50, 0.18) * flicker * 0.55;
    if (emitterType == 6) emission = vec3(1.00, 0.49, 0.80);
    if (emitterType == 7) emission = vec3(0.37, 1.00, 0.42);
    if (emitterType == 8)  emission = vec3(1.00, 0.55, 0.28);
    if (emitterType == 9)  emission = vec3(0.82, 0.48, 0.32);
    if (emitterType == 10) emission = vec3(0.48, 0.68, 0.36);
    if (emitterType == 11) emission = vec3(0.22, 0.72, 0.58);
    if (emitterType == 12) emission = vec3(1.00, 0.45, 0.12) * flicker * 0.35;
    if (emitterType == 13) emission = vec3(1.00, 0.85, 0.55);
#if LIGHT_COLOR_MODE != 14
    if (emitterType > 0) emission = sourcePalette(emitterWorld);
#endif

    // Glowing ores — soft surface emission (makes sense underground)
    if (oreType > 0) {
        vec3 oreCol = vec3(0.0);
        if (oreType == 1)  oreCol = vec3(0.25, 0.22, 0.20); // coal
        if (oreType == 2)  oreCol = vec3(0.55, 0.52, 0.48); // iron
        if (oreType == 3)  oreCol = vec3(0.75, 0.42, 0.22); // copper
        if (oreType == 4)  oreCol = vec3(1.00, 0.82, 0.28); // gold
        if (oreType == 5)  oreCol = vec3(1.00, 0.18, 0.12); // redstone
        if (oreType == 6)  oreCol = vec3(0.20, 0.35, 1.00); // lapis
        if (oreType == 7)  oreCol = vec3(0.35, 0.85, 1.00); // diamond
        if (oreType == 8)  oreCol = vec3(0.25, 1.00, 0.40); // emerald
        if (oreType == 9)  oreCol = vec3(0.95, 0.92, 0.88); // quartz
        if (oreType == 10) oreCol = vec3(0.55, 0.32, 0.18); // ancient debris
        if (oreType == 11) oreCol = vec3(0.70, 0.40, 1.00); // amethyst
        // Pulse slightly so veins feel alive
        float pulse = 0.85 + 0.15 * sin(frameTimeCounter * 1.7 + emitterWorld.x * 0.4 + emitterWorld.z * 0.3);
        float strength = (oreType == 1 || oreType == 2) ? 0.22 : 0.38;
        if (oreType == 7 || oreType == 8) strength = 0.48; // diamond / emerald stronger
        if (oreType == 5) strength = 0.42;
        color.rgb += oreCol * strength * pulse;
        // keep a bit of emission buffer for bloom pipelines
        emission = max(emission, oreCol * strength * 0.65 * pulse);
    }

    gl_FragData[1] = vec4(emission, (emitterType > 0 || oreType > 0) ? 1.0 : 0.0);
    gl_FragData[2] = (emitterType > 0 || oreType > 0) ? vec4(emitterWorld, 1.0) : vec4(0.0);
    // Vanilla block light already respects solid blocks and routes around
    // openings. Its level is a cheap conservative gate for extra RGB light.
    float blockLevel = clamp((lightUV.x - 1.0 / 32.0) * (32.0 / 30.0), 0.0, 1.0);
    float skyLevel = clamp((lightUV.y - 1.0 / 32.0) * (32.0 / 30.0), 0.0, 1.0);
    float daylight = smoothstep(-0.04, 0.15, sin(sunAngle * 6.2831853));
    float skyContribution = pow(skyLevel, 1.35) * daylight;
    gl_FragData[3] = vec4(blockLevel, skyContribution, 0.0, 1.0);
}
