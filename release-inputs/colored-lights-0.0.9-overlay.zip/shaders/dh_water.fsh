#version 330 compatibility
/* DRAWBUFFERS:0 */
#define WATER_TINT_R 0.05 // [0.0 0.05 0.10 0.25 0.50 0.75 1.0]
#define WATER_TINT_G 0.28 // [0.0 0.05 0.10 0.28 0.50 0.75 1.0]
#define WATER_TINT_B 0.30 // [0.0 0.05 0.10 0.30 0.50 0.75 1.0]
#define WATER_TINT_STRENGTH 0.0 // [0.0 0.25 0.50 0.75 1.0]
#define WATER_OPACITY 1.0 // [0.5 0.75 1.0 1.25]
#define WATER_STYLE 0 // [0 1 2] Natural / Clear / Vanilla
#define WATER_WAVINESS 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0]
#define WATER_WAVES 1 // [0 1 2]
in vec4 waterColor;
in vec3 distantWaterPos;
uniform float frameTimeCounter;

void main() {
    vec3 body=mix(vec3(0.025,0.20,0.27),waterColor.rgb,0.40);
    body=mix(body,vec3(WATER_TINT_R,WATER_TINT_G,WATER_TINT_B),WATER_TINT_STRENGTH);
    float waves=sin(dot(distantWaterPos.xz,vec2(0.19,0.11))-frameTimeCounter*0.9)*
                sin(dot(distantWaterPos.xz,vec2(-0.12,0.16))-frameTimeCounter*0.7);
    body+=vec3(0.015,0.02,0.025)*waves*WATER_WAVINESS*float(WATER_WAVES);
    float opacity=0.65;
#if WATER_STYLE == 1
    opacity=0.36;
#elif WATER_STYLE == 2
    body=mix(waterColor.rgb,vec3(WATER_TINT_R,WATER_TINT_G,WATER_TINT_B),WATER_TINT_STRENGTH);
    opacity=waterColor.a;
#endif
    gl_FragData[0]=vec4(clamp(body,0.0,1.0),clamp(opacity*WATER_OPACITY,0.18,0.98));
}
