#version 330 compatibility
#define RAIN_SLANT 0.28 // [0.0 0.14 0.28 0.32 0.42]
#define SNOW_SLANT 0.10 // [0.0 0.05 0.10 0.20 0.30]
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform int biome_precipitation;
out vec2 texcoord;
out vec4 glcolor;
void main() {
    texcoord=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
    glcolor=gl_Color;
    vec4 view=gl_ModelViewMatrix*gl_Vertex;
    vec3 world=(gbufferModelViewInverse*view).xyz;
    float angle=biome_precipitation==2?SNOW_SLANT:RAIN_SLANT;
    // Shear relative to the camera's world-height plane, independent of yaw and UV scrolling.
    world.xz+=vec2(1.0,0.33)*world.y*angle;
    gl_Position=gbufferProjection*gbufferModelView*vec4(world,1.0);
}
