#version 330 compatibility

#define WIND_STRENGTH 0.80 // [0.0 0.30 0.50 0.65 0.80 1.0 1.25 1.5 0.60]

in vec2 mc_Entity;
in vec4 at_midBlock;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferModelView;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
out vec2 texcoord;
out vec2 lightUV;
out vec4 glcolor;
flat out int emitterType;
flat out int oreType;
out vec3 emitterWorld;

// Rigid rotation around X then Z (small angles, preserves shape)
vec3 rotateXZ(vec3 p, float ax, float az) {
    // Rotate around X
    float cx = cos(ax), sx = sin(ax);
    p = vec3(p.x, cx * p.y - sx * p.z, sx * p.y + cx * p.z);
    // Rotate around Z
    float cz = cos(az), sz = sin(az);
    p = vec3(cz * p.x - sz * p.y, sz * p.x + cz * p.y, p.z);
    return p;
}

void main() {
    vec4 vertex = gl_Vertex;
    float id = mc_Entity.x;

    if (WIND_STRENGTH > 0.0) {
        bool leaves = abs(id - 10002.0) < 0.5;
        bool grass = abs(id - 10003.0) < 0.5;
        if (leaves || grass) {
            vec3 world = (gbufferModelViewInverse * (gl_ModelViewMatrix * vertex)).xyz + cameraPosition;
            float tip = clamp(0.5 - at_midBlock.y / 64.0, 0.0, 1.0);
            float phase = dot(world.xz, vec2(0.27, 0.19)) + frameTimeCounter * (1.0 + rainStrength * 0.9);
            float gust = 0.72 + 0.28 * sin(frameTimeCounter * 0.31 + world.x * 0.027);
            float amount = WIND_STRENGTH * gust * (1.0 + rainStrength * 0.65);
            amount *= grass ? 0.14 * tip : 0.06 * (0.5 + 0.5 * tip);
            vertex.xz += amount * vec2(sin(phase), cos(phase * 0.81 + 0.5));
        }
    }

    // Hanging lantern / chain: rigid pendulum from top of block (no mesh morphing)
    bool isChain = abs(id - 11014.0) < 0.5;
    bool isHangLantern = abs(id - 11015.0) < 0.5 || abs(id - 11016.0) < 0.5 || abs(id - 11021.0) < 0.5;
    if (isChain || isHangLantern) {
        // World-space vertex
        vec4 viewPos = gl_ModelViewMatrix * vertex;
        vec3 world = (gbufferModelViewInverse * viewPos).xyz + cameraPosition;

        // Block center from midBlock attribute
        vec3 blockCenter = world + at_midBlock.xyz / 64.0;
        // Pivot = top center of the block (where chain/lantern hangs from)
        vec3 pivot = vec3(floor(blockCenter.x) + 0.5, floor(blockCenter.y) + 1.0, floor(blockCenter.z) + 0.5);

        float h = fract(sin(dot(floor(blockCenter), vec3(12.9898, 78.233, 37.719))) * 43758.5453);
        float t = frameTimeCounter;
        float wind = (0.55 + 0.65 * WIND_STRENGTH) * (1.0 + rainStrength * 0.8);

        // Ambient swing angles (radians); keep lantern motion visible at normal wind.
        float baseAmp = isChain ? 0.10 : 0.17;
        baseAmp *= wind;

        // Player proximity: boost angle when walking into it
        vec2 toPlayer = cameraPosition.xz - pivot.xz;
        float dist = length(toPlayer);
        float near = 1.0 - smoothstep(0.5, 2.0, dist);
        near *= near;

        float amp = baseAmp * (1.0 + near * 2.5);

        float angleX = (sin(t * 1.15 + h * 20.0) * 0.55 + sin(t * 0.47 + h * 9.0) * 0.25) * amp;
        float angleZ = (cos(t * 0.93 + h * 14.0) * 0.45 + sin(t * 0.61 + h * 11.0) * 0.20) * amp;

        // Push away from player when close
        if (near > 0.01 && dist > 0.01) {
            vec2 push = normalize(toPlayer);
            float impact = near * (0.08 + 0.06 * sin(t * 7.0 + h * 4.0));
            angleX += push.y * impact;
            angleZ += -push.x * impact;
        }

        // Rigid rotate entire mesh around pivot
        vec3 local = world - pivot;
        local = rotateXZ(local, angleX, angleZ);
        vec3 newWorld = pivot + local;

        // Convert back to model/view space for projection
        vec3 newRelative = newWorld - cameraPosition;
        vec4 newView = gbufferModelView * vec4(newRelative, 1.0);
        gl_Position = gl_ProjectionMatrix * newView;
    } else {
        gl_Position = gl_ModelViewProjectionMatrix * vertex;
    }

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lightUV = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
    emitterType = 0;
    oreType = 0;
    if ((id >= 11001.0 && id <= 11017.0) || (id >= 11021.0 && id <= 11024.0)) {
        emitterType = int(id - 11000.0 + 0.5);
        if (emitterType == 15) emitterType = 5;
        if (emitterType == 16) emitterType = 2;
        if (emitterType == 21) emitterType = 11;
        if (emitterType == 22) emitterType = 5;
        if (emitterType == 23) emitterType = 2;
        if (emitterType == 24) emitterType = 11;
    }
    if (id >= 12001.0 && id <= 12011.0) {
        oreType = int(id - 12000.0 + 0.5);
    }
    vec4 center = gl_ModelViewMatrix * vec4(vertex.xyz + at_midBlock.xyz / 64.0, 1.0);
    emitterWorld = (gbufferModelViewInverse * center).xyz + cameraPosition;
}
