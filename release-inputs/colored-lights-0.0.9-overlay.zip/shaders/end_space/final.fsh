#version 430 compatibility

uniform float currentPlayerHealth;
layout(std430, binding = 0) buffer NearbyLightsFX {
    uint count;
    uint seen[8192];
    vec4 positions[256];
    vec4 colors[256];
    float screenWet;
    float pad0;
    vec4 lingeringSmoke[16];
    vec4 smokeBirth[16];
} fxLights;


// Values in brackets become controls in Iris Shader Pack Settings.
#define CLOUD_STEPS 12 // [0 4 6 12 16 20 24] 0=off, 6=fast, 12=default, 24=cinema
#define CLOUD_STYLE 0 // [0 1 2 3] Volumetric, Minecraft Earth, Layered Vanilla, Dungeons 2
#define CLOUD_COVERAGE 0.52 // [0.30 0.42 0.52 0.62 0.72 0.48 0.58]
#define GODRAY_SAMPLES 8 // [0 4 8 12]
#define STORM_FOG 1 // [0 1 2] 0=off, 1=natural, 2=heavy
#define LIGHT_COLOR_MODE 14 // [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14]
#define CUSTOM_LIGHT_R 1.0 // [0.0 0.25 0.50 0.75 1.0]
#define CUSTOM_LIGHT_G 0.50 // [0.0 0.25 0.50 0.75 1.0]
#define CUSTOM_LIGHT_B 0.25 // [0.0 0.25 0.50 0.75 1.0]
#define VHS_MODE 0 // [0 1 2] 0=off, 1=4:3, 2=16:9
#define CAMERA_EXPOSURE 0.0 // [-2.0 -1.0 -0.5 0.0 0.5 1.0 2.0]
#define CAMERA_GAMMA 1.0 // [0.75 0.85 1.0 1.15 1.3]
#define CAMERA_SHARPNESS 0.0 // [0.0 0.25 0.5 0.75 1.0]
#define CAMERA_ZOOM 1.0 // [1.0 1.25 1.5 2.0 3.0]
#define CAMERA_FOCUS 0.0 // [0.0 2.0 4.0 8.0 16.0 32.0]
#define CAMERA_FILM 0 // [0 1 2] off, 35mm, Super 8
#define CAMERA_GRAIN 0.0 // [0.0 0.015 0.03 0.06 0.10]
#define CAMERA_LENS 0.0 // [0.0 0.04 0.08 0.12]
#define CAMERA_CHROMATIC 0.0 // [0.0 0.5 1.0 2.0 3.0] pixel offset at frame edge
#define CAMERA_BARS 0 // [0 1 2] off, 1.85:1, 2.39:1
#define BLOOD_EFFECT 1 // [0 1 2] Off / Subtle / Strong
#define NETHER_HEAT 1 // [0 1 2] 0=off, 1=hot, 2=blazing
#define BLOOM 1 // [0 1 2] 0=off, 1=soft, 2=strong
#define BLOOM_STRENGTH 0.24 // [0.0 0.12 0.24 0.36 0.42 0.48]
#define COLOR_STRENGTH 0.60 // [0.0 0.25 0.60 0.85 1.0]
#define CONTRAST 1.06 // [0.95 1.0 1.06 1.12 1.20]
#define SATURATION 1.08 // [0.85 1.0 1.08 1.16 1.25]
#define VIGNETTE 0.10 // [0.0 0.05 0.10 0.16 0.22]

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D endEarth;
uniform sampler2D endMars;
uniform sampler2D endJupiter;
uniform sampler2D endSaturn;
uniform sampler2D endNeptune;
uniform sampler2D endDesert;
uniform sampler2D endIce;
uniform sampler2D endForest;
uniform sampler2D endVolcanic;
uniform sampler2D endOcean;
uniform sampler2D endDeathStar;
uniform sampler2D endDestroyer;
uniform sampler2D endRing;
uniform sampler2D endIterationRingMap;
#define END_PLANET 0 // [0 6] Earth / Venus
#define END_SKY_STYLE 0 // [0 1 2 3 4 5 6 7 8] Milky Way / Deep Space / Nebula / Violet / Asteroids / Black Hole / Black / Supernova / IterationT Inspired
#define END_EARTH_SCALE 3.0 // [0.3 0.6 1.0 1.5 2.0 3.0 5.0 10.0]
#define END_PLANET_BRIGHTNESS 0.75 // [0.25 0.50 0.75 1.0 1.25]
#define END_GALAXY_BRIGHTNESS 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define END_STAR_BRIGHTNESS 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define END_BLACK_HOLE_LIGHT 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5]
uniform sampler2D colortex4;
layout(std430, binding = 1) buffer SceneVoxels {
    uint occupiedCount;
    uint bits[65536];
} voxels;
uniform sampler2D depthtex0;
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
uniform float dhNearPlane;
uniform float dhFarPlane;
#endif
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferProjection;
uniform float near;
uniform float far;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 skyColor;
uniform float frameTimeCounter;
uniform float frameTime;
uniform float rainStrength;
uniform float wetness;
uniform float thunderStrength;
uniform float temperature;
uniform float rainfall;
uniform int biome_precipitation;
uniform bool hasSkylight;
uniform bool hasCeiling;
uniform vec3 fogColor;
uniform int isEyeInWater;
uniform float viewWidth;
uniform float viewHeight;

in vec2 texcoord;

float weatherStrength() {
    return clamp(max(rainStrength, max(thunderStrength, wetness * 0.45)), 0.0, 1.0);
}

vec3 viewRay(vec2 uv) {
    vec4 view = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, 1.0, 1.0);
    return normalize(view.xyz / view.w);
}

float linearDepth(float d) {
    return (2.0 * near * far) / (far + near - (d * 2.0 - 1.0) * (far - near));
}

float sceneDepth(vec2 uv) {
    float vanilla = texture(depthtex0, uv).r;
#ifdef DISTANT_HORIZONS
    if (vanilla > 0.99999) return texture(dhDepthTex0, uv).r;
#endif
    return vanilla;
}

float sceneDistance(vec2 uv) {
    float vanilla = texture(depthtex0, uv).r;
    if (vanilla < 0.99999) return linearDepth(vanilla);
#ifdef DISTANT_HORIZONS
    float distant = texture(dhDepthTex0, uv).r;
    if (distant < 0.99999)
        return (2.0 * dhNearPlane * dhFarPlane) /
               (dhFarPlane + dhNearPlane - (distant * 2.0 - 1.0) * (dhFarPlane - dhNearPlane));
#endif
    return 220.0;
}

float hash2(vec2 p) {
    p = fract(p * vec2(0.1031, 0.1030));
    p += dot(p, p.yx + 33.33);
    return fract((p.x + p.y) * p.x);
}

float steamNoise(vec2 p) {
    vec2 cell = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float low = mix(hash2(cell), hash2(cell + vec2(1.0, 0.0)), f.x);
    float high = mix(hash2(cell + vec2(0.0, 1.0)), hash2(cell + vec2(1.0)), f.x);
    return mix(low, high, f.y);
}

vec3 sunDisc(vec2 uv, float weather) {
    vec3 sunWorld = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    if (sunWorld.y <= 0.0) return vec3(0.0);
    float alignment = dot(viewRay(uv), normalize(sunPosition));
    float radius = 0.0090;
    float edge = max(fwidth(alignment) * 1.3, 0.000012);
    float disc = smoothstep(cos(radius) - edge, cos(radius) + edge, alignment);
    float halo = pow(max(alignment, 0.0), 620.0) * 0.30;
    vec3 sunlight = mix(vec3(1.0, 0.55, 0.30), vec3(1.0, 0.95, 0.82), smoothstep(0.02, 0.36, sunWorld.y));
    return sunlight * (disc * 0.92 + halo) * (1.0 - weather * 0.94);
}

#if GODRAY_SAMPLES > 0
vec3 sunShafts(vec2 uv, float weather) {
    vec4 projected = gbufferProjection * vec4(sunPosition, 1.0);
    if (projected.w <= 0.0) return vec3(0.0);
    vec2 sunUV = projected.xy / projected.w * 0.5 + 0.5;
    if (any(lessThan(sunUV, vec2(-0.15))) || any(greaterThan(sunUV, vec2(1.15)))) return vec3(0.0);
    float skyOpen = 0.0;
    for (int i = 0; i < GODRAY_SAMPLES; ++i) {
        vec2 sampleUV = mix(uv, sunUV, (float(i) + 0.5) / float(GODRAY_SAMPLES));
        if (all(greaterThanEqual(sampleUV, vec2(0.0))) && all(lessThanEqual(sampleUV, vec2(1.0))))
            skyOpen += step(0.99999, sceneDepth(sampleUV));
    }
    float visible = skyOpen / float(GODRAY_SAMPLES);
    float distanceFade = exp(-length((uv - sunUV) * vec2(viewWidth / viewHeight, 1.0)) * 3.7);
    vec3 sunWorld = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    float daylight = smoothstep(0.01, 0.19, sunWorld.y);
    return vec3(1.0, 0.83, 0.60) * visible * distanceFade * daylight * (1.0 - weather) * 0.20;
}
#endif


#if CLOUD_STYLE == 0 && CLOUD_STEPS > 0
float cloudHash(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

float cloudNoise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = cloudHash(i + vec3(0.0, 0.0, 0.0));
    float n100 = cloudHash(i + vec3(1.0, 0.0, 0.0));
    float n010 = cloudHash(i + vec3(0.0, 1.0, 0.0));
    float n110 = cloudHash(i + vec3(1.0, 1.0, 0.0));
    float n001 = cloudHash(i + vec3(0.0, 0.0, 1.0));
    float n101 = cloudHash(i + vec3(1.0, 0.0, 1.0));
    float n011 = cloudHash(i + vec3(0.0, 1.0, 1.0));
    float n111 = cloudHash(i + vec3(1.0, 1.0, 1.0));
    float a = mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y);
    float b = mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y);
    return mix(a, b, f.z);
}

float cloudDensity(vec3 pos) {
    vec3 q = pos * vec3(0.006, 0.016, 0.006);
    q.xz += vec2(frameTimeCounter * (0.003 + weatherStrength() * 0.004),
                 frameTimeCounter * (0.0016 + weatherStrength() * 0.002));
    float broad = cloudNoise(q);
    float detail = cloudNoise(q * 2.35 + vec3(19.3, 2.7, 8.4));
    float shape = broad * 0.75 + detail * 0.25;
    float h = clamp((pos.y - 156.0) / 76.0, 0.0, 1.0);
    float envelope = smoothstep(0.0, 0.17, h) * (1.0 - smoothstep(0.74, 1.0, h));
    float storm = weatherStrength();
    float coverage = mix(CLOUD_COVERAGE * 0.75, 0.95, smoothstep(0.0, 1.0, storm));
    float threshold = 0.72 - coverage * 0.28;
    float billow = smoothstep(threshold, threshold + 0.14, shape);
    return max(billow, storm * 0.68) * envelope;
}

vec4 volumeClouds(vec2 uv) {
    vec3 ray = normalize((gbufferModelViewInverse * vec4(viewRay(uv), 0.0)).xyz);
    if (abs(ray.y) < 0.018) return vec4(0.0);
    float lo = (156.0 - cameraPosition.y) / ray.y;
    float hi = (232.0 - cameraPosition.y) / ray.y;
    float start = max(0.0, min(lo, hi));
    float end = min(2400.0, max(lo, hi));
    if (end <= start) return vec4(0.0);
    float stepSize = (end - start) / float(CLOUD_STEPS);
    vec3 lightDir = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    float day = smoothstep(-0.15, 0.20, lightDir.y);
    vec3 bright = mix(vec3(0.20, 0.26, 0.37), vec3(1.0, 0.98, 0.92), day);
    float storm = weatherStrength();
    bright = mix(bright, vec3(0.12, 0.15, 0.19), storm * 0.90);
    vec3 accum = vec3(0.0);
    float opacity = 0.0;
    for (int i = 0; i < CLOUD_STEPS; ++i) {
        float distanceAlongRay = start + (float(i) + 0.5) * stepSize;
        vec3 samplePos = cameraPosition + ray * distanceAlongRay;
        float density = cloudDensity(samplePos);
        float shade = mix(0.48, 1.0, clamp((samplePos.y - 156.0) / 76.0, 0.0, 1.0));
        shade *= 1.0 - density * (0.16 + storm * 0.28);
        float localAlpha = 1.0 - exp(-density * stepSize * 0.026);
        localAlpha *= 1.0 - smoothstep(1400.0, 2400.0, distanceAlongRay);
        accum += (1.0 - opacity) * localAlpha * bright * shade;
        opacity += (1.0 - opacity) * localAlpha;
        if (opacity > 0.985) break;
    }
    return vec4(accum, opacity);
}
#endif

#if CLOUD_STYLE == 1
float earthCloudBox(vec2 p, vec2 halfSize) {
    vec2 d = abs(p) - halfSize;
    return length(max(d, vec2(0.0))) + min(max(d.x, d.y), 0.0);
}

float earthCloudLayer(vec2 worldPos, float coverage) {
    vec2 grid = worldPos * 0.010;
    vec2 tile = floor(grid);
    float shape = 1.0;
    for (int x = -1; x <= 1; ++x) {
        for (int y = -1; y <= 1; ++y) {
            vec2 cell = tile + vec2(float(x), float(y));
            float seed = hash2(cell + 3.1);
            if (seed > coverage) continue;
            vec2 center = cell + 0.30 + 0.40 * vec2(hash2(cell + 21.7), hash2(cell + 64.3));
            vec2 q = grid - center;
            float width = mix(0.18, 0.34, hash2(cell + 9.4));
            float d = earthCloudBox(q, vec2(width, 0.17));
            d = min(d, earthCloudBox(q - vec2(width * 0.68, 0.07), vec2(width * 0.72, 0.13)));
            d = min(d, earthCloudBox(q + vec2(width * 0.60, 0.05), vec2(width * 0.64, 0.14)));
            shape = min(shape, d);
        }
    }
    return 1.0 - smoothstep(-max(fwidth(shape), 0.008), max(fwidth(shape), 0.008), shape);
}

vec4 minecraftEarthClouds(vec2 uv) {
    vec3 ray = normalize((gbufferModelViewInverse * vec4(viewRay(uv), 0.0)).xyz);
    if (ray.y <= 0.015 || cameraPosition.y >= 215.0) return vec4(0.0);
    float storm = weatherStrength();
    float coverage = mix(CLOUD_COVERAGE * 0.72, 0.98, storm);
    vec2 wind = frameTimeCounter * vec2(0.45, 0.22) * (1.0 + storm * 0.9);
    float nearT = min((176.0 - cameraPosition.y) / ray.y, 2000.0);
    float farT = min((205.0 - cameraPosition.y) / ray.y, 2000.0);
    vec2 nearPos = cameraPosition.xz + ray.xz * nearT + wind;
    vec2 farPos = cameraPosition.xz + ray.xz * farT + wind * 1.27;
    float back = farT > 0.0 ? earthCloudLayer(farPos + vec2(71.0, -42.0), coverage * 0.54) : 0.0;
    float front = nearT > 0.0 ? earthCloudLayer(nearPos, coverage) : 0.0;
    float opacity = clamp(front * 0.90 + back * (1.0 - front) * 0.68, 0.0, 1.0);
    vec3 sunWorld = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    float daylight = smoothstep(-0.16, 0.21, sunWorld.y);
    vec3 white = mix(vec3(0.28, 0.32, 0.42), vec3(1.0, 0.98, 0.94), daylight);
    vec3 shaded = mix(white * 0.80, white, front);
    shaded = mix(shaded, vec3(0.13, 0.16, 0.19), storm * 0.90);
    return vec4(shaded * opacity, opacity);
}
#endif


#if CLOUD_STYLE == 2 || CLOUD_STYLE == 3
// Layered vanilla-style planes + Minecraft Dungeons 2 pillowy layers
float layerCloudNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = fract(sin(dot(i, vec2(127.1, 311.7))) * 43758.5453);
    float b = fract(sin(dot(i + vec2(1.0, 0.0), vec2(127.1, 311.7))) * 43758.5453);
    float c = fract(sin(dot(i + vec2(0.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
    float d = fract(sin(dot(i + vec2(1.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float layerFbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; ++i) {
        v += a * layerCloudNoise(p);
        p = p * 2.05 + vec2(13.1, 7.7);
        a *= 0.5;
    }
    return v;
}

vec4 layeredVanillaClouds(vec2 uv) {
    vec3 ray = normalize((gbufferModelViewInverse * vec4(viewRay(uv), 0.0)).xyz);
    if (ray.y <= 0.02) return vec4(0.0);
    float storm = weatherStrength();
    float coverage = mix(CLOUD_COVERAGE * 0.70, 0.95, storm);
    vec3 sunWorld = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    float daylight = smoothstep(-0.12, 0.22, sunWorld.y);
    vec3 base = mix(vec3(0.25, 0.28, 0.38), vec3(0.98, 0.97, 0.95), daylight);
    base = mix(base, vec3(0.18, 0.20, 0.24), storm * 0.85);

    float totalA = 0.0;
    vec3 totalC = vec3(0.0);
    // Three height layers
    float heights[3];
    heights[0] = 165.0; heights[1] = 188.0; heights[2] = 210.0;
    float scales[3];
    scales[0] = 0.012; scales[1] = 0.009; scales[2] = 0.007;
    float speeds[3];
    speeds[0] = 0.35; speeds[1] = 0.55; speeds[2] = 0.22;
    for (int L = 0; L < 3; ++L) {
        float tHit = (heights[L] - cameraPosition.y) / ray.y;
        if (tHit <= 0.0 || tHit > 2200.0) continue;
        vec2 pos = cameraPosition.xz + ray.xz * tHit;
        pos += frameTimeCounter * speeds[L] * vec2(0.4, 0.25);
        float n = layerFbm(pos * scales[L]);
        float dens = smoothstep(1.0 - coverage, 1.0 - coverage + 0.18, n);
        dens *= 0.55 + 0.45 * float(2 - L) / 2.0;
        float a = dens * (1.0 - totalA);
        totalC += base * (0.85 + 0.15 * float(L)) * a;
        totalA += a;
    }
    return vec4(totalC, clamp(totalA, 0.0, 1.0));
}

vec4 dungeonsClouds(vec2 uv) {
    // Minecraft Dungeons 2: bold, soft, stacked rounded masses
    vec3 ray = normalize((gbufferModelViewInverse * vec4(viewRay(uv), 0.0)).xyz);
    if (ray.y <= 0.02) return vec4(0.0);
    float storm = weatherStrength();
    float coverage = mix(CLOUD_COVERAGE * 0.78, 0.98, storm);
    vec3 sunWorld = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    float daylight = smoothstep(-0.12, 0.22, sunWorld.y);
    vec3 white = mix(vec3(0.30, 0.34, 0.48), vec3(1.0, 0.99, 0.96), daylight);
    white = mix(white, vec3(0.14, 0.16, 0.20), storm * 0.9);

    float totalA = 0.0;
    vec3 totalC = vec3(0.0);
    float heights[3];
    heights[0] = 170.0; heights[1] = 195.0; heights[2] = 218.0;
    for (int L = 0; L < 3; ++L) {
        float tHit = (heights[L] - cameraPosition.y) / ray.y;
        if (tHit <= 0.0 || tHit > 2000.0) continue;
        vec2 pos = cameraPosition.xz + ray.xz * tHit;
        pos += frameTimeCounter * (0.30 + float(L) * 0.12) * vec2(0.5, 0.2);
        // Large soft blobs
        float n = layerFbm(pos * 0.0045);
        n = pow(n, 1.35);
        float dens = smoothstep(1.0 - coverage, 1.0 - coverage + 0.22, n);
        // Extra rounded edge
        dens *= dens;
        dens *= mix(0.5, 1.0, float(2 - L) / 2.0);
        float shade = 0.75 + 0.25 * dens;
        float a = dens * (1.0 - totalA) * 0.95;
        totalC += white * shade * a;
        totalA += a;
    }
    return vec4(totalC, clamp(totalA, 0.0, 1.0));
}
#endif


vec3 paletteColor(vec2 uv) {
#if LIGHT_COLOR_MODE == 0
    return vec3(0.40, 1.00, 0.42); // green
#elif LIGHT_COLOR_MODE == 1
    return vec3(0.74, 0.42, 1.00); // purple
#elif LIGHT_COLOR_MODE == 2
    return vec3(1.00, 0.88, 0.35); // yellow
#elif LIGHT_COLOR_MODE == 14
    return vec3(1.00); // white / neutral
#elif LIGHT_COLOR_MODE == 4
    return vec3(0.45, 0.72, 1.00); // blue
#elif LIGHT_COLOR_MODE == 5
    return vec3(0.19, 0.35, 0.72); // dark blue
#elif LIGHT_COLOR_MODE == 6
    return vec3(0.32); // dim
#elif LIGHT_COLOR_MODE == 7
    return vec3(1.65); // blinding
#elif LIGHT_COLOR_MODE == 8
    return vec3(0.62, 0.35, 0.17); // brown
#elif LIGHT_COLOR_MODE == 9
    return vec3(1.00, 0.24, 0.20); // red
#elif LIGHT_COLOR_MODE == 10
    return vec3(1.00, 0.58, 0.75); // pink
#elif LIGHT_COLOR_MODE == 11
    return vec3(1.00, 0.15, 0.58); // hot pink
#elif LIGHT_COLOR_MODE == 12
    float d = texture(depthtex0, uv).r;
    vec4 world = gbufferModelViewInverse * (gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0));
    vec3 p = world.xyz / world.w + cameraPosition;
    float h = hash2(floor(p.xz * 0.25) + floor(p.y * 0.25) * 0.73);
    return 0.4 + 0.6 * vec3(0.5 + 0.5 * sin(h * 6.283 + 0.0),
                             0.5 + 0.5 * sin(h * 6.283 + 2.1),
                             0.5 + 0.5 * sin(h * 6.283 + 4.2));
#elif LIGHT_COLOR_MODE == 13
    return vec3(CUSTOM_LIGHT_R, CUSTOM_LIGHT_G, CUSTOM_LIGHT_B);
#else
    return vec3(1.0); // native source colors
#endif
}

float luminance(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

vec2 cameraLensUV(vec2 uv) {
    vec2 q = (uv - 0.5) * vec2(viewWidth / viewHeight, 1.0);
    float r2 = dot(q, q);
    return clamp(0.5 + (uv - 0.5) * (1.0 - CAMERA_LENS * r2), vec2(0.001), vec2(0.999));
}

vec3 cameraFilmFinish(vec3 color, vec2 uv) {
    float frame = floor(frameTimeCounter * 24.0);
    vec2 pixel = floor(uv * vec2(viewWidth, viewHeight));
    float grain = hash2(pixel + vec2(frame * 17.0, frame * 31.0)) - 0.5;
    float amount = CAMERA_GRAIN + float(CAMERA_FILM) * 0.012;
    color += grain * amount * (0.60 + 0.40 * sqrt(max(luminance(color), 0.0)));
#if CAMERA_FILM > 0
    // Subtle exposure pulse and intermittent emulsion dust.
    float pulse = sin(frame * 1.37) * (CAMERA_FILM == 2 ? 0.016 : 0.006);
    color *= 1.0 + pulse;
    float speck = hash2(floor(pixel / 2.0) + vec2(frame * 4.0, frame * 9.0));
    float dust = step(CAMERA_FILM == 2 ? 0.99955 : 0.99985, speck);
    color *= 1.0 - dust * (CAMERA_FILM == 2 ? 0.42 : 0.22);
#if CAMERA_FILM == 2
    float scratchX = hash2(vec2(floor(frame / 11.0), 35.0));
    float scratch = 1.0 - smoothstep(0.0, 1.4, abs(uv.x * viewWidth - scratchX * viewWidth));
    color += vec3(0.025, 0.020, 0.012) * scratch * step(0.83, hash2(vec2(floor(frame / 11.0), 12.0)));
#endif
#endif
    return color;
}

#if VHS_MODE > 0
vec2 tapeUV(vec2 uv) {
    float line = floor(uv.y * viewHeight * 0.5);
    float noise = hash2(vec2(line, floor(frameTimeCounter * 24.0)));
    float wobble = sin(uv.y * viewHeight * 0.16 + frameTimeCounter * 11.0) * 0.00028;
    float tracking = exp(-abs(uv.y - fract(frameTimeCounter * 0.115)) * 115.0);
    float offset = wobble + (noise - 0.5) * 0.0010 + tracking * 0.0028;
    return clamp(uv + vec2(offset, 0.0), vec2(0.001), vec2(0.999));
}

vec3 tapeFinish(vec3 color, vec2 screenUV, vec2 imageUV) {
    float tracking = exp(-abs(screenUV.y - fract(frameTimeCounter * 0.115)) * 115.0);
    vec2 bleed = vec2((1.3 + tracking * 2.6) / viewWidth, 0.0);
    vec3 left = texture(colortex0, clamp(imageUV - bleed, vec2(0.001), vec2(0.999))).rgb;
    vec3 right = texture(colortex0, clamp(imageUV + bleed, vec2(0.001), vec2(0.999))).rgb;
    color.r = mix(color.r, left.r, 0.27);
    color.b = mix(color.b, right.b, 0.32);
    color = mix(vec3(luminance(color)), color, 0.77);

    float scanline = sin(screenUV.y * viewHeight * 3.14159265) * 0.034;
    float grain = hash2(floor(screenUV * vec2(viewWidth, viewHeight)) +
                        vec2(floor(frameTimeCounter * 24.0) * 17.0, 0.0));
    float dropout = step(0.9985, hash2(vec2(floor(screenUV.y * viewHeight),
                                            floor(frameTimeCounter * 18.0))));
    color = color * (0.965 + scanline - tracking * 0.12 - dropout * 0.18)
                  + (grain - 0.5) * 0.065;
    float edge = length((screenUV - 0.5) * vec2(viewWidth / viewHeight, 1.0));
    color *= 1.0 - smoothstep(0.30, 1.12, edge) * 0.18;
    return clamp(color, 0.0, 1.0);
}
#endif

#if BLOOM > 0
vec3 brightSample(vec2 uv) {
    vec2 sampleUV=clamp(uv,vec2(0.001),vec2(0.999));
    vec3 c=texture(colortex0,sampleUV).rgb;
    vec3 emission=texture(colortex1,sampleUV).rgb;
    float peak=max(max(c.r,c.g),c.b);
    float isWorld=1.0-step(0.99999,sceneDepth(sampleUV));
    return max(emission,c*smoothstep(0.92,1.10,peak)*0.35)*isWorld;
}
#endif

#include "/lib/end_sky.glsl"

#if END_SKY_STYLE == 8
bool iterationVoxelOccupied(ivec3 worldCell) {
    ivec3 cell = worldCell - ivec3(floor(cameraPosition)) + ivec3(64);
    if (any(lessThan(cell, ivec3(0))) || any(greaterThanEqual(cell, ivec3(128))))
        return false;
    uint bit = uint(cell.x) | (uint(cell.y) << 7u) | (uint(cell.z) << 14u);
    return (voxels.bits[bit >> 5u] & (1u << (bit & 31u))) != 0u;
}

vec3 iterationTerrainLight(vec2 uv, float rawDepth) {
    if (END_BLACK_HOLE_LIGHT <= 0.0) return vec3(0.0);
    vec4 albedo = texture(colortex4, uv);
    if (albedo.a < 0.25 || rawDepth >= 0.99999) return vec3(0.0);
    vec4 view = gbufferProjectionInverse *
        vec4(uv * 2.0 - 1.0, rawDepth * 2.0 - 1.0, 1.0);
    vec3 world = (gbufferModelViewInverse *
        vec4(view.xyz / view.w, 1.0)).xyz + cameraPosition;
    vec3 edgeX = dFdx(world);
    vec3 edgeY = dFdy(world);
    vec3 geometric = cross(edgeX, edgeY);
    if (dot(geometric, geometric) < 0.000001) return vec3(0.0);
    vec3 normal = normalize(geometric);
    if (dot(normal, cameraPosition - world) < 0.0) normal = -normal;
    vec3 sourceDirection = normalize(vec3(0.15, 0.34, -0.94));
    float diffuse = max(dot(normal, sourceDirection), 0.0);
    if (diffuse < 0.01 && normal.y <= 0.0) return vec3(0.0);

    // World-space opaque-block occupancy also sees roofs and pillars that are
    // hidden from the camera. Avoid testing the receiver's own block.
    float visibility = 1.0;
    if (voxels.occupiedCount > 0u) {
        ivec3 receiverCell = ivec3(floor(world));
        for (int i = 1; i <= 28; ++i) {
            ivec3 cell = ivec3(floor(world + sourceDirection * float(i)));
            if (all(equal(cell, receiverCell))) continue;
            if (iterationVoxelOccupied(cell)) {
                visibility = 0.0;
                break;
            }
        }
    } else {
        // Fallback for hardware that did not populate the shadow-pass grid.
        for (int i = 1; i <= 5; ++i) {
            vec3 point = world + sourceDirection * (float(i) * 2.3);
            vec4 sampleView = gbufferModelView * vec4(point - cameraPosition, 1.0);
            if (sampleView.z >= -near) continue;
            vec4 clip = gbufferProjection * sampleView;
            vec2 sampleUV = clip.xy / clip.w * 0.5 + 0.5;
            if (any(lessThan(sampleUV, vec2(0.002))) ||
                any(greaterThan(sampleUV, vec2(0.998)))) continue;
            float blocker = texture(depthtex0, sampleUV).r;
            if (blocker < 0.99999 && linearDepth(blocker) + 0.65 < -sampleView.z) {
                visibility = 0.0;
                break;
            }
        }
    }
    float spill = (diffuse * 1.15 + max(normal.y, 0.0) * 0.05) * visibility;
    float pulse = 0.96 + 0.04 * sin(frameTimeCounter * 0.14);
    return albedo.rgb * vec3(0.52, 0.55, 0.66) *
           spill * END_BLACK_HOLE_LIGHT * pulse;
}
#endif




// --- Water exit drips + low health blood ---



float dripHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

vec3 applyWaterDrips(vec3 color, vec2 uv, float wet) {
    if (wet < 0.01) return color;
    float elapsed = (1.0 - wet) * 2.8;
    vec2 pixel = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    // Each drop has its own speed, path, short wake, and tiny lens highlight.
    for (int i = 0; i < 11; ++i) {
        float seed = float(i) * 17.3 + 3.1;
        float originX = 0.035 + 0.93 * dripHash(vec2(seed, 1.7));
        float speed = 0.26 + 0.31 * dripHash(vec2(seed, 2.3));
        float yHead = 1.13 + dripHash(vec2(seed, 4.1)) * 0.22 - elapsed * speed;
        float behind = uv.y - yHead; // The wake stays above a downward-moving drop.
        float bend = sin(behind * 16.0 + seed) * min(max(behind, 0.0), 0.16) * 0.025;
        float dx = uv.x - originX - bend;
        if (abs(dx) > 0.035 || behind < -0.035 || behind > 0.27) continue;
        float radius = 0.005 + 0.006 * dripHash(vec2(seed, 5.5));
        vec2 glass = vec2(dx / (radius * 0.80), behind / (radius * 1.28));
        float dropR = length(glass);
        float bulb = 1.0 - smoothstep(0.65, 1.10, dropR);
        float wake = smoothstep(0.0, 0.025, behind) *
                     (1.0 - smoothstep(0.10, 0.25, behind)) *
                     (1.0 - smoothstep(radius * 0.30, radius * 0.85, abs(dx)));
        float coverage = clamp(bulb * 0.70 + wake * 0.42, 0.0, 1.0) * wet;
        if (coverage < 0.003) continue;
        vec2 normal = normalize(vec2(glass.x * 0.9, glass.y * 0.7) + vec2(0.001));
        vec2 refractedUV = clamp(uv + normal * pixel * (3.2 * bulb + 1.3 * wake),
                                 vec2(0.001), vec2(0.999));
        vec3 refracted = texture(colortex0, refractedUV).rgb;
        color = mix(color, refracted * 0.91, coverage * 0.69);
        float rim = exp(-pow((dropR - 0.80) * 7.0, 2.0));
        float lightSide = max(dot(normal, normalize(vec2(-0.55, 0.84))), 0.0);
        color += vec3(0.84, 0.92, 1.0) * rim * lightSide * bulb * wet * 0.12;
    }
    // A fast, uneven splash sheet crosses the top of the lens on surfacing.
    float sheetY = 0.94 - 0.025 * sin(uv.x * 31.0) - 0.018 * sin(uv.x * 83.0 + 1.8);
    float sheet = smoothstep(sheetY - 0.018, sheetY + 0.020, uv.y) *
                  exp(-elapsed * 6.0);
    vec3 shifted = texture(colortex0, clamp(uv + vec2(0.0, 3.0 * pixel.y),
                                           vec2(0.001), vec2(0.999))).rgb;
    color = mix(color, shifted * 0.92 + vec3(0.028), sheet * 0.22);
    return color;
}

vec3 applyBloodOverlay(vec3 color, vec2 uv, float health) {
#if BLOOD_EFFECT == 0
    return color;
#else
    if (health < 0.0 || health >= 0.35) return color;
    float severity = 1.0 - smoothstep(0.06, 0.35, health);
    float critical = 1.0 - smoothstep(0.06, 0.22, health);
    float aspect = viewWidth / max(viewHeight, 1.0);
    vec2 center = (uv - 0.5) * vec2(aspect, 1.0);
    float angle = atan(center.y, center.x);
    float irregular = 0.023 * sin(angle * 7.0 + 1.6) +
                      0.013 * sin(angle * 17.0 - 0.8);
    float rim = smoothstep(0.40 + irregular, 0.91, length(center));
    float pulse = 0.89 + 0.11 * sin(frameTimeCounter * (2.8 + severity * 1.6));
    float amount = rim * severity * pulse * (BLOOD_EFFECT == 2 ? 0.59 : 0.33);
    vec3 edgeTint = color * vec3(0.72, 0.40, 0.43) + vec3(0.052, 0.002, 0.003);
    color = mix(color, edgeTint, amount);

    // Thin translucent stains remain at the frame edge instead of coating
    // the view. Each trickle has a different width, bend and length.
    for (int i = 0; i < 5; ++i) {
        float seed = float(i) * 11.7 + 2.0;
        float x = 0.08 + 0.84 * dripHash(vec2(seed, 4.2));
        float lengthY = 0.055 + 0.095 * dripHash(vec2(seed, 9.4));
        float width = 0.002 + 0.0035 * dripHash(vec2(seed, 7.3));
        float travel = clamp((1.0 - uv.y) / lengthY, 0.0, 1.0);
        float dx = abs(uv.x - x - sin(travel * 2.6 + seed) * travel * 0.004);
        float taper = (1.0 - smoothstep(0.64, 1.0, travel)) *
                      smoothstep(0.0, 0.08, travel);
        float stain = (1.0 - smoothstep(width, width * 2.1, dx)) * taper *
                      critical * (BLOOD_EFFECT == 2 ? 0.40 : 0.23);
        color = mix(color, color * vec3(0.52, 0.16, 0.18) + vec3(0.04, 0.001, 0.002), stain);
    }
    return color;
#endif
}

void main() {
    // Keep the End on one undistorted screen projection. Warping this UV
    // rescales celestial discs when they move toward the camera's edges.
    vec2 imageUV = texcoord;
#if VHS_MODE > 0
    imageUV = tapeUV(imageUV);
#endif
    vec3 color = texture(colortex0, imageUV).rgb;
    float depth = sceneDepth(imageUV);
    if (CAMERA_SHARPNESS>0.0 || CAMERA_FOCUS>0.0) {
    vec2 cameraPixel=1.0/vec2(viewWidth,viewHeight);
    vec3 neighbors=vec3(0.0); float weight=0.0;
    float centerDistance=sceneDistance(imageUV);
    for (int tap=0; tap<4; ++tap) {
        vec2 direction=tap==0?vec2(1,0):tap==1?vec2(-1,0):tap==2?vec2(0,1):vec2(0,-1);
        vec2 sampleUV=clamp(imageUV+direction*cameraPixel,vec2(0.001),vec2(0.999));
        float compatible=1.0-smoothstep(0.10,0.5,abs(sceneDistance(sampleUV)-centerDistance));
        neighbors+=texture(colortex0,sampleUV).rgb*compatible; weight+=compatible;
    }
    vec3 average=weight>0.0?neighbors/weight:color;
    if (CAMERA_SHARPNESS>0.0) color=max(color+(color-average)*CAMERA_SHARPNESS,vec3(0.0));
    if (CAMERA_FOCUS>0.0 && depth<0.99999) {
        float blur=clamp(abs(centerDistance-CAMERA_FOCUS)/max(CAMERA_FOCUS,1.0),0.0,1.0);
        color=mix(color,average,blur*0.8);
    }

    }
    if (depth > 0.99999) {
        color = endSpaceSky(imageUV, texcoord);
    }

    // The End draws only its space sky; Overworld clouds, godrays and weather are absent.
    bool nether = false;

#if BLOOM > 0
    vec2 pixel = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    vec3 glow = brightSample(imageUV) * 0.16;
    vec2 nearRadius = pixel * 4.0 * (viewHeight/1080.0);
    vec2 farRadius = pixel * 11.0 * (viewHeight/1080.0);
    glow += brightSample(imageUV + vec2( nearRadius.x, 0.0)) * 0.11;
    glow += brightSample(imageUV + vec2(-nearRadius.x, 0.0)) * 0.11;
    glow += brightSample(imageUV + vec2(0.0,  nearRadius.y)) * 0.11;
    glow += brightSample(imageUV + vec2(0.0, -nearRadius.y)) * 0.11;
    glow += brightSample(imageUV + vec2( farRadius.x,  farRadius.y)) * 0.0675;
    glow += brightSample(imageUV + vec2(-farRadius.x,  farRadius.y)) * 0.0675;
    glow += brightSample(imageUV + vec2( farRadius.x, -farRadius.y)) * 0.0675;
    glow += brightSample(imageUV + vec2(-farRadius.x, -farRadius.y)) * 0.0675;
    glow += brightSample(imageUV + vec2( farRadius.x, 0.0)) * 0.045;
    glow += brightSample(imageUV + vec2(-farRadius.x, 0.0)) * 0.045;
    glow += brightSample(imageUV + vec2(0.0,  farRadius.y)) * 0.045;
    glow += brightSample(imageUV + vec2(0.0, -farRadius.y)) * 0.045;
#if NETHER_HEAT > 0
    if (nether) {
        vec2 heatRadius = pixel * 24.0;
        glow += brightSample(imageUV + vec2( heatRadius.x, 0.0)) * 0.065;
        glow += brightSample(imageUV + vec2(-heatRadius.x, 0.0)) * 0.065;
        glow += brightSample(imageUV + vec2(0.0,  heatRadius.y)) * 0.065;
        glow += brightSample(imageUV + vec2(0.0, -heatRadius.y)) * 0.065;
    }
#endif
#if BLOOM == 2
    glow *= 1.6;
#endif
    // Screen blend keeps the output in display range and avoids white clipping.
    float glowStrength = BLOOM_STRENGTH;

    // Soft-cap bloom so campfires/torches don't bleach the whole frame
    color += max(1.0 - color, vec3(0.0)) * clamp(glow * glowStrength, 0.0, 0.55);
#endif

    bool blackHoleLit = false;
#if END_SKY_STYLE == 8
    if (depth < 0.99999) {
        vec3 lightFromHole = iterationTerrainLight(imageUV, texture(depthtex0, imageUV).r);
        blackHoleLit = dot(lightFromHole, vec3(0.2126, 0.7152, 0.0722)) > 0.0001;
        color += lightFromHole;
    }
#endif

    if (depth < 0.99999) {
        float luma = luminance(color);
        // Apply the world color grade to surfaces; its contrast crushes the
        // faint Milky Way and distant stars if applied to empty space.
        vec3 shadows = vec3(-0.025, 0.003, 0.050) * (1.0 - smoothstep(0.06, 0.55, luma));
        vec3 highlights = vec3(0.040, 0.015, -0.025) * smoothstep(0.45, 0.98, luma);
        color += (shadows + highlights) * COLOR_STRENGTH;
        color = (color - 0.5) * CONTRAST + 0.5;
        color = mix(vec3(luminance(color)), color, SATURATION);
    }

    vec2 centered = (imageUV - 0.5) * vec2(viewWidth / viewHeight, 1.0);
    float edge = smoothstep(0.16, 0.75, dot(centered, centered));
    color *= 1.0 - VIGNETTE * edge;

    if (CAMERA_CHROMATIC > 0.0) {
    // Restrict channel separation to geometry. The End sky is generated in
    // this pass, so reading colortex0 at its neighboring sky pixels is invalid.
    if (depth < 0.99999) {
        vec2 displacement = (imageUV - 0.5) *
            (CAMERA_CHROMATIC * 2.0 / max(viewWidth, viewHeight));
        vec2 redUV = clamp(imageUV + displacement, vec2(0.001), vec2(0.999));
        vec2 blueUV = clamp(imageUV - displacement, vec2(0.001), vec2(0.999));
        if (sceneDepth(redUV) < 0.99999) color.r +=
            (texture(colortex0, redUV).r - texture(colortex0, imageUV).r) * 0.75;
        if (sceneDepth(blueUV) < 0.99999) color.b +=
            (texture(colortex0, blueUV).b - texture(colortex0, imageUV).b) * 0.75;
    }
    }
    if (CAMERA_GRAIN > 0.0 || CAMERA_FILM > 0) color = cameraFilmFinish(color, texcoord);

#if VHS_MODE > 0
    color = tapeFinish(color, texcoord, imageUV);
#if VHS_MODE == 1
    // Crop the wide frame to a centered 4:3 picture with opaque side bars.
    float halfWidth = min(0.5, 2.0 / (3.0 * (viewWidth / viewHeight)));
    if (abs(texcoord.x - 0.5) >= halfWidth) color = vec3(0.0);
#endif
#endif
#if CAMERA_BARS > 0
    float barHeight = max(0.0, 0.5 - viewWidth / (2.0 * viewHeight * (CAMERA_BARS == 1 ? 1.85 : 2.39)));
    if (texcoord.y < barHeight || texcoord.y > 1.0 - barHeight) color = vec3(0.0);
#endif
    // Keep lightless End surfaces black after grading; empty sky is separate.
    if (!blackHoleLit && depth < 0.99999 &&
        dot(texture(colortex0, imageUV).rgb, vec3(0.2126, 0.7152, 0.0722)) < 0.0001)
        color = vec3(0.0);

    // The negative state means submerged. Flip to a positive timer on exit.
    // Keep the effect off while underwater, then fade over about 2.8 seconds.
    if (texcoord.x < 1.5 / viewWidth && texcoord.y < 1.5 / viewHeight) {
        if (isEyeInWater == 1) fxLights.screenWet = -1.0;
        else if (fxLights.screenWet < -0.5) fxLights.screenWet = 1.0;
        else fxLights.screenWet = max(fxLights.screenWet - clamp(frameTime, 0.0, 0.1) / 2.8, 0.0);
    }
    float wetAmt = isEyeInWater == 0 ? clamp(fxLights.screenWet, 0.0, 1.0) : 0.0;
    color = applyWaterDrips(color, texcoord, wetAmt);
    color = applyBloodOverlay(color, texcoord, currentPlayerHealth);
    color = pow(max(color*exp2(CAMERA_EXPOSURE),vec3(0.0)),vec3(1.0/CAMERA_GAMMA));
    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
