#version 330 compatibility
out vec4 waterColor;
out vec3 distantWaterPos;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
void main() {
    gl_Position = ftransform();
    waterColor = gl_Color;
    distantWaterPos=(gbufferModelViewInverse*gl_ModelViewMatrix*gl_Vertex).xyz+cameraPosition;
}
