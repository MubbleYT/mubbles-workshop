"""Execute the actual water fragment on controlled horizontal/vertical sheets."""
from pathlib import Path
exec(Path(__file__).with_name('render_lighting.py').read_text().split('outputs=[target]')[0])
v=vertex.replace('out vec2 texcoord;','out vec2 texcoord; out vec2 lightUV; out vec4 glcolor; out vec3 waterWorldPos; out vec3 waterViewPos; out vec3 waterNormal; flat out float isWater; uniform vec3 face; uniform mat4 gbufferModelView;').replace('texcoord=p;','texcoord=p; lightUV=vec2(0.96875);glcolor=vec4(1);waterWorldPos=vec3(p.x*8, p.y*8,0);waterViewPos=mat3(gbufferModelView)*vec3(0,0,-3);waterNormal=mat3(gbufferModelView)*face;isWater=1;')
def run(face,waves=1,time=0,angle=0,style=0):
 p=pipeline(v,expand(S/'gbuffers_water.fsh',{'WATER_WAVES':waves,'WATER_STYLE':style},{}));use(p)
 cs=np.cos(angle);sn=np.sin(angle);rot=np.array([[1,0,0,0],[0,cs,-sn,0],[0,sn,cs,0],[0,0,0,1]],np.float32)
 for name,m in [('gbufferModelView',rot),('gbufferModelViewInverse',rot.T)]:
  packed=m.T.copy();matrix(loc(p,name.encode()),1,0,packed.ctypes.data)
 for name,val in [('near',0.05),('far',256),('viewWidth',N),('viewHeight',N),('sunAngle',0.25),('frameTimeCounter',time)]:u1(loc(p,name.encode()),val)
 u3(loc(p,b'face'),*face);u3(loc(p,b'skyColor'),0.3,0.5,0.8);u3(loc(p,b'sunPosition'),0,1,0)
 for unit,(name,val) in enumerate({'gtexture':[0.2,0.5,0.8,0.5],'depthtex1':[0.999]*4}.items()):
  data=np.empty((N,N,4),np.float32);data[:]=val;active(0x84C0+unit);bindTex(0x0DE1,texture(data));ui(loc(p,name.encode()),unit)
 viewport(0,0,N,N);draw(4,0,3);r=pixels();pdelete(p);return r
fall=run((0,0,1));top=run((0,1,0));rotated=run((0,0,1),angle=0.6)
assert fall[:,:,3].max()<0.35 and top[:,:,3].mean()>0.70
assert np.allclose(fall[8:-8,8:-8,3],rotated[8:-8,8:-8,3],atol=1e-5)
assert np.abs(run((0.95,0,0.312))-run((0.95,0,0.312),time=3)).mean()>0.00001
assert np.array_equal(run((0,0,1),waves=0),run((0,0,1),waves=0,time=3))
assert np.allclose(run((0,0,1),style=2)[:,:,3],0.5)
Path(__file__).with_name('water-results.json').write_text(json.dumps({'waterfall_max_opacity':float(fall[:,:,3].max()),'horizontal_mean_opacity':float(top[:,:,3].mean()),'fall_opacity_independent_of_camera_pitch':True,'flow_ripples_animated':True,'calm_time_invariant':True,'vanilla_texture_alpha_retained':True,'gameplay_tested':False},indent=2))
print('Waterfall thin-sheet shading, camera pitch, flow animation, calm and Vanilla GPU tests passed.')
