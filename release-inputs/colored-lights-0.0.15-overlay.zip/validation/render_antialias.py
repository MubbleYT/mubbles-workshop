"""Actual spatial AA and lantern material GPU regressions; not game screenshots."""
from pathlib import Path
exec(Path(__file__).with_name('render_lighting.py').read_text().split('outputs=[target]')[0])
y,x=np.mgrid[:N,:N]
def run(data,mode=1):
 p=pipeline(vertex,expand(S/'composite1.fsh',{'ANTI_ALIASING':mode},{'DISTANT_HORIZONS':1}));use(p)
 for unit,(name,value) in enumerate({'colortex0':data,'depthtex0':[1]*4,'dhDepthTex0':[0.5]*4}.items()):
  d=np.empty((N,N,4),np.float32);d[:]=value;active(0x84C0+unit);bindTex(0x0DE1,texture(d));ui(loc(p,name.encode()),unit)
 viewport(0,0,N,N);draw(4,0,3);r=pixels()[:,:,:3];pdelete(p);return r
flat=np.full((N,N,4),0.42,np.float32);flat[:,:,3]=1
assert np.allclose(run(flat),0.42)
black=flat.copy();black[:,:,:3]=0;assert run(black).max()==0
frames=[];rawFrames=[]
for shift in [0,0.2,0.4,0.6,0.8,1.0]:
 d=np.ones((N,N,4),np.float32);d[:,:,:3]=((x+y*0.63)>N*0.7+shift)[:,:,None]
 rawFrames.append(d[:,:,:3]);frames.append(run(d))
rawMotion=sum(np.abs(b-a).mean() for a,b in zip(rawFrames,rawFrames[1:]));aaMotion=sum(np.abs(b-a).mean() for a,b in zip(frames,frames[1:]))
assert sum(((r>0.01)&(r<0.99)).sum() for r in frames)>100
rawPeak=max(np.abs(b-a).max() for a,b in zip(rawFrames,rawFrames[1:]))
aaPeak=max(np.abs(b-a).max() for a,b in zip(frames,frames[1:]))
assert aaPeak<rawPeak*0.95
assert all(r.min()>=0 and r.max()<=1 for r in frames)
# High mode suppresses high-frequency far-LOD checkerboard contrast.
d=np.ones((N,N,4),np.float32);d[:,:,:3]=((x+y)%2)[:,:,None]
a=run(d,1);b=run(d,2);assert b.var()<a.var()*0.70
# Execute the real terrain material shader on bright flame and dark metal texels.
outputs=[target]+[texture(np.zeros((N,N,4),np.float32)) for _ in range(5)]
for i,t in enumerate(outputs):attachTex(0x8D40,0x8CE0+i,0x0DE1,t,0)
drawBuffers(6,(U*6)(*[0x8CE0+i for i in range(6)]))
v=vertex.replace('out vec2 texcoord;','out vec2 texcoord; out vec2 lightUV; out vec4 glcolor; out vec3 surfaceNormal; flat out int emitterType; flat out int oreType; out vec3 emitterWorld;').replace('texcoord=p;','texcoord=p;lightUV=vec2(0.96875);glcolor=vec4(1);surfaceNormal=vec3(0,1,0);emitterType=KIND;oreType=0;emitterWorld=vec3(0);')
tex=np.ones((N,N,4),np.float32);tex[:,:N//2,:3]=0.12;tex[:,N//2:,:3]=[1,0.8,0.2]
for kind in [5,2]:
 p=pipeline(v.replace('KIND',str(kind)),expand(S/'gbuffers_terrain.fsh',{},{}));use(p);active(0x84C0);bindTex(0x0DE1,texture(tex));ui(loc(p,b'gtexture'),0);u1(loc(p,b'sunAngle'),0.25);draw(4,0,3)
 readBuffer(0x8CE1);em=pixels();assert em[:,:N//2,:3].max()==0;assert em[:,N//2:,:3].max()>0.1
 if kind==5:assert em[:,N//2:,0].mean()>em[:,N//2:,2].mean()
 readBuffer(0x8CE5);normal=pixels();assert np.allclose(normal,[0.5,1,0.5,1]);pdelete(p)
report={'flat_color_preserved':True,'exact_black_preserved':True,'diagonal_edges_have_fractional_coverage':True,'raw_edge_motion':float(rawMotion),'raw_peak_pixel_change':float(rawPeak),'aa_peak_pixel_change':float(aaPeak),'aa_edge_motion':float(aaMotion),'far_detail_variance_before':float(a.var()),'far_detail_variance_after':float(b.var()),'lantern_metal_emission_zero':True,'normal_lantern_glow_warm':True,'mesh_normal_mrt_exact':True,'temporal_history_used':False,'gameplay_tested':False}
Path(__file__).with_name('antialias-results.json').write_text(json.dumps(report,indent=2)+'\n')
print('AA, far-detail filtering, lantern frame emission and mesh-normal GPU fixtures passed.')
