// Original spatial edge resolve. Explicit bilinear taps also support nearest-filtered buffers.
#define ANTI_ALIASING 2 // [0 1 2] Off / Edge AA / Edge AA + distant detail filtering
vec3 aaSample(vec2 uv) {
    ivec2 size=textureSize(colortex0,0);
    vec2 pixel=clamp(uv*vec2(size)-0.5,vec2(0.0),vec2(size-1));
    ivec2 a=ivec2(floor(pixel)), b=min(a+1,size-1);
    vec2 f=fract(pixel);
    return mix(mix(texelFetch(colortex0,a,0).rgb,texelFetch(colortex0,ivec2(b.x,a.y),0).rgb,f.x),
               mix(texelFetch(colortex0,ivec2(a.x,b.y),0).rgb,texelFetch(colortex0,b,0).rgb,f.x),f.y);
}
float aaLuma(vec3 c){return dot(c,vec3(0.299,0.587,0.114));}
vec3 resolveEdges(vec2 uv){
#if ANTI_ALIASING == 0
    return texture(colortex0,uv).rgb;
#else
    vec2 pixel=1.0/vec2(textureSize(colortex0,0));
    vec3 center=aaSample(uv);
    vec3 nw=aaSample(uv+pixel*vec2(-1,1)),ne=aaSample(uv+pixel*vec2(1,1));
    vec3 sw=aaSample(uv+pixel*vec2(-1,-1)),se=aaSample(uv+pixel*vec2(1,-1));
    float m=aaLuma(center),a=aaLuma(nw),b=aaLuma(ne),c=aaLuma(sw),d=aaLuma(se);
    float lo=min(m,min(min(a,b),min(c,d))),hi=max(m,max(max(a,b),max(c,d)));
    if (hi-lo<max(0.0312,hi*0.10)) {
#if ANTI_ALIASING == 2 && defined(DISTANT_HORIZONS)
        // Diagonal taps miss a one-pixel checkerboard. Far-detail filtering
        // must still run when that edge detector considers the neighborhood flat.
        if (!(texture(depthtex0,uv).r>=0.99999 && texture(dhDepthTex0,uv).r<0.99999)) return center;
#else
        return center;
#endif
    }
    vec2 direction=vec2(-(a+b-c-d),a+c-b-d);
    float reduce=max((a+b+c+d)*0.03125,0.0078125);
    direction=clamp(direction/(min(abs(direction.x),abs(direction.y))+reduce),vec2(-6),vec2(6))*pixel;
    vec3 narrow=0.5*(aaSample(uv-direction/6.0)+aaSample(uv+direction/6.0));
    vec3 wide=narrow*0.5+0.25*(aaSample(uv-direction*0.5)+aaSample(uv+direction*0.5));
    float wideLuma=aaLuma(wide);
    vec3 result=wideLuma<lo || wideLuma>hi?narrow:wide;
#if ANTI_ALIASING == 2
    // Suppress unresolved far-LOD detail while retaining full-resolution nearby textures.
    float depth=texture(depthtex0,uv).r;
    float distant=0.0;
#ifdef DISTANT_HORIZONS
    distant=depth>=0.99999 && texture(dhDepthTex0,uv).r<0.99999?1.0:0.0;
#endif
    if (distant>0.0) {
        vec3 cardinal=aaSample(uv+vec2(pixel.x,0))+aaSample(uv-vec2(pixel.x,0))
                     +aaSample(uv+vec2(0,pixel.y))+aaSample(uv-vec2(0,pixel.y));
        result=mix(result,(center*4.0+cardinal)*0.125,0.25);
    }
#endif
    return result;
#endif
}
