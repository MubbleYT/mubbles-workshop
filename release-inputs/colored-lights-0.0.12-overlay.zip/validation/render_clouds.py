"""Render actual cloud-library GPU fixtures from above/below and at two times."""
from pathlib import Path
import numpy as np, json
exec(Path(__file__).with_name('compile.py').read_text().split('profiles={}')[0])
def gl(name,result,args):return sig(G,name,result,args)
genTex=gl('glGenTextures',None,[I,ptr]);bindTex=gl('glBindTexture',None,[U,U]);texImage=gl('glTexImage2D',None,[U,I,I,I,I,I,U,U,ptr]);texParam=gl('glTexParameteri',None,[U,U,I])
genFBO=gl('glGenFramebuffers',None,[I,ptr]);bindFBO=gl('glBindFramebuffer',None,[U,U]);attachTex=gl('glFramebufferTexture2D',None,[U,U,U,U,I]);checkFBO=gl('glCheckFramebufferStatus',U,[U])
use=gl('glUseProgram',None,[U]);loc=gl('glGetUniformLocation',I,[U,C.c_char_p]);u1=gl('glUniform1f',None,[I,C.c_float]);u3=gl('glUniform3f',None,[I,C.c_float,C.c_float,C.c_float]);ui=gl('glUniform1i',None,[I,I]);matrix=gl('glUniformMatrix4fv',None,[I,I,U,ptr])
active=gl('glActiveTexture',None,[U]);viewport=gl('glViewport',None,[I,I,I,I]);draw=gl('glDrawArrays',None,[U,I,I]);read=gl('glReadPixels',None,[I,I,I,I,U,U,ptr])
def texture(data):
 tid=U();genTex(1,C.byref(tid));bindTex(0x0DE1,tid);texParam(0x0DE1,0x2801,0x2600);texParam(0x0DE1,0x2800,0x2600)
 texImage(0x0DE1,0,0x8814,data.shape[1],data.shape[0],0,0x1908,0x1406,data.ctypes.data)
 return tid.value
N=64;target=texture(np.zeros((N,N,4),np.float32));fbo=U();genFBO(1,C.byref(fbo));bindFBO(0x8D40,fbo);attachTex(0x8D40,0x8CE0,0x0DE1,target,0);assert checkFBO(0x8D40)==0x8CD5
depths=[texture(np.ones((N,N,4),np.float32)),texture(np.zeros((N,N,4),np.float32))]
vertex='''#version 430 compatibility
out vec2 texcoord;
void main(){ vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);texcoord=p;gl_Position=vec4(p*2.0-1.0,0.0,1.0); }
'''
header='''#version 430 compatibility
#define CLOUD_STEPS 24
#define CLOUD_STYLE STYLE
#define CLOUD_COVERAGE 0.72
uniform float frameTimeCounter;
uniform float directionY;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;
uniform sampler2D depthtex0;
in vec2 texcoord;
float hash2(vec2 p){p=fract(p*vec2(0.1031,0.1030));p+=dot(p,p.yx+33.33);return fract((p.x+p.y)*p.x);}
float weatherStrength(){return 0.0;}
vec3 viewRay(vec2 uv){return normalize(vec3((uv.x-0.5)*2.0,directionY,(uv.y-0.5)*2.0));}
'''
def raw(src,kind):
 sid=create(kind);b=src.encode();p=C.c_char_p(b);source(sid,1,C.byref(p),None);compile(sid);ok=I();status(sid,0x8B81,C.byref(ok))
 if not ok.value:
  buf=C.create_string_buffer(20000);log(sid,len(buf),None,buf);raise RuntimeError(buf.value.decode())
 return sid
def build(style,dynamic=1,density=1):
 cloud=(S/'lib/clouds.glsl').read_text().replace('#define DYNAMIC_CLOUDS 1','#define DYNAMIC_CLOUDS '+str(dynamic)).replace('#define DYNAMIC_CLOUD_DENSITY 1','#define DYNAMIC_CLOUD_DENSITY '+str(density))
 vs=raw(vertex,0x8B31);fs=raw(header.replace(' STYLE\n',' '+str(style)+'\n')+cloud+'\nvoid main(){gl_FragData[0]=stableClouds(texcoord);}',0x8B30)
 pid=program();attach(pid,vs);attach(pid,fs);link(pid);ok=I();pstatus(pid,0x8B82,C.byref(ok));assert ok.value
 for sid in [vs,fs]:delete(sid)
 return pid
def render(pid,height,dy,time,blocked=False):
 use(pid);u1(loc(pid,b'frameTimeCounter'),time);u1(loc(pid,b'directionY'),dy);u3(loc(pid,b'cameraPosition'),37,height,71);u3(loc(pid,b'sunPosition'),0,1,0)
 identity=np.eye(4,dtype=np.float32);matrix(loc(pid,b'gbufferModelViewInverse'),1,0,identity.ctypes.data);matrix(loc(pid,b'gbufferProjectionInverse'),1,0,identity.ctypes.data)
 active(0x84C0);bindTex(0x0DE1,depths[int(blocked)]);ui(loc(pid,b'depthtex0'),0);viewport(0,0,N,N);draw(4,0,3)
 result=np.empty((N,N,4),np.float32);read(0,0,N,N,0x1908,0x1406,result.ctypes.data);assert np.isfinite(result).all()
 return result
checks=[];images=[]
for style in range(4):
 pid=build(style);below=render(pid,64,0.5,0);above=render(pid,320,-0.5,0);later=render(pid,64,0.5,600);blocked=render(pid,64,0.5,0,True)
 assert below[:,:,3].max()>0.1 and above[:,:,3].max()>0.1
 assert np.abs(below-later).mean()>0.001
 assert blocked.max()==0
 images.extend([below,above,later]);checks.append({'style':style,'below_max_alpha':float(below[:,:,3].max()),'above_max_alpha':float(above[:,:,3].max()),'animation_difference':float(np.abs(below-later).mean()),'blocked_cloud_max':float(blocked.max())});pdelete(pid)
pid=build(0,0,0);a=render(pid,64,0.5,0);b=render(pid,64,0.5,600);assert np.array_equal(a,b);pdelete(pid)
from PIL import Image
panels=[]
for r in images:
 rgb=r[:,:,:3]+np.array([0.1,0.3,0.55])*(1-r[:,:,3,None]);panels.append((np.clip(rgb,0,1)*255).astype('uint8')[::-1])
import io
imageBuffer=io.BytesIO()
Image.fromarray(np.concatenate([np.concatenate(panels[i:i+3],axis=1) for i in range(0,12,3)],axis=0)).resize((768,1024)).save(imageBuffer,format='PNG')
Path(__file__).with_name('cloud-fixtures.png').write_bytes(imageBuffer.getvalue())
Path(__file__).with_name('cloud-results.json').write_text(json.dumps({'cloud_checks':checks,'frozen_clouds_exact_match':True},indent=2))
print('Cloud GPU fixtures passed: above, below, animation, foreground depth, frozen settings.')
# Regression for the reported opaque blanket at normal coverage and grazing angles.
header=header.replace('#define CLOUD_COVERAGE 0.72','#define CLOUD_COVERAGE 0.52')
pid=build(0);normalAbove=render(pid,320,-0.5,0);horizon=render(pid,260,-0.08,0)
clearFraction=float((normalAbove[:,:,3]<0.08).mean());horizonClear=float((horizon[:,:,3]<0.08).mean())
assert clearFraction>0.15 and horizonClear>0.15
assert horizon[:,:,3].mean()<0.75
pdelete(pid)
# Actual DH clipping path: foreground far-terrain depth must prevent cloud overdraw.
header+='\n#define DISTANT_HORIZONS 1\nuniform sampler2D dhDepthTex0;\nuniform mat4 dhProjectionInverse;\n'
pid=build(0);use(pid);active(0x84C1);bindTex(0x0DE1,depths[1]);ui(loc(pid,b'dhDepthTex0'),1)
identity=np.eye(4,dtype=np.float32);matrix(loc(pid,b'dhProjectionInverse'),1,0,identity.ctypes.data)
dhBlocked=render(pid,320,-0.5,0);assert dhBlocked.max()==0;pdelete(pid)
report=json.loads(Path(__file__).with_name('cloud-results.json').read_text())
report.update(default_above_clear_fraction=clearFraction,grazing_angle_clear_fraction=horizonClear,grazing_angle_mean_opacity=float(horizon[:,:,3].mean()),dh_foreground_cloud_max=float(dhBlocked.max()))
Path(__file__).with_name('cloud-results.json').write_text(json.dumps(report,indent=2))
print('Blanket regression and DH clipping passed:',clearFraction,horizonClear)

styleFrames=[]
for style in range(4):
 pid=build(style);use(pid);active(0x84C1);bindTex(0x0DE1,depths[0]);ui(loc(pid,b'dhDepthTex0'),1);matrix(loc(pid,b'dhProjectionInverse'),1,0,identity.ctypes.data)
 styleFrames.append(render(pid,320,-0.5,0));pdelete(pid)
differences={}
for a in range(4):
 for b in range(a+1,4):
  difference=float(np.abs(styleFrames[a]-styleFrames[b]).mean());assert difference>0.001,(a,b,difference)
  differences[str(a)+'-'+str(b)]=difference
report=json.loads(Path(__file__).with_name('cloud-results.json').read_text());report['all_style_pair_differences']=differences
Path(__file__).with_name('cloud-results.json').write_text(json.dumps(report,indent=2))
print('All six cloud-style pairs produce different GPU output.')

# Graphic styles must be independent of raymarch quality and visible on both faces.
header=header.split('\n#define DISTANT_HORIZONS')[0]
flatChecks=[]
for style in [1,2,3]:
 pid=build(style,0,0);a=render(pid,64,0.5,0);pdelete(pid)
 saved=header;header=header.replace('#define CLOUD_STEPS 24','#define CLOUD_STEPS 4')
 pid=build(style,0,0);b=render(pid,64,0.5,0);pdelete(pid);header=saved
 assert np.array_equal(a,b)
 flatChecks.append(style)
report=json.loads(Path(__file__).with_name('cloud-results.json').read_text())
report['flat_styles_independent_of_march_steps']=flatChecks
Path(__file__).with_name('cloud-results.json').write_text(json.dumps(report,indent=2))
print('Earth, Vanilla and Dungeons use quality-independent flat sheets.')
