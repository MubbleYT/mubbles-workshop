// World-space, depth-limited cloud layer. Both ray directions are supported.
#define CLOUD_HEIGHT 192.0 // [96.0 128.0 160.0 192.0 224.0 256.0 320.0 384.0]
#define CLOUD_DISTANCE 2400.0 // [512.0 1024.0 1600.0 2400.0 3200.0 4800.0]
#define CLOUD_SPEED 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0]
#define DYNAMIC_CLOUDS 1 // [0 1]
#define DYNAMIC_CLOUD_DENSITY 1 // [0 1]

float cloudNoiseStable(vec3 p) {
    vec3 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float result = 0.0;
    for (int z=0; z<2; ++z) for (int y=0; y<2; ++y) for (int x=0; x<2; ++x) {
        vec3 corner = vec3(x,y,z);
        vec3 weight = mix(1.0-f, f, corner);
        result += hash2((i+corner).xz + (i.y+corner.y)*vec2(17.13,43.71)) * weight.x*weight.y*weight.z;
    }
    return result;
}

float dynamicCoverage() {
    float coverage = CLOUD_COVERAGE;
#if DYNAMIC_CLOUD_DENSITY == 1
    // Slow variation independent of wind; a stable weather field travels with clouds.
    float cycle = sin(frameTimeCounter*0.0031)*0.065 + sin(frameTimeCounter*0.0013+1.8)*0.035;
    coverage = mix(coverage+cycle, 0.90, weatherStrength());
#endif
    return clamp(coverage, 0.05, 0.98);
}

vec4 stableClouds(vec2 uv) {
#if CLOUD_STEPS == 0
    return vec4(0.0);
#else
    vec3 ray = normalize((gbufferModelViewInverse * vec4(viewRay(uv),0.0)).xyz);
    float bottom = CLOUD_HEIGHT - 36.0, top = CLOUD_HEIGHT + 36.0;
    float start, finish;
    if (abs(ray.y) < 0.00001) {
        if (cameraPosition.y < bottom || cameraPosition.y > top) return vec4(0.0);
        start=0.0; finish=CLOUD_DISTANCE;
    } else {
        float a=(bottom-cameraPosition.y)/ray.y, b=(top-cameraPosition.y)/ray.y;
        start=max(0.0,min(a,b)); finish=min(CLOUD_DISTANCE,max(a,b));
    }
    // Reconstruct radial distance rather than clipping with view-space Z.
    float depth = texture(depthtex0,uv).r;
    if (depth < 0.99999) {
        vec4 v=gbufferProjectionInverse*vec4(uv*2.0-1.0,depth*2.0-1.0,1.0);
        finish=min(finish,length(v.xyz/v.w));
    }
#ifdef DISTANT_HORIZONS
    else if (texture(dhDepthTex0,uv).r < 0.99999) {
        float distantDepth=texture(dhDepthTex0,uv).r;
        vec4 distantView=dhProjectionInverse*vec4(uv*2.0-1.0,distantDepth*2.0-1.0,1.0);
        finish=min(finish,max(length(distantView.xyz/distantView.w)-0.75,0.0));
    }
#endif
    if (finish<=0.0) return vec4(0.0);
    vec2 wind=vec2(0.52,0.21)*frameTimeCounter*CLOUD_SPEED*float(DYNAMIC_CLOUDS);
    float coverage=dynamicCoverage();
    vec3 light=normalize((gbufferModelViewInverse*vec4(sunPosition,0.0)).xyz);
    float day=smoothstep(-0.15,0.20,light.y);
    vec3 bright=mix(vec3(0.19,0.23,0.34),vec3(1.0,0.98,0.93),day);
    bright=mix(bright,vec3(0.19,0.22,0.27),weatherStrength()*0.78);
#if CLOUD_STYLE != 0
    // Graphic cloud sheets: one analytic plane hit, never a density march.
    if (abs(ray.y)<0.00001) return vec4(0.0);
    float planeDistance=(CLOUD_HEIGHT-cameraPosition.y)/ray.y;
    if (planeDistance<=0.0 || planeDistance>=finish) return vec4(0.0);
    vec2 position=cameraPosition.xz+ray.xz*planeDistance+wind;
    float mask;
#if CLOUD_STYLE == 1
    // Earth: wide, connected rectangular panels with crisp stepped edges.
    vec2 pixel=floor(position/12.0)*12.0;
    float field=cloudNoiseStable(vec3(pixel.x*0.006,0.37,pixel.y*0.009));
    mask=step(0.78-coverage*0.28,field);
#elif CLOUD_STYLE == 2
    // Vanilla: connected pixel silhouettes, with smaller square steps.
    vec2 pixel=floor(position/12.0)*12.0;
    float field=cloudNoiseStable(vec3(pixel.x*0.012,0.8,pixel.y*0.012));
    mask=step(0.78-coverage*0.32,field);
#else
    // Dungeons: broad graphic bands, layered-looking but geometrically flat.
    vec2 cell=floor(position/vec2(220.0,140.0));
    vec2 local=fract(position/vec2(220.0,140.0))-0.5;
    float seed=hash2(cell+vec2(17.0,31.0));
    vec2 extent=mix(vec2(0.22,0.18),vec2(0.46,0.40),seed);
    mask=step(seed,coverage)*step(abs(local.x),extent.x)*step(abs(local.y),extent.y);
#endif
    float fade=1.0-smoothstep(CLOUD_DISTANCE*0.70,CLOUD_DISTANCE,planeDistance);
    float opacity=mask*fade*0.86;
    // Two-sided shading keeps the same silhouette above and below the sheet.
    float faceShade=ray.y<0.0?1.0:0.76;
    return vec4(bright*faceShade*opacity,opacity);
#else
    if (finish<=start) return vec4(0.0);
    // Bound world-space sample spacing: sparse long rays caused radial stripes.
    float spacing=mix(36.0,8.0,clamp(float(CLOUD_STEPS)/24.0,0.0,1.0));
    int marchSteps=clamp(int(ceil((finish-start)/spacing)),4,192);
    float stepLength=(finish-start)/float(marchSteps);
    vec3 accum=vec3(0.0); float opacity=0.0;
    for (int i=0; i<192; ++i) {
        if (i>=marchSteps) break;
        float t=start+(float(i)+0.5)*stepLength;
        vec3 p=cameraPosition+ray*t; p.xz+=wind;
        float h=clamp((p.y-bottom)/72.0,0.0,1.0);
        float envelope=smoothstep(0.0,0.18,h)*(1.0-smoothstep(0.75,1.0,h));
        vec3 q=p*vec3(0.0055,0.013,0.0055);
        float shape=cloudNoiseStable(q)*0.72+cloudNoiseStable(q*2.03+vec3(9.1,2.7,17.3))*0.28;
#if CLOUD_STYLE == 1
        // Rectangular Minecraft Earth clusters, anchored in world space.
        vec2 cell=floor(p.xz/48.0), local=fract(p.xz/48.0)-0.5;
        float seed=hash2(cell);
        shape=mix(0.0,0.85,step(seed,coverage))*
            (1.0-smoothstep(0.30,0.47,max(abs(local.x),abs(local.y))));
#elif CLOUD_STYLE == 2
        shape=cloudNoiseStable(vec3(p.xz*0.009,0.0));
        envelope*=0.55+0.45*cos((h-0.5)*12.56637)*cos((h-0.5)*12.56637);
#elif CLOUD_STYLE == 3
        shape=cloudNoiseStable(q*0.65)*0.8+cloudNoiseStable(q*1.3+7.0)*0.2;
#endif
        // Large horizontal weather cells create true empty regions, rather than
        // filling the entire slab with low-density noise. Each formation has
        // its own tapered vertical extent, so the top is not one flat shelf.
        float weather=cloudNoiseStable(vec3(p.x*0.0032,0.37,p.z*0.0032));
        float macroMask=smoothstep(0.64-coverage*0.26,0.80-coverage*0.26,weather);
        float center=0.40+0.20*cloudNoiseStable(vec3(p.x*0.006,1.7,p.z*0.006));
        float halfHeight=mix(0.13,0.40,macroMask);
        float formation=1.0-smoothstep(halfHeight*0.55,halfHeight,abs(h-center));
        float detail=smoothstep(0.49,0.72,shape);
#if CLOUD_STYLE == 1
        // Keep the separate block-shaped layout of this style.
        macroMask=smoothstep(0.60-coverage*0.18,0.76-coverage*0.18,weather);
        formation=envelope;
        detail=smoothstep(0.30,0.68,shape);
#endif
        #if CLOUD_STYLE == 2
        // A thin broken layer rather than the billowing volume of style 0.
        formation=1.0-smoothstep(0.055,0.14,abs(h-0.50));
        macroMask=smoothstep(0.55-coverage*0.18,0.70-coverage*0.18,weather);
        detail=smoothstep(0.45,0.65,shape);
#elif CLOUD_STYLE == 3
        // Tall clustered puffs with a broader, distinctly chunkier silhouette.
        float clusters=cloudNoiseStable(vec3(p.x*0.002,0.8,p.z*0.002));
        macroMask=smoothstep(0.56-coverage*0.12,0.70-coverage*0.12,clusters);
        formation=1.0-smoothstep(0.20,0.46,abs(h-0.51));
        detail=smoothstep(0.40,0.61,shape);
#endif
        float density=detail*macroMask*formation*envelope;
        float alpha=1.0-exp(-density*stepLength*0.016);
        alpha*=1.0-smoothstep(CLOUD_DISTANCE*0.70,CLOUD_DISTANCE,t);
        float shade=mix(0.46,1.0,h)*(1.0-density*0.17);
        accum+=(1.0-opacity)*alpha*bright*shade;
        opacity+=(1.0-opacity)*alpha;
        if (opacity>0.99) break;
    }
    return vec4(accum,opacity);
#endif // CLOUD_STYLE
#endif
}
