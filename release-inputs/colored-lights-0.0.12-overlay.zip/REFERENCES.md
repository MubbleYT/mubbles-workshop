# Cloud visual references

- Minecraft Earth map screenshot (cloud silhouettes, not AR camera footage):
  https://www.windowscentral.com/minecraft-earth-one-month-later
  https://cdn.mos.cms.futurecdn.net/ndMuECfMu3bYUwXPoGKM48.jpg
- Vanilla Fast/Fancy comparison and texture gallery:
  https://minecraft.wiki/w/Cloud
  Fast uses flat sheets; Fancy uses shallow block geometry, rather than a
  raymarched density field. The shader uses original square-stepped masks.
- Minecraft Dungeons Tower / Cloudy Climb official imagery:
  https://www.minecraft.net/en-us/article/a-towering-challenge
  https://www.minecraft.net/en-us/article/tower-scour
- Minecraft Dungeons II official environment screenshots:
  https://news.xbox.com/de-de/2026/09/28/minecraft-dungeons-ii/
  https://www.xbox.com/en-US/games/minecraft-dungeons-ii/

These are visual references, not evidence of the proprietary Earth/Dungeons
rendering algorithms. Flat named styles implement Mubble's requested design;
no game textures or third-party shader code are included. Dungeons imagery
varies by scene; this is a stylized interpretation, not an exact renderer port.
