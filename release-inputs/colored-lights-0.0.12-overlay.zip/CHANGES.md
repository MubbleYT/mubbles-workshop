# V0.0.12 — cloud rendering repair

- Earth, Layered Vanilla and Dungeons 2 now use distinct two-sided graphic cloud
  sheets, with no volumetric density integration. Only Volumetric uses raymarching.
- Fix sparse long-ray sampling that produced radial stripes in Volumetric.
- Break volumetric formations into weather cells with varied vertical extent,
  preventing the opaque flat-topped blanket at normal coverage.
- Reconstruct radial Distant Horizons depth with its own inverse projection.
- Flat styles retain height, distance, coverage, wind and dynamic-density settings.
  Cloud Quality Off disables all styles; other quality levels only change volume sampling.
- Keep V0.0.11 lighting and the complete End shaders/textures unchanged.
- 149 compile/link variants and cloud GPU regression fixtures pass. Actual
  Minecraft/Iris/Vitrail gameplay and performance remain untested.

# V0.0.11 — directional lighting and shadows

- Add an opaque deferred lighting pass before transparent surfaces.
- Warm directional sun and dim moonlight, filtered depth shadows, cooler sky fill,
  and a small ground bounce gated by the actual skylight level.
- Decode material color to linear space, evaluate lighting, and apply a smooth
  highlight shoulder before returning display color.
- Shadow quality: 512 / 1024 / 2048; sun-shadow switch, sunlight and sky-fill controls.
- Alpha-test the shadow pass for leaf/grass cutouts; use matching foliage motion.
- Distance-based aerial perspective gated by skylight; nearby surfaces remain clear.
- Preserve black with multiplicative color grading and reduce highlight bloom spill.
- Smooth inverse-square-style torch attenuation with a finite range cutoff.
- Store material/skylight data for Distant Horizons terrain too.
- Preserve the whole protected End library and retain all previous settings/fixes.
- 149 compile/link checks and actual deferred-lighting GPU fixtures pass; Minecraft
  Vulkan gameplay and performance remain untested. No BSL code/assets are copied.

# V0.0.10 — Vitrail loading and presets

- Remove the unsupported REVERSED_CULLING requirement and use distance-box shadow culling so nearby light sources and voxel occluders are still collected.
- Use NAME=value profile assignments, as Vitrail requires. All six profiles still reset VHS.
- Make shadowDistance a macro-expanded numeric constant rather than an expression the directive parser cannot read.
- Preserve the protected End library byte-for-byte.
- Validate the ZIP central directory before publishing.

# V0.0.9 — all 16 requested changes

1. **VHS reset:** every quality profile explicitly resets VHS, film, grain,
   lens distortion, chromatic separation, bars and added camera controls.
2. **Planet presets:** Earth (0) and Venus (6) only; other planet/object menu
   choices removed. Protected End projection code remains unchanged.
3. **Held torches:** fixed Iris light uniforms from float to int; mapped items;
   independent main/offhand positions, colors, falloff and visibility. Soul/copper
   lights remain recognized even if reported block emission is zero.
4. **Quality presets:** Potato, Low, Medium, Default, High, Ultra only. Removed
   Super Potato, VHS, VHS 16:9 and Sunlit Realism profiles.
5. **Clouds tab:** height, distance, style, quality, coverage and speed controls.
6. **Water tab:** Natural/Clear/Vanilla style, continuous waviness, RGB color,
   wave mode, reflection, tint strength and opacity. Calm truly means zero waves.
7. **Camera settings:** exposure, gamma, depth-aware sharpness, postprocess zoom
   and subtle focus distance, plus existing controls.
8. **Lighting/bloom:** correct held-light types and foreground material buffers;
   hand-light incidence and occlusion; emissive-driven bloom with restrained
   highlight fallback and resolution-scaled radius. Bloom Off stays off.
9. **Animated, less distorted clouds:** shared world-space layer, smooth noise,
   continuous wind and stable ray integration replace the old implementations.
10. **Clouds from above:** both ray directions intersect the same layer;
    foreground geometry and Distant Horizons clip integration distance.
11. **See-through entities:** opaque entities/block entities write their own
    material/light data and clear stale terrain emission/position. Opaque blending
    is off; explicit translucent passes preserve intended transparency.
12. **Rain angle:** stable world-height shear, independent of scrolling/repeating
    texture coordinates and camera yaw.
13. **Snow angle:** independent angle setting using the same world-space transform
    for snow precipitation.
14. **Dynamic clouds:** dedicated animation switch and speed control.
15. **Dynamic density:** slow time variation and weather-driven coverage;
    independent switch restores fixed coverage.
16. **Remove End Fog:** removed Fog/Dustbound style 9, implementation, label and
    its 8K fog/debris atlas.

Implemented changes are not a claim of completed Minecraft gameplay testing.
