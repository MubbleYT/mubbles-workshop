# Mubble's Colored Lights V0.0.12 — Minecraft 26.3

Put this ZIP into `shaderpacks` and select it in Iris or Vitrail. This is a
shader pack, not a mod JAR. Based on the workshop v32 compact release; retains
its SSBO/compute requirements. Vitrail 0.12.0-beta provides the Vulkan translation.
V0.0.12 repairs cloud styles and clipping. V0.0.11 directional sunlight,
filtered cast shadows, cool sky fill and
distance haze. The v0.0.10 Vitrail loading and preset fixes are retained.
In-game Vitrail rendering still needs verification.

The lighting is an original implementation guided by the supplied visual reference;
no BSL code or assets are included. Use Medium, Default, High or Ultra to enable
cast shadows. Lighting has Sun/Moon Shadows, Shadow Quality (512/1024/2048), Direct
Sunlight and Sky Fill controls. Potato disables sun shadows. Disabling sun shadows
retains a tiny shadow pass for the nearby colored-light collector.

Opaque terrain/entities are relit before water and glass blend over them. Unlit
sealed caves retain zero ambient fill. Shadow alpha testing follows leaf/grass
cutouts, and foliage motion matches the terrain pass. At the shadow-map coverage
edge, direct light fades to a skylight-gated approximation; this is not unlimited
shadow coverage or path tracing.

All 16 requested changes are implemented. See CHANGES.md for the full checklist.
Quality choices: Potato, Low, Medium, Default, High, Ultra. Each resets VHS and
camera effects. VHS is still available independently in Camera. Select a quality
preset to replace previous Custom settings.

- Clouds: style, height, distance, quality, coverage, speed, animation and dynamic
  density. Height positions the flat sheets, or centers the 72-block volumetric
  layer. Quality Off disables every
  style. Disable dynamic density for fixed coverage; disable dynamic clouds to
  freeze motion.
- Water: Natural/Clear/Vanilla, waviness, wave mode, RGB tint, reflection, opacity.
  Waviness 0 or Waves Calm means no waves. Distant Horizons uses cheaper shading.
- Camera: exposure (EV), gamma, sharpness, postprocess zoom and subtle depth-aware
  focus distance, alongside existing film/VHS/lens controls. Focus 0 disables it.
- End: only Earth and Venus are selectable. Fog/Dustbound is removed; other skies
  including IterationT remain. The protected End library is byte-identical.

149 compile/link variants and synthetic cloud/entity/held-light GPU fixtures
passed. Minecraft/Iris gameplay and hardware performance remain untested.
See VALIDATION.md for the tested scope and reproduction scripts.

Designed and directed by Mubble; code primarily generated with AI.
