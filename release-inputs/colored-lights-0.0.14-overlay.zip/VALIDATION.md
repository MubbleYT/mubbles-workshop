# V0.0.14

Distant one-pixel detail filtering verified even when diagonal edge detection
reports flat color. All V0.0.13 checks retained.

# V0.0.13 validation

156 compile/link variants, including AA modes Off/Edge/Distant with both depth
paths. GPU fixtures verify fractional diagonal edge coverage, reduced largest
pixel change during simulated motion, far-detail contrast filtering, preservation
of flat colors/exact black, zero emission from lantern frames, warm ordinary
lantern flame, exact mesh normals in MRT and lighting independent of neighboring
depth discontinuities. Existing sunlight, torch and cloud fixtures pass.
End shaders/assets remain byte-identical to V0.0.12. These are synthetic shader
fixtures, not a Minecraft/Iris/Vitrail gameplay or performance test.

# V0.0.12 cloud validation

149 compile/link variants passed. GPU tests exercise actual clouds.glsl:
all four styles above/below, time animation, foreground clipping, frozen controls,
normal/grazing-angle clear regions, DH inverse-projection clipping, six distinct
style pairs, and quality-independent flat styles. Synthetic panels are not game
screenshots. End shader and texture bytes match the verified V0.0.11 ZIP.
Minecraft/Iris/Vitrail gameplay remains untested.

# V0.0.11 lighting validation

- 149 OpenGL compile/link variants, including the new deferred and shadow passes
  under all six profiles and the Distant Horizons compile path.
- Actual deferred GPU fixture: lit vs cast-shadow material, cooler shadow color,
  filtered shadow edge, rain reduction, dark night, zero-light cave = exact black,
  and passthrough of nonopaque/invalid material buffers.
- Existing entity and both-hand torch GPU fixtures rerun successfully.
- Protected End library byte comparison against the verified V0.0.10 archive.
- ZIP integrity and all packaged PNGs verified before publication.

Reproduce new fixture: `python validation/render_daylight.py`.
The panel PNG is synthetic shader output, not an in-game screenshot or a BSL match.
No Minecraft Vulkan render/performance test is claimed. Verify actual terrain
shadows, transparent objects and far-LOD ordering on the user's Vitrail install.

# V0.0.10 compatibility changes

Compared against Vitrail v0.12.0-beta source (f42e5489c6abff655781b40bebc70338bada3039): required features are served; distance culling preserves the nearby box; presets use its equals-assignment syntax; shadow distance preprocesses to a numeric constant. These are source-conformance checks, not an in-game Vulkan render test.

# V0.0.9 validation

Passed on Mesa 25.2.8 OpenGL 4.5 compatibility context:

- **135 compile/link variants:** all supplied fragment/compute programs; all six
  quality profiles in both dimension folders; four cloud styles with height and
  distance changes; nine End skies with Earth/Venus; VHS and added camera controls;
  water styles/wave modes; Distant Horizons compile paths.
- **Actual cloud-library GPU fixtures:** all four styles visible above and below;
  time changes the image; foreground depth removes clouds; frozen animation/density
  produces identical images.
- **Actual entity fragment GPU fixture:** foreground albedo/color written correctly;
  old terrain emission and position cleared.
- **Actual composite GPU fixtures:** integer held-light uniforms; empty hands black;
  main/offhand torches illuminate dark material; soul torch is bluer than red.
- **Audit:** every profile value and screen control exists, include/texture paths
  exist, held uniform types match Iris, only Earth/Venus exposed, Fog absent.
- **Locked End library:** whole file byte-identical to base, including projection
  functions, call sites and 1.428148 constant.
- Release ZIP integrity and packaged PNG/JSON checks.

Reproduction (Python, NumPy, Pillow, Mesa EGL/OpenGL):

```sh
python validation/compile.py
python validation/render_clouds.py
python validation/render_lighting.py
python validation/audit.py
```

Results are JSON files under validation. Cloud fixture rows: Volumetric, Minecraft
Earth, Layered Vanilla, Dungeons. Columns: below, above, later time. These are
synthetic scenes, not game screenshots.

Still needs in-game verification: Iris loading/patching on the user's 26.3 install,
profile switching in the UI, rain/snow meshes while moving/turning, translucent
entities/armor, resource packs, Voxy integration and hardware performance. Iris
translucent entity routing depends on the installed build. No gameplay pass is
claimed. Distant Horizons water uses simpler distant shading.

Suggested checks: VHS then each quality preset; normal/soul/copper torch in either
hand; fly through/above each cloud style; opaque mob against bright terrain and
behind glass; rotate during rain/snow; Bloom Off; each water/cloud/camera control.

Implementation references: Iris ID uniforms, item.properties, gbuffers,
rendering/blending and entity ordering documentation at shaders.properties.
