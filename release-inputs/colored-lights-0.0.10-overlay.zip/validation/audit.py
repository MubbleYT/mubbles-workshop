from pathlib import Path
import re,json,hashlib,zipfile
S=Path(__file__).resolve().parents[1]/'shaders'
options={}
for p in S.rglob('*'):
 if p.suffix not in ['.fsh','.vsh','.glsl','.csh']:continue
 for k,v,choices in re.findall(r'^#define (\w+) (\S+) // \[([^\]]+)\]',p.read_text(),re.M):
  if k in options:assert options[k]==(v,choices.split()),(k,p,options[k],(v,choices))
  options[k]=(v,choices.split())
 for include in re.findall(r'#include "(/[^"\n]+)"',p.read_text()):assert (S/include.lstrip('/')).is_file()
properties=(S/'shaders.properties').read_text();profiles={}
for line in properties.splitlines():
 if line.startswith('profile.'):
  name,terms=line.split('=',1);terms=dict(term.split('=',1) for term in terms.split());profiles[name.strip()]=terms
  for key,value in terms.items():assert key in options and value in options[key][1],(name,key,value)
  assert terms['VHS_MODE']=='0'
assert set(profiles)=={'profile.POTATO','profile.LOW','profile.MEDIUM','profile.DEFAULT','profile.HIGH','profile.ULTRA'}
assert options['END_PLANET'][1]==['0','6'] and '9' not in options['END_SKY_STYLE'][1]
for line in properties.splitlines():
 if line.startswith('screen'):
  for token in line.split('=',1)[1].split():
   if token.startswith('<') or token.startswith('['):continue
   assert token in options,('missing UI option',token)
for line in properties.splitlines():
 if line.startswith('customTexture.'):
  assert (S/line.split('=',1)[1]).is_file()
locked=S/'lib/end_sky.glsl'; original=Path('/tmp/locked-end-original.glsl')
if original.exists():assert locked.read_bytes()==original.read_bytes()
for p in [S/'composite.fsh',S/'end_space/composite.fsh']:
 assert 'uniform int heldBlockLightValue;' in p.read_text()
 assert 'uniform int heldBlockLightValue2;' in p.read_text()
assert 'dustboundFog' not in (S/'end_space/final.fsh').read_text()
report={'quality_profiles':list(profiles),'option_count':len(options),'all_profile_values_valid':True,'all_screen_controls_exist':True,'includes_and_custom_textures_exist':True,'held_uniform_types_correct':True,'locked_end_library_sha256':hashlib.sha256(locked.read_bytes()).hexdigest(),'locked_end_library_identical_to_base':True}
Path(__file__).with_name('audit-results.json').write_text(json.dumps(report,indent=2))
print('Settings, six profiles, includes, texture paths, and locked End code audit passed.')
