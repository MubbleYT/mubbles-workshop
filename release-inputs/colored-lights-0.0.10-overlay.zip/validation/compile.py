"""Headless Mesa compatibility-context compile/link checks; not an Iris gameplay test."""
import ctypes as C, os, re, json
from pathlib import Path
os.environ['EGL_PLATFORM']='surfaceless'
E=C.CDLL('libEGL.so.1');G=C.CDLL('libGL.so.1')
def sig(lib,name,result,args):
 f=getattr(lib,name);f.restype=result;f.argtypes=args;return f
ptr=C.c_void_p;I=C.c_int;U=C.c_uint
display=sig(E,'eglGetDisplay',ptr,[ptr])(None)
assert sig(E,'eglInitialize',U,[ptr,ptr,ptr])(display,None,None)
assert sig(E,'eglBindAPI',U,[U])(0x30A2)
attrs=(I*7)(0x3040,8,0x3033,1,0x3024,8,0x3038)
config=ptr();num=I()
assert sig(E,'eglChooseConfig',U,[ptr,ptr,ptr,I,ptr])(display,attrs,C.byref(config),1,C.byref(num)) and num.value
ctxattrs=(I*7)(0x3098,4,0x30FB,3,0x30FD,2,0x3038)
ctx=sig(E,'eglCreateContext',ptr,[ptr,ptr,ptr,ptr])(display,config,None,ctxattrs)
assert ctx and sig(E,'eglMakeCurrent',U,[ptr,ptr,ptr,ptr])(display,None,None,ctx)
print(sig(G,'glGetString',C.c_char_p,[U])(0x1F02).decode(),flush=True)
create=sig(G,'glCreateShader',U,[U]);source=sig(G,'glShaderSource',None,[U,I,ptr,ptr]);compile=sig(G,'glCompileShader',None,[U])
status=sig(G,'glGetShaderiv',None,[U,U,ptr]);log=sig(G,'glGetShaderInfoLog',None,[U,I,ptr,ptr]);delete=sig(G,'glDeleteShader',None,[U])
program=sig(G,'glCreateProgram',U,[]);attach=sig(G,'glAttachShader',None,[U,U]);link=sig(G,'glLinkProgram',None,[U]);pstatus=sig(G,'glGetProgramiv',None,[U,U,ptr]);plog=sig(G,'glGetProgramInfoLog',None,[U,I,ptr,ptr]);pdelete=sig(G,'glDeleteProgram',None,[U])
S=Path(__file__).resolve().parents[1]/'shaders'
def expand(path,opts,extra):
 text=path.read_text()
 text=re.sub(r'#include "(/[^"\n]+)"',lambda m:expand(S/m[1].lstrip('/'),opts,{}),text)
 for key,value in opts.items():text=re.sub(r'(#define '+re.escape(key)+r')\s+\S+',r'\g<1> '+str(value),text)
 if '#version' in text:text=text.replace('\n','\n'+''.join('#define '+k+' '+str(v)+'\n' for k,v in extra.items()),1)
 return text
def shader(path,opts,extra):
 stage={'.vsh':0x8B31,'.fsh':0x8B30,'.csh':0x91B9}[path.suffix]
 sid=create(stage);b=expand(path,opts,extra).encode();p=C.c_char_p(b)
 source(sid,1,C.byref(p),None);compile(sid);ok=I();status(sid,0x8B81,C.byref(ok))
 if not ok.value:
  buf=C.create_string_buffer(20000);log(sid,len(buf),None,buf)
  raise RuntimeError(str(path.relative_to(S))+' '+str(opts)+'\n'+buf.value.decode())
 return sid
def pair(path,opts,extra):
 ids=[shader(path,opts,extra)]
 if path.suffix=='.fsh':ids.append(shader(path.with_suffix('.vsh'),opts,extra))
 pid=program()
 for sid in ids:attach(pid,sid)
 link(pid);ok=I();pstatus(pid,0x8B82,C.byref(ok))
 if not ok.value:
  buf=C.create_string_buffer(20000);plog(pid,len(buf),None,buf);raise RuntimeError(str(path)+' link: '+buf.value.decode())
 pdelete(pid)
 for sid in ids:delete(sid)
profiles={}
for line in (S/'shaders.properties').read_text().splitlines():
 if line.startswith('profile.'):
  key,values=line.split('=',1);profiles[key.split('.')[1].strip()]=dict(x.split('=',1) for x in values.split())
checks=[]
def check(p,opts={},extra={}):
 pair(p,opts,extra);checks.append({'file':str(p.relative_to(S)),'options':opts,'defines':extra})
for p in sorted(S.rglob('*')):
 if p.suffix in ['.fsh','.csh']:check(p)
for name,opts in profiles.items():
 for folder in [S,S/'end_space']:
  for name in ['final','composite','gbuffers_water','gbuffers_weather']:check(folder/(name+'.fsh'),opts)
for style in range(4):
 for h in [96.0,384.0]:check(S/'final.fsh',{'CLOUD_STYLE':style,'CLOUD_HEIGHT':h,'CLOUD_DISTANCE':4800.0,'CLOUD_STEPS':24})
for style in range(9):
 for planet in [0,6]:check(S/'end_space/final.fsh',{'END_SKY_STYLE':style,'END_PLANET':planet})
for vhs in [0,1,2]:
 for folder in [S,S/'end_space']:check(folder/'final.fsh',{'VHS_MODE':vhs,'CAMERA_FOCUS':8.0,'CAMERA_SHARPNESS':1.0,'CAMERA_EXPOSURE':2.0,'CAMERA_GAMMA':1.3,'CAMERA_ZOOM':3.0})
for style in range(3):
 for wave in [0,2]:
  for folder in [S,S/'end_space']:check(folder/'gbuffers_water.fsh',{'WATER_STYLE':style,'WATER_WAVES':wave,'WATER_WAVINESS':2.0})
for folder in [S,S/'end_space']:
 for name in ['final','composite','dh_terrain','dh_water']:check(folder/(name+'.fsh'),{}, {'DISTANT_HORIZONS':1})
Path(__file__).with_name('compile-results.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2))
print(str(len(checks))+' compile/link variants passed',flush=True)
