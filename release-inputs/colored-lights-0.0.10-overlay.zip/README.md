# Mubble's Colored Lights V0.0.10 — Minecraft 26.3

Put this ZIP into `shaderpacks` and select it in Iris or Vitrail. This is a
shader pack, not a mod JAR. Based on the workshop v32 compact release; retains
its SSBO/compute requirements. Vitrail 0.12.0-beta provides the Vulkan translation.
V0.0.10 fixes the required-feature rejection and preset parsing; in-game Vitrail
rendering still needs verification.

All 16 requested changes are implemented. See CHANGES.md for the full checklist.
Quality choices: Potato, Low, Medium, Default, High, Ultra. Each resets VHS and
camera effects. VHS is still available independently in Camera. Select a quality
preset to replace previous Custom settings.

- Clouds: style, height, distance, quality, coverage, speed, animation and dynamic
  density. Height is the center of a 72-block layer. Quality Off disables every
  style. Disable dynamic density for fixed coverage; disable dynamic clouds to
  freeze motion.
- Water: Natural/Clear/Vanilla, waviness, wave mode, RGB tint, reflection, opacity.
  Waviness 0 or Waves Calm means no waves. Distant Horizons uses cheaper shading.
- Camera: exposure (EV), gamma, sharpness, postprocess zoom and subtle depth-aware
  focus distance, alongside existing film/VHS/lens controls. Focus 0 disables it.
- End: only Earth and Venus are selectable. Fog/Dustbound is removed; other skies
  including IterationT remain. The protected End library is byte-identical.

135 compile/link variants and synthetic cloud/entity/held-light GPU fixtures
passed. Minecraft/Iris gameplay and hardware performance remain untested.
See VALIDATION.md for the tested scope and reproduction scripts.

Designed and directed by Mubble; code primarily generated with AI.
