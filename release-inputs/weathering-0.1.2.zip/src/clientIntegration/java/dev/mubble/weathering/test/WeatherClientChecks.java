package dev.mubble.weathering.test;
import dev.mubble.weathering.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.core.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Test-only real client/model and item-interaction checks. */
public final class WeatherClientChecks implements ClientModInitializer {
    private final AtomicBoolean ready=new AtomicBoolean();
    private boolean requested;
    private int tick,passed;
    private void check(boolean value,String name) { if(!value) throw new AssertionError(name);passed++;System.out.println("WEATHER CLIENT PASS "+name); }
    public void onInitializeClient() { ClientTickEvents.END_CLIENT_TICK.register(client->{try{run(client);}catch(Throwable e){System.out.println("WEATHER CLIENT CHECKS FAILED");e.printStackTrace();client.stop();}}); }
    private void run(Minecraft client) {
        if(client.gui.screen() instanceof net.minecraft.client.gui.screens.AccessibilityOnboardingScreen screen) screen.onClose();
        if(client.level==null || client.player==null || !client.hasSingleplayerServer()) return;
        if(!requested) {
            requested=true; client.options.pauseOnLostFocus=false;client.options.renderDistance().set(2);client.options.framerateLimit().set(30);
            client.getSingleplayerServer().execute(()->{
                try {
                    var server=client.getSingleplayerServer();var level=server.overworld();Weathering.config().enabled=false;
                    for(int x=-3;x<34;x++) for(int z=-12;z<=8;z++) {
                        level.setBlockAndUpdate(new BlockPos(x,99,z),Blocks.SMOOTH_STONE.defaultBlockState());
                        for(int y=100;y<=106;y++)level.setBlockAndUpdate(new BlockPos(x,y,z),Blocks.AIR.defaultBlockState());
                    }
                    for(int x=-3;x<34;x++)for(int y=100;y<=105;y++)level.setBlockAndUpdate(new BlockPos(x,y,8),Blocks.QUARTZ_BLOCK.defaultBlockState());
                    var materials=List.of(Blocks.OAK_PLANKS,Blocks.STONE_BRICKS,Blocks.SANDSTONE,Blocks.SPRUCE_PLANKS,Blocks.BRICKS);
                    for(int i=0;i<materials.size();i++) for(int stage=0;stage<=3;stage++) {
                        Block base=materials.get(i);Block target=WeatherBlocks.WOOD.getOrDefault(base,WeatherBlocks.MOSS.get(base));
                        var state=stage==0?base.defaultBlockState():target.defaultBlockState().setValue(WeatherBlocks.MOSS_STAGE,stage);
                        for(int y=100;y<=103;y++) level.setBlockAndUpdate(new BlockPos(i*5+stage,y,4),state);
                    }
                    for(int stage=1;stage<=3;stage++) {
                        level.setBlockAndUpdate(new BlockPos(9+stage*2,100,1),WeatherBlocks.MOSS.get(Blocks.STONE_BRICK_STAIRS).defaultBlockState().setValue(WeatherBlocks.MOSS_STAGE,stage));
                        level.setBlockAndUpdate(new BlockPos(9+stage*2,100,-1),WeatherBlocks.WOOD.get(Blocks.OAK_SLAB).defaultBlockState().setValue(WeatherBlocks.MOSS_STAGE,stage));
                    }
                    var player=server.getPlayerList().getPlayers().getFirst();
                    var testPos=new BlockPos(30,100,4);level.setBlockAndUpdate(testPos,Blocks.OAK_PLANKS.defaultBlockState());
                    player.setGameMode(GameType.SURVIVAL);player.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.HONEYCOMB,2));
                    var hit=new BlockHitResult(Vec3.atCenterOf(testPos),Direction.UP,testPos,false);
                    var result=UseBlockCallback.EVENT.invoker().interact(player,level,InteractionHand.MAIN_HAND,hit);
                    check(result.consumesAction() && Weathering.state(level).sealed(testPos),"real honeycomb use seals block");
                    check(player.getMainHandItem().getCount()==1,"survival sealing consumes one honeycomb");
                    player.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.IRON_AXE));player.setShiftKeyDown(true);
                    result=UseBlockCallback.EVENT.invoker().interact(player,level,InteractionHand.MAIN_HAND,hit);
                    check(result.consumesAction() && !Weathering.state(level).sealed(testPos),"sneak axe use removes protection");
                    check(player.getMainHandItem().getDamageValue()==1,"unsealing uses axe durability");player.setShiftKeyDown(false);
                    level.setBlockAndUpdate(testPos,WeatherBlocks.WOOD.get(Blocks.OAK_PLANKS).defaultBlockState());
                    result=UseBlockCallback.EVENT.invoker().interact(player,level,InteractionHand.MAIN_HAND,hit);
                    check(result.consumesAction() && level.getBlockState(testPos).is(Blocks.OAK_PLANKS),"axe use scrapes moss from wood");
                    check(player.getMainHandItem().getDamageValue()==2,"scraping uses axe durability");
                    player.setGameMode(GameType.CREATIVE);player.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);
                    server.getCommands().performPrefixedCommand(server.createCommandSourceStack(),"time set noon");
                    player.teleportTo(level,12.5,102,-10.5,Set.of(),0,5,false);ready.set(true);
                } catch(Throwable e) { System.out.println("WEATHER CLIENT CHECKS FAILED");e.printStackTrace();client.execute(client::stop); }
            });
        }
        if(!ready.get())return;
        if(++tick==140) {
            var models=client.getModelManager().getBlockStateModelSet();
            for(var block:WeatherBlocks.ORIGINAL.keySet()) {
                boolean valid=block.getStateDefinition().getPossibleStates().stream().allMatch(state->models.get(state)!=models.missingModel());
                check(valid,"all states have a baked model: "+block);
            }
            Screenshot.grab(client.gameDirectory,"mubbles-weathering-gallery.png",client.gameRenderer.mainRenderTarget(),1,message->System.out.println("WEATHER CLIENT CAPTURE "+message.getString()));
        }
        if(tick==180) {System.out.println("WEATHER CLIENT CHECKS PASSED "+passed);client.stop();}
    }
}
