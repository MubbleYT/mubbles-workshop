package dev.mubble.weathering.test;
import dev.mubble.weathering.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import java.util.*;

/** Separate QA mod, excluded from playable JAR. */
public final class WeatherServerChecks implements ModInitializer {
    private int tick,passed;
    private final BlockPos protectedPos=new BlockPos(33,100,4), hidden=new BlockPos(36,100,4), unload=new BlockPos(67,100,4),reset=new BlockPos(39,100,4);
    private double unloadAge;
    private net.minecraft.world.level.chunk.LevelChunk unloadedChunk;
    private void check(boolean value,String name) { if(!value) throw new AssertionError(name);passed++;System.out.println("WEATHER PASS "+name); }
    public void onInitialize() { ServerTickEvents.END_SERVER_TICK.register(server->{try{run(server);}catch(Throwable e){System.out.println("WEATHER CHECKS FAILED");e.printStackTrace();server.halt(false);}}); }
    private void command(MinecraftServer server,String command) { server.getCommands().performPrefixedCommand(server.createCommandSourceStack(),command); }
    private void run(MinecraftServer server) {
        tick++; var level=server.overworld(); var weather=Weathering.state(level);
        if(tick==1) { command(server,"forceload add 0 0 79 15"); if(!Boolean.getBoolean("weather.test.restart")) { var c=Weathering.config();c.minDays=.005;c.maxDays=.012;c.checkIntervalTicks=1;c.checksPerInterval=4096; } }
        if(Boolean.getBoolean("weather.test.restart")) {
            if(tick==60) {
                check(weather.sealed(protectedPos),"honeycomb protection persisted across real server restart");
                check(level.getBlockState(protectedPos).is(Blocks.OAK_PLANKS),"protected block survived restart unchanged");
                check(WeatherBlocks.ORIGINAL.containsKey(level.getBlockState(new BlockPos(3,100,4)).getBlock()),"mossy wood world block persisted across restart");
                check(weather.exposure(hidden)==0,"sheltered block has no offline aging");
                System.out.println("WEATHER RESTART CHECKS PASSED "+passed);server.halt(false);
            }
            return;
        }
        if(tick==60) {
            check(WeatherBlocks.WOOD.size()==81,"81 mossy wood variants registered");
            var fire=net.fabricmc.fabric.api.registry.FlammableBlockRegistry.getDefaultInstance();
            check(fire.get(Blocks.OAK_PLANKS)!=null && WeatherBlocks.WOOD.entrySet().stream().allMatch(pair->Objects.equals(fire.get(pair.getKey()),fire.get(pair.getValue()))),"all wood fire behavior retained");
            for(var pair:WeatherBlocks.WOOD.entrySet()) {
                boolean correct=true;
                for(var original:pair.getKey().getStateDefinition().getPossibleStates()) {
                    var target=WeatherBlocks.next(original,true);
                    correct &= target!=null && target.getBlock()==pair.getValue();
                    correct &= WeatherBlocks.restore(target).equals(original);
                    correct &= original.getCollisionShape(level,protectedPos).toAabbs().equals(target.getCollisionShape(level,protectedPos).toAabbs());
                }
                check(correct,"all orientations, waterlogging and collision shapes preserved: "+pair.getKey());
                check(Objects.equals(pair.getKey().asItem().components().get(net.minecraft.core.component.DataComponents.COOKING_FUEL),pair.getValue().asItem().components().get(net.minecraft.core.component.DataComponents.COOKING_FUEL)),"wood fuel behavior retained: "+pair.getKey());
                var drops=Block.getDrops(pair.getValue().defaultBlockState(),level,protectedPos,null);
                check(drops.size()==1 && drops.getFirst().is(pair.getValue().asItem()),"weathered block drops its own item: "+pair.getValue());
            }
            check(WeatherBlocks.ORIGINAL.size()==483,"81 wood and 402 masonry variants registered");
            for(var pair:WeatherBlocks.ORIGINAL.entrySet()) if(!WeatherBlocks.WOOD.containsKey(pair.getValue())) {
                boolean correct=true;
                for(var original:pair.getValue().getStateDefinition().getPossibleStates()) {
                    var target=WeatherBlocks.properties(original,pair.getKey().defaultBlockState());
                    correct &= WeatherBlocks.restore(target).equals(original);
                    correct &= original.getCollisionShape(level,protectedPos).toAabbs().equals(target.getCollisionShape(level,protectedPos).toAabbs());
                    correct &= !(target.getBlock() instanceof InfestedBlock);
                }
                check(correct,"masonry states and geometry preserved: "+pair.getKey());
                var masonryDrops=Block.getDrops(pair.getKey().defaultBlockState(),level,protectedPos,null);
                check(masonryDrops.size()==1 && masonryDrops.getFirst().is(pair.getKey().asItem()),"masonry drops correct: "+pair.getKey());
            }
            for(var pair:WeatherBlocks.ORIGINAL.entrySet()) if(pair.getKey().defaultBlockState().hasProperty(WeatherBlocks.MOSS_STAGE)) {
                var light=pair.getKey().defaultBlockState().setValue(WeatherBlocks.MOSS_STAGE,1);
                var medium=WeatherBlocks.next(light,true);var full=WeatherBlocks.next(medium,true);
                check(medium.getValue(WeatherBlocks.MOSS_STAGE)==2 && full.getValue(WeatherBlocks.MOSS_STAGE)==3,"moss stages advance: "+pair.getKey());
                check(WeatherBlocks.next(full,true)==null && !WeatherBlocks.eligible(full),"full moss is final: "+pair.getKey());
                check(WeatherBlocks.restore(light).is(pair.getValue()) && WeatherBlocks.restore(full).is(pair.getValue()),"each moss stage restores base: "+pair.getKey());
                check(WeatherBlocks.next(light,false)!=null == WeatherBlocks.WOOD.containsKey(pair.getValue()),"masonry moss pauses when dry: "+pair.getKey());
                var stageDrops=Block.getDrops(light,level,protectedPos,null);
                var data=stageDrops.getFirst().get(net.minecraft.core.component.DataComponents.BLOCK_STATE);
                check(data!=null && data.properties().get("moss_stage").equals("1"),"drops retain moss stage: "+pair.getKey());
            }
            // Regression: a full terrain budget must not prevent placed stone from aging.
            level.setBlockAndUpdate(new BlockPos(28,100,4),Blocks.AIR.defaultBlockState());
            level.setBlockAndUpdate(new BlockPos(28,100,4),Blocks.OAK_PLANKS.defaultBlockState());
            int cap=Weathering.config().maxTrackedBlocksPerDimension;
            Weathering.config().maxTrackedBlocksPerDimension=weather.size();
            var priority=new BlockPos(24,100,4);level.setBlockAndUpdate(priority,Blocks.AIR.defaultBlockState());level.setBlockAndUpdate(priority,Blocks.STONE_BRICKS.defaultBlockState());
            check(weather.inspect(priority).contains("exposure="),"placed stone tracked when terrain budget full");
            Weathering.config().maxTrackedBlocksPerDimension=cap;
            var oakSlab=WeatherBlocks.WOOD.get(Blocks.OAK_SLAB);
            var drops=Block.getDrops(oakSlab.defaultBlockState().setValue(SlabBlock.TYPE,SlabType.DOUBLE),level,protectedPos,null);
            check(drops.size()==1 && drops.getFirst().getCount()==2,"double mossy slabs drop two items");
            check(!WeatherBlocks.eligible(Blocks.CHEST.defaultBlockState()),"block entities excluded");
            check(!WeatherBlocks.eligible(Blocks.INFESTED_STONE.defaultBlockState()),"infested blocks excluded");
            check(!WeatherBlocks.eligible(Blocks.CRIMSON_PLANKS.defaultBlockState()),"Nether fungal wood excluded");
            for(var original:WeatherBlocks.MOSS.keySet()) check(!(WeatherBlocks.next(original.defaultBlockState(),true).getBlock() instanceof InfestedBlock),"moss route never infested: "+original);
            var masonry=Blocks.STONE_BRICK_STAIRS.defaultBlockState().setValue(StairBlock.FACING,Direction.WEST).setValue(StairBlock.HALF,Half.TOP).setValue(StairBlock.WATERLOGGED,true);
            check(WeatherBlocks.next(masonry,true).getBlock()==WeatherBlocks.MOSS.get(Blocks.STONE_BRICK_STAIRS) && WeatherBlocks.next(masonry,true).getValue(StairBlock.WATERLOGGED),"stone stairs retain facing, half, and waterlogging");
            int[] xs={3,6,9,12,15,18,33,36,39,67};
            for(int x:xs) { level.setBlockAndUpdate(new BlockPos(x,100,4),Blocks.AIR.defaultBlockState()); level.setBlockAndUpdate(new BlockPos(x,99,4),Blocks.BARRIER.defaultBlockState()); }
            level.setBlockAndUpdate(new BlockPos(3,100,4),Blocks.OAK_PLANKS.defaultBlockState());
            level.setBlockAndUpdate(new BlockPos(6,100,4),Blocks.STONE_BRICKS.defaultBlockState());
            level.setBlockAndUpdate(new BlockPos(9,100,4),Blocks.STONE_BRICKS.defaultBlockState());
            level.setBlockAndUpdate(new BlockPos(9,99,4),Blocks.MOSS_BLOCK.defaultBlockState());
            level.setBlockAndUpdate(new BlockPos(12,100,4),Blocks.COBBLESTONE.defaultBlockState());
            level.setBlockAndUpdate(new BlockPos(12,99,4),Blocks.MOSS_BLOCK.defaultBlockState());
            level.setBlockAndUpdate(new BlockPos(15,100,4),Blocks.STONE.defaultBlockState());
            level.setBlockAndUpdate(new BlockPos(18,100,4),Blocks.DEEPSLATE.defaultBlockState().setValue(RotatedPillarBlock.AXIS,Direction.Axis.X));
            level.setBlockAndUpdate(protectedPos,Blocks.OAK_PLANKS.defaultBlockState());
            check(weather.seal(protectedPos),"honeycomb protection applies");
            level.setBlockAndUpdate(hidden,Blocks.SPRUCE_PLANKS.defaultBlockState());
            for(Direction d:Direction.values()) level.setBlockAndUpdate(hidden.relative(d),Blocks.BARRIER.defaultBlockState());
            level.setBlockAndUpdate(reset,Blocks.OAK_PLANKS.defaultBlockState());
            level.setBlockAndUpdate(unload,Blocks.OAK_PLANKS.defaultBlockState());
            check(!weather.ageNow(protectedPos),"manual age respects protection");
        }
        if(tick==100) {
            check(weather.exposure(reset)>0,"loaded exposed wood accumulates age");
            level.setBlockAndUpdate(reset,Blocks.AIR.defaultBlockState());
            level.setBlockAndUpdate(reset,Blocks.OAK_PLANKS.defaultBlockState());
            check(weather.exposure(reset)==0,"replacement resets age");
            unloadedChunk=level.getChunkAt(unload);weather.unloaded(unloadedChunk);unloadAge=weather.exposure(unload);
        }
        if(tick==160) {
            check(weather.exposure(unload)==unloadAge,"unloaded blocks stop accumulating age");
            weather.loaded(unloadedChunk);
            Weathering.config().enabled=false;weather.pause();unloadAge=weather.exposure(unload);
        }
        if(tick==220) {
            check(weather.exposure(unload)==unloadAge,"disabled mod pauses age");
            Weathering.config().enabled=true;weather.pause();
            check(weather.unseal(protectedPos),"protection can be removed");
            check(weather.seal(protectedPos),"protection can be reapplied");
        }
        if(tick==1160) {
            check(WeatherBlocks.ORIGINAL.containsKey(level.getBlockState(new BlockPos(3,100,4)).getBlock()),"wood naturally ages to mossy wood");
            check(level.getBlockState(new BlockPos(3,100,4)).getValue(WeatherBlocks.MOSS_STAGE)==3,"wood naturally completes all three moss stages");
            check(level.getBlockState(new BlockPos(9,100,4)).getValue(WeatherBlocks.MOSS_STAGE)==3,"damp stone naturally completes all three moss stages");
            check(weather.wet(new BlockPos(10,100,4)),"medium or full moss spreads dampness to adjacent blocks");
            check(level.getBlockState(new BlockPos(6,100,4)).is(Blocks.CRACKED_STONE_BRICKS),"dry stone bricks naturally crack");
            check(level.getBlockState(new BlockPos(9,100,4)).getBlock()==WeatherBlocks.MOSS.get(Blocks.STONE_BRICKS),"wet stone bricks naturally grow moss");
            check(level.getBlockState(new BlockPos(12,100,4)).getBlock()==WeatherBlocks.MOSS.get(Blocks.COBBLESTONE),"wet cobblestone naturally grows moss");
            check(level.getBlockState(new BlockPos(15,100,4)).is(Blocks.COBBLESTONE),"exposed stone naturally roughens");
            check(level.getBlockState(new BlockPos(18,100,4)).is(Blocks.COBBLED_DEEPSLATE),"deepslate naturally roughens");
            check(level.getBlockState(protectedPos).is(Blocks.OAK_PLANKS),"protected wood stays unchanged");
            check(level.getBlockState(hidden).is(Blocks.SPRUCE_PLANKS) && weather.exposure(hidden)==0,"fully enclosed wood stays unchanged");
            check(weather.restore(reset) && level.getBlockState(reset).is(Blocks.OAK_PLANKS),"moss can be scraped back to original wood");
            for(var pos:List.of(new BlockPos(3,100,4),new BlockPos(6,100,4),new BlockPos(9,100,4),new BlockPos(12,100,4))) check(!(level.getBlockState(pos).getBlock() instanceof InfestedBlock),"runtime output never infested at "+pos);
            command(server,"mubbleweathering status");weather.save();
            System.out.println("WEATHER SERVER CHECKS PASSED "+passed);server.halt(false);
        }
    }
}
