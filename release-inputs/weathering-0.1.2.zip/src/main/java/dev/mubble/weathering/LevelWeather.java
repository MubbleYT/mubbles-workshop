package dev.mubble.weathering;
import com.google.gson.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.storage.LevelResource;
import java.nio.file.*;
import java.util.*;

/** All access is on the logical server thread. Only loaded chunks are inspected. */
public final class LevelWeather {
    public static final class Age {
        public String state;
        public double exposure, deadline;
        public boolean sealed;
        public boolean discovered;
        transient long lastTick;
        transient double rate;
    }
    private record Scan(LevelChunk chunk,int section) {}
    private final ServerLevel level;
    private final Map<Long,Age> ages=new HashMap<>();
    private final Map<Long,Set<Long>> perChunk=new HashMap<>();
    private final Map<Long,LevelChunk> loaded=new HashMap<>();
    private final ArrayDeque<Long> queue=new ArrayDeque<>();
    private final Set<Long> active=new HashSet<>();
    private final ArrayDeque<Scan> scans=new ArrayDeque<>();
    private final Random random=new Random();
    private boolean internalChange, warned;
    private long changed;
    LevelWeather(ServerLevel level) { this.level=level; read(); }
    private long now() { return level.getGameTime(); }
    private Path path() {
        var id=level.dimension().identifier();
        return level.getServer().getWorldPath(LevelResource.ROOT).resolve("mubble-weathering").resolve(id.getNamespace()).resolve(id.getPath()+".json");
    }
    private void read() {
        try {
            if (!Files.exists(path())) return;
            var json=JsonParser.parseString(Files.readString(path())).getAsJsonObject();
            for (var pair:json.entrySet()) {
                if (ages.size()>=Weathering.config().maxTrackedBlocksPerDimension) break;
                Age age=WeatherConfig.JSON.fromJson(pair.getValue(),Age.class);
                if (age==null || age.state==null || !Double.isFinite(age.exposure) || !Double.isFinite(age.deadline)
                    || age.exposure<0 || age.deadline<=0) continue;
                long key=Long.parseLong(pair.getKey()); ages.put(key,age);
                perChunk.computeIfAbsent(ChunkPos.pack(BlockPos.of(key)),ignored->new HashSet<>()).add(key);
            }
        } catch (Exception e) { Weathering.LOGGER.error("Could not read saved weathering ages for "+level.dimension(),e); }
    }
    public void save() {
        try {
            // No elapsed wall-clock/offline time is included in the save.
            var json=new JsonObject(); ages.forEach((key,age)->json.add(Long.toString(key),WeatherConfig.JSON.toJsonTree(age)));
            WeatherConfig.atomic(path(),json.toString());
        } catch (Exception e) { Weathering.LOGGER.error("Could not save weathering ages",e); }
    }
    private Age add(BlockPos pos,BlockState state) { return add(pos,state,false); }
    private Age add(BlockPos pos,BlockState state,boolean discovered) {
        long key=pos.asLong(); Age age=ages.get(key);
        if (age==null) {
            int limit=Weathering.config().maxTrackedBlocksPerDimension;
            if(discovered && ages.size()>=limit*3/4) return null; // Reserve space for player builds.
            if(ages.size()>=limit) {
                Long victim=null;
                for(var entry:ages.entrySet()) if(entry.getValue().discovered && !entry.getValue().sealed) {victim=entry.getKey();break;}
                if(victim==null) for(var entry:ages.entrySet()) if(!entry.getValue().sealed) {victim=entry.getKey();break;}
                if(victim==null) return null;
                remove(victim);
            }
            var c=Weathering.config(); age=new Age(); age.discovered=discovered; age.state=state.toString();
            age.deadline=(c.minDays+random.nextDouble()*(c.maxDays-c.minDays))*24000;
            ages.put(key,age); perChunk.computeIfAbsent(ChunkPos.pack(pos),ignored->new HashSet<>()).add(key);
        }
        if (loaded.containsKey(ChunkPos.pack(pos)) && active.add(key)) { age.lastTick=now(); age.rate=0; queue.addLast(key); }
        return age;
    }
    private void remove(long key) {
        ages.remove(key); active.remove(key); queue.removeIf(slot->slot==key);
        var set=perChunk.get(ChunkPos.pack(BlockPos.of(key)));
        if (set!=null) { set.remove(key); if(set.isEmpty()) perChunk.remove(ChunkPos.pack(BlockPos.of(key))); }
        // Queue slots are discarded lazily. There can be no stale age object retained by a slot.
    }
    public void loaded(LevelChunk chunk) {
        long chunkKey=chunk.getPos().pack(); loaded.put(chunkKey,chunk); scans.addLast(new Scan(chunk,0));
        var positions=perChunk.get(chunkKey);
        if (positions!=null) for(long key:List.copyOf(positions)) {
            Age age=ages.get(key); BlockState block=chunk.getBlockState(BlockPos.of(key));
            if (!block.toString().equals(age.state)) { remove(key); continue; }
            add(BlockPos.of(key),block);
        }
    }
    public void unloaded(LevelChunk chunk) {
        long chunkKey=chunk.getPos().pack(); loaded.remove(chunkKey);
        var positions=perChunk.get(chunkKey);
        if(positions!=null) for(long key:positions) {
            Age age=ages.get(key);
            if(active.remove(key)) { if(Weathering.config().enabled && !age.sealed) age.exposure+=Math.max(0,now()-age.lastTick)*age.rate; age.lastTick=now(); age.rate=0; }
        }
        queue.removeIf(key->ChunkPos.pack(BlockPos.of(key))==chunkKey);
        scans.removeIf(scan->scan.chunk().getPos().pack()==chunkKey);
    }
    public void blockChanged(BlockPos pos,BlockState oldState,BlockState state) {
        if(internalChange) return;
        long key=pos.asLong(); Age age=ages.get(key);
        if(age!=null && oldState.getBlock()!=state.getBlock()) remove(key);
        else if(age!=null) age.state=state.toString();
        if(WeatherBlocks.eligible(state) && exposed(pos)) add(pos,state);
        for(Direction direction:Direction.values()) {
            BlockPos neighbor=pos.relative(direction);
            if(!loaded.containsKey(ChunkPos.pack(neighbor))) continue;
            var adjacent=level.getBlockState(neighbor);
            if(WeatherBlocks.eligible(adjacent) && exposed(neighbor)) add(neighbor,adjacent,true);
        }
    }
    private void scan() {
        int budget=Weathering.config().scanSectionsPerTick;
        while(budget-->0 && !scans.isEmpty()) {
            Scan job=scans.removeFirst(); LevelChunk chunk=job.chunk();
            if(loaded.get(chunk.getPos().pack())!=chunk) continue;
            var sections=chunk.getSections(); if(job.section()>=sections.length) continue;
            var section=sections[job.section()];
            if(section.maybeHas(WeatherBlocks::eligible)) {
                int yBase=chunk.getMinY()+16*job.section(),xBase=chunk.getPos().getMinBlockX(),zBase=chunk.getPos().getMinBlockZ();
                for(int y=0;y<16;y++) for(int z=0;z<16;z++) for(int x=0;x<16;x++) {
                    var block=section.getBlockState(x,y,z);
                    if(WeatherBlocks.eligible(block)) {
                        var position=new BlockPos(xBase+x,yBase+y,zBase+z);
                        if(exposed(position)) add(position,block,true);
                    }
                }
            }
            if(job.section()+1<sections.length) scans.addLast(new Scan(chunk,job.section()+1));
        }
    }
    public boolean exposed(BlockPos pos) {
        for(Direction direction:Direction.values()) {
            BlockPos neighbor=pos.relative(direction);
            if(!loaded.containsKey(ChunkPos.pack(neighbor))) continue;
            BlockState block=level.getBlockState(neighbor);
            if(block.isAir() || block.getFluidState().is(FluidTags.WATER)) return true;
        }
        return false;
    }
    public boolean wet(BlockPos pos) {
        if(level.isRainingAt(pos.above())) return true;
        for(Direction direction:Direction.values()) {
            BlockPos neighbor=pos.relative(direction);
            if(!loaded.containsKey(ChunkPos.pack(neighbor))) continue;
            var block=level.getBlockState(neighbor);
            if(block.getFluidState().is(FluidTags.WATER) || block.is(Blocks.MOSS_BLOCK) || block.is(Blocks.MOSS_CARPET) || (block.hasProperty(WeatherBlocks.MOSS_STAGE) && block.getValue(WeatherBlocks.MOSS_STAGE)>=2)) return true;
        }
        return false;
    }
    public void tick() {
        scan(); var c=Weathering.config();
        if(now()%6000==0) save();
        if(now()%c.checkIntervalTicks!=0) return;
        int budget=Math.min(c.checksPerInterval,queue.size());
        while(budget-->0 && !queue.isEmpty()) {
            long key=queue.removeFirst(); if(!active.contains(key)) continue;
            Age age=ages.get(key); if(age==null) { active.remove(key); continue; }
            BlockPos pos=BlockPos.of(key); var block=level.getBlockState(pos);
            if(!block.toString().equals(age.state)) { remove(key); if(WeatherBlocks.eligible(block)) add(pos,block); continue; }
            boolean surface=exposed(pos), damp=surface && wet(pos);
            double rate=c.enabled && !age.sealed && surface && WeatherBlocks.canProgress(block,damp) ? (damp?c.wetSpeedMultiplier:1) : 0;
            age.exposure+=Math.max(0,now()-age.lastTick)*rate; age.lastTick=now(); age.rate=rate;
            if(rate>0 && age.exposure>=age.deadline) {
                BlockState next=WeatherBlocks.next(block,damp);
                if(next!=null) { change(pos,next); continue; }
            }
            queue.addLast(key);
        }
    }
    private void change(BlockPos pos,BlockState next) {
        if(next.getBlock() instanceof InfestedBlock || next.hasBlockEntity()) throw new IllegalStateException("Unsafe weathering target");
        remove(pos.asLong()); internalChange=true;
        try { level.setBlockAndUpdate(pos,next); changed++; }
        finally { internalChange=false; }
        if(WeatherBlocks.eligible(next)) add(pos,next);
    }
    public boolean ageNow(BlockPos pos) {
        var block=level.getBlockState(pos); if(!WeatherBlocks.eligible(block)) return false;
        Age age=ages.get(pos.asLong()); if(age!=null && age.sealed) return false;
        BlockState next=WeatherBlocks.next(block,wet(pos)); if(next==null) return false;
        change(pos,next); return true;
    }
    public boolean seal(BlockPos pos) {
        var block=level.getBlockState(pos); if(!WeatherBlocks.eligible(block) && !WeatherBlocks.ORIGINAL.containsKey(block.getBlock())) return false;
        Age age=add(pos,block); if(age==null || age.sealed) return false;
        age.sealed=true; age.rate=0; return true;
    }
    public boolean unseal(BlockPos pos) { Age age=ages.get(pos.asLong()); if(age==null || !age.sealed) return false; age.sealed=false; age.lastTick=now(); return true; }
    public boolean restore(BlockPos pos) { BlockState base=WeatherBlocks.restore(level.getBlockState(pos)); if(base==null) return false; change(pos,base); return true; }
    public boolean sealed(BlockPos pos) { Age age=ages.get(pos.asLong()); return age!=null && age.sealed; }
    public String inspect(BlockPos pos) {
        var block=level.getBlockState(pos); Age age=ages.get(pos.asLong());
        return "eligible="+WeatherBlocks.eligible(block)+"; exposed="+exposed(pos)+"; damp="+wet(pos)
            +"; "+(age==null?"not tracked yet":"protected="+age.sealed+"; exposure="+(long)age.exposure+" / "+(long)age.deadline+" ticks")
            +"; moss stage="+(block.hasProperty(WeatherBlocks.MOSS_STAGE)?block.getValue(WeatherBlocks.MOSS_STAGE)+"/3":"none")+"; enabled="+Weathering.config().enabled;
    }
    public double exposure(BlockPos pos) { Age age=ages.get(pos.asLong()); return age==null?0:age.exposure; }
    public void pause() { for(var age:ages.values()) { age.lastTick=now(); age.rate=0; } }
    public int size() { return ages.size(); }
    public long changes() { return changed; }
}
