package dev.mubble.weathering;
import com.google.gson.*;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.*;
import net.minecraft.resources.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.Property;
import java.io.*;
import java.util.*;

public final class WeatherBlocks {
    public static final Map<Block,Block> WOOD = new LinkedHashMap<>(), ORIGINAL = new HashMap<>();
    public static final Map<Block,Block> MOSS = new HashMap<>(), CRACK = new HashMap<>(), ROUGH = new HashMap<>();
    private static class WeatherStairs extends StairBlock {
        WeatherStairs(BlockState base, BlockBehaviour.Properties settings) { super(base,settings); }
    }
    public static final net.minecraft.world.level.block.state.properties.IntegerProperty MOSS_STAGE = net.minecraft.world.level.block.state.properties.IntegerProperty.create("moss_stage",1,3);
    private static class MossBlock extends Block {
        MossBlock(BlockBehaviour.Properties p){super(p);registerDefaultState(defaultBlockState().setValue(MOSS_STAGE,3));}
        protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){super.createBlockStateDefinition(b);b.add(MOSS_STAGE);}
    }
    private static class MossPillar extends RotatedPillarBlock {
        MossPillar(BlockBehaviour.Properties p){super(p);registerDefaultState(defaultBlockState().setValue(MOSS_STAGE,3));}
        protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){super.createBlockStateDefinition(b);b.add(MOSS_STAGE);}
    }
    private static class MossStairs extends StairBlock {
        MossStairs(BlockState base,BlockBehaviour.Properties p){super(base,p);registerDefaultState(defaultBlockState().setValue(MOSS_STAGE,3));}
        protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){super.createBlockStateDefinition(b);b.add(MOSS_STAGE);}
    }
    private static class MossSlab extends SlabBlock {
        MossSlab(BlockBehaviour.Properties p){super(p);registerDefaultState(defaultBlockState().setValue(MOSS_STAGE,3));}
        protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){super.createBlockStateDefinition(b);b.add(MOSS_STAGE);}
    }
    private static class MossFence extends FenceBlock {
        MossFence(BlockBehaviour.Properties p){super(p);registerDefaultState(defaultBlockState().setValue(MOSS_STAGE,3));}
        protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){super.createBlockStateDefinition(b);b.add(MOSS_STAGE);}
    }
    private static class MossWall extends WallBlock {
        MossWall(BlockBehaviour.Properties p){super(p);registerDefaultState(defaultBlockState().setValue(MOSS_STAGE,3));}
        protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){super.createBlockStateDefinition(b);b.add(MOSS_STAGE);}
    }
    private static Block mossBlock(String shape,Block base,BlockBehaviour.Properties p) {
        return switch(shape){case "pillar" -> new MossPillar(p);case "stairs" -> new MossStairs(base.defaultBlockState(),p);case "slab" -> new MossSlab(p);case "fence" -> new MossFence(p);case "wall" -> new MossWall(p);default -> new MossBlock(p);};
    }
    public static void initialize() {
        try (var in = WeatherBlocks.class.getResourceAsStream("/weathering-materials.json")) {
            var definitions = JsonParser.parseReader(new InputStreamReader(Objects.requireNonNull(in))).getAsJsonArray();
            for (var definition : definitions) {
                var d = definition.getAsJsonObject(); String name = d.get("base").getAsString();
                Block base = BuiltInRegistries.BLOCK.getValue(Identifier.withDefaultNamespace(name));
                if (base == null || base == Blocks.AIR) throw new IllegalArgumentException("Unknown wood: "+name);
                var id = Identifier.fromNamespaceAndPath("mubble_weathering","mossy_"+name);
                var key = ResourceKey.create(Registries.BLOCK,id);
                var settings = BlockBehaviour.Properties.ofFullCopy(base).setId(key).overrideLootTable(Optional.of(ResourceKey.create(Registries.LOOT_TABLE,id.withPrefix("blocks/"))));
                Block mossy=mossBlock(d.get("shape").getAsString(),base,settings);
                Registry.register(BuiltInRegistries.BLOCK,key,mossy);
                var itemSettings=new Item.Properties().setId(ResourceKey.create(Registries.ITEM,id)).useBlockDescriptionPrefix();
                itemSettings.cookingFuel(d.get("shape").getAsString().equals("slab")
                    ? net.minecraft.world.level.storage.loot.providers.number.ints.ContextIntProviders.COOKING_TIME_WOOD_SLABS
                    : net.minecraft.world.level.storage.loot.providers.number.ints.ContextIntProviders.COOKING_TIME_WOOD_BLOCKS);
                Registry.register(BuiltInRegistries.ITEM,id,new BlockItem(mossy,itemSettings));
                var fire=net.fabricmc.fabric.api.registry.FlammableBlockRegistry.getDefaultInstance();
                var flammable=fire.get(base);
                if(flammable!=null) fire.add(mossy,flammable.getIgniteOdds(),flammable.getBurnOdds());
                WOOD.put(base,mossy); ORIGINAL.put(mossy,base);
            }
        } catch (IOException e) { throw new IllegalStateException(e); }
        for (String materialFile : List.of("weathering-masonry.json", "weathering-cracked.json")) {
            try (var in=WeatherBlocks.class.getResourceAsStream("/"+materialFile)) {
                for (var definition:JsonParser.parseReader(new InputStreamReader(Objects.requireNonNull(in))).getAsJsonArray()) {
                    var d=definition.getAsJsonObject(); Block base=vanilla(d.get("base").getAsString());
                    var id=Identifier.fromNamespaceAndPath("mubble_weathering",d.get("name").getAsString());
                    var key=ResourceKey.create(Registries.BLOCK,id);
                    var settings=BlockBehaviour.Properties.ofFullCopy(base).setId(key).overrideLootTable(Optional.of(ResourceKey.create(Registries.LOOT_TABLE,id.withPrefix("blocks/"))));
                    Block aged=materialFile.contains("cracked") ? switch(d.get("shape").getAsString()) {
                        case "stairs" -> new WeatherStairs(base.defaultBlockState(),settings);
                        case "slab" -> new SlabBlock(settings);
                        case "wall" -> new WallBlock(settings);
                        case "fence" -> new FenceBlock(settings);
                        case "pillar" -> new RotatedPillarBlock(settings);
                        default -> new Block(settings);
                    } : mossBlock(d.get("shape").getAsString(),base,settings);
                    Registry.register(BuiltInRegistries.BLOCK,key,aged);
                    Registry.register(BuiltInRegistries.ITEM,id,new BlockItem(aged,new Item.Properties().setId(ResourceKey.create(Registries.ITEM,id)).useBlockDescriptionPrefix()));
                    ORIGINAL.put(aged,base);
                    if(materialFile.contains("cracked")) CRACK.put(base,aged); else MOSS.put(base,aged);
                }
            } catch(IOException e) {throw new IllegalStateException(e);}
        }
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, Identifier.fromNamespaceAndPath("mubble_weathering","weathered_wood"),
            CreativeModeTab.builder(CreativeModeTab.Row.TOP,0).title(net.minecraft.network.chat.Component.literal("Mubble's Weathering"))
                .icon(()->new ItemStack(WOOD.get(Blocks.OAK_PLANKS))).build());
        net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents.modifyOutputEvent(
            ResourceKey.create(Registries.CREATIVE_MODE_TAB, Identifier.fromNamespaceAndPath("mubble_weathering","weathered_wood")))
             .register(output->ORIGINAL.keySet().forEach(block->{
                if(block.defaultBlockState().hasProperty(MOSS_STAGE)) for(int stage=1;stage<=3;stage++) {
                    var stack=new ItemStack(block);stack.set(net.minecraft.core.component.DataComponents.BLOCK_STATE,new net.minecraft.world.item.component.BlockItemStateProperties(Map.of("moss_stage",Integer.toString(stage))));output.accept(stack);
                } else output.accept(new ItemStack(block));
            }));
        crack("stone_bricks","cracked_stone_bricks");
        crack("nether_bricks","cracked_nether_bricks");
        crack("polished_blackstone_bricks","cracked_polished_blackstone_bricks");
        for(String name:List.of("stone","smooth_stone","deepslate")) CRACK.remove(vanilla(name));
        rough("stone","cobblestone"); rough("smooth_stone","stone"); rough("deepslate","cobbled_deepslate");
        for(String name:List.of("cobblestone","cobbled_deepslate","cracked_stone_bricks","cracked_nether_bricks","cracked_polished_blackstone_bricks","cracked_deepslate_bricks","cracked_deepslate_tiles")) CRACK.remove(vanilla(name));
        for(String name:List.of("mossy_stone_bricks","mossy_stone_brick_stairs","mossy_stone_brick_slab","mossy_stone_brick_wall")) { CRACK.remove(vanilla(name)); MOSS.remove(vanilla(name)); }
        for(var entry:List.copyOf(CRACK.entrySet())) { var moss=MOSS.get(entry.getKey()); if(moss!=null) MOSS.put(entry.getValue(),moss); }
    }
    private static void moss(String a,String b) { MOSS.put(vanilla(a),vanilla(b)); }
    private static void crack(String a,String b) { CRACK.put(vanilla(a),vanilla(b)); }
    private static void rough(String a,String b) { ROUGH.put(vanilla(a),vanilla(b)); }
    private static Block vanilla(String name) {
        Block block = BuiltInRegistries.BLOCK.getValue(Identifier.withDefaultNamespace(name));
        if (block == null || block == Blocks.AIR) throw new IllegalArgumentException(name);
        return block;
    }
    public static boolean eligible(BlockState state) {
        if (state.hasBlockEntity() || state.getBlock() instanceof InfestedBlock) return false;
        if(state.hasProperty(MOSS_STAGE)) return state.getValue(MOSS_STAGE)<3;
        Block block=state.getBlock();
        if(ROUGH.containsKey(block) && !Weathering.config().weatherNaturalStone) return false;
        return WOOD.containsKey(block) || MOSS.containsKey(block) || CRACK.containsKey(block)
            || (Weathering.config().weatherNaturalStone && ROUGH.containsKey(block));
    }
    public static boolean canProgress(BlockState state,boolean wet) {
        if(!state.hasProperty(MOSS_STAGE)) return true;
        Block original=ORIGINAL.get(state.getBlock());
        return state.getValue(MOSS_STAGE)<3 && (wet || WOOD.containsKey(original));
    }
    public static BlockState next(BlockState state, boolean wet) {
        if(state.hasProperty(MOSS_STAGE)) return canProgress(state,wet) ? state.setValue(MOSS_STAGE,state.getValue(MOSS_STAGE)+1) : null;
        Block block=state.getBlock(), target=WOOD.get(block);
        if (target == null && wet) target=MOSS.get(block);
        if (target == null) target=CRACK.get(block);
        if (target == null && Weathering.config().weatherNaturalStone) target=ROUGH.get(block);
        if (target == null) return null;
        if (target instanceof InfestedBlock) throw new IllegalStateException("Infested weathering output");
        BlockState result=properties(state,target.defaultBlockState());
        return result.hasProperty(MOSS_STAGE)?result.setValue(MOSS_STAGE,1):result;
    }
    public static BlockState restore(BlockState state) {
        Block target=ORIGINAL.get(state.getBlock());
        return target == null ? null : properties(state,target.defaultBlockState());
    }
    public static BlockState properties(BlockState source, BlockState target) {
        for (var property : source.getProperties()) if (target.hasProperty(property)) target=copy(source,target,property);
        return target;
    }
    private static <T extends Comparable<T>> BlockState copy(BlockState a,BlockState b,Property<T> p) { return b.setValue(p,a.getValue(p)); }
}
