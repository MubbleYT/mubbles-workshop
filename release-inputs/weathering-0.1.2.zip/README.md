# Mubble's Weathering 0.1.2

## New moss growth

Moss develops through **light → medium → full** stages. Small branching tendrils join into irregular patches before covering most of the block. Masks use half-pixel geometry rather than the old two-pixel squares, and two patterns vary the appearance between blocks. Each stage grows the same underlying pattern. Mubble's supplied 16×16 moss PNG is used unchanged across all custom mossy wood and masonry.

Each step gets a fresh 4–12 Minecraft-day exposure timer. Wood continues slowly in dry conditions; masonry moss stages advance only while damp. Adjacent medium/full moss makes neighboring blocks damp, allowing the spread to extend outward. Only loaded, exposed, unprotected blocks participate. Full moss is the final stage.

Mining preserves `moss_stage` on the dropped item. Light, medium and full versions are available in the creative tab and show their respective item models. A honeycomb coat works at every stage, and an axe restores the original material. Existing custom moss block IDs are preserved; pre-update moss blocks without a stage load as full moss.

Example placement commands (cheats enabled):

```mcfunction
/setblock ~ ~ ~ mubble_weathering:mossy_oak_planks[moss_stage=1]
/setblock ~ ~ ~ mubble_weathering:aged_mossy_stone_bricks[moss_stage=2]
```

The inspect command now shows the stage. Ordinary pre-existing vanilla mossy bricks/cobblestone remain vanilla blocks.


Minecraft 26.3 / Fabric / Java 25. Replace the old JAR; Fabric API is required on the server and every client.

This update adds 201 masonry materials with 402 custom mossy and cracked variants, alongside the existing 81 mossy wood blocks. Shapes, orientation, waterlogging, collision, and double-slab drops are retained. Never creates infested blocks.

Covered masonry includes stone and stone bricks, cobblestone, granite/diorite/andesite and their polished forms, sandstone/red sandstone, bricks, deepslate, blackstone, Nether bricks, End stone, quartz, purpur, prismarine, tuff, mud/resin bricks, all concrete and terracotta colors, clay, calcite, basalt and dripstone. Available stairs, slabs, walls, pillars and Nether brick fences are included. Copper already oxidizes in vanilla. Glass, wool, concrete powder, glazed terracotta and functional blocks are left intact.

Damp masonry grows staged moss; dry masonry develops cracks or uses its existing vanilla cracked/rough counterpart. Already cracked or rough blocks can later grow moss when damp. Fully mossy variants are final; custom cracked variants can acquire light moss when damp. Stone, smooth stone and deepslate retain vanilla roughening in dry conditions.

Placed blocks take priority when the tracking budget fills up. Terrain discovery uses up to 75% of the budget, reserving the remainder for builds. At the hard cap, an unprotected discovered block is evicted first, then an unprotected tracked block if necessary. Protected blocks are never evicted. Eviction discards that block's timer, so very large worlds should increase `maxTrackedBlocksPerDimension`.

Check a specific block with `/mubbleweathering inspect x y z`. It reports eligibility, exposure, dampness, protection, accumulated exposure and the stage deadline. `/mubbleweathering age x y z` advances one available stage immediately.

Default timing remains 4–12 Minecraft days per stage: 96,000–288,000 exposure ticks. Dampness multiplies progress by 2.5. `/tick rate 10000` accelerates game time if the server can keep up; random tick speed does not control this mod. Only loaded, exposed blocks age. Config day-range changes affect new timers; existing deadlines remain.

Honeycomb protects blocks. Sneak with an axe to remove protection; use an axe normally to restore custom weathered blocks. Custom masonry, like custom wood, requires this mod to remain installed; restore those blocks before removing the mod.

## Install

Minecraft Java **26.3**, Java **25+**, Fabric Loader **0.19.5+**, and Fabric API **0.161.0+26.3** (or a compatible newer 26.3 build).

Place `mubbles-weathering-0.1.2.jar` in `mods`. For singleplayer, install in the client instance. For multiplayer, **the server and every client need the mod**, because it adds real weathered blocks. No additional resource pack is required. This differs from Mubble's Flame Flicker and Mubble's Rivercarve, whose multiplayer clients do not need their mods.

## Aging paths

| Material | Weathering |
|---|---|
| Overworld wood and bamboo | Mossy wood |
| Stone bricks / Nether bricks / polished blackstone bricks | Vanilla cracks when dry; custom staged moss when damp |
| Stone, smooth stone and deepslate | Vanilla roughening when dry; moss when damp |
| Other supported masonry, including available stairs/slabs/walls/pillars | Custom cracked weathered form when dry; mossy form when damp |

There are **81 mossy wood blocks**: oak, spruce, birch, jungle, acacia, dark oak, mangrove, cherry and pale oak planks/logs/wood/stripped logs/stripped wood/stairs/slabs/fences; bamboo planks, mosaic, their stairs/slabs, fences, blocks and stripped blocks. Their wood grain stays visible under moss patches using Mubble's edited texture. Log axes, stair orientation/shape, slab type, waterlogging, fence connections, collision shapes, wood mining tags, furnace fuel, and wood fire behavior are retained. A mossy double slab drops two slabs. Mossy variants have a dedicated creative tab.

Doors, trapdoors, gates, signs, furniture, containers, and other block entities are excluded. Crimson and warped fungal wood are excluded. No random block destruction, air replacement, structural collapse, or infested conversion is performed. Blocks with no defined later stage remain in their final form.

## Time and exposure

By default a stage takes **4–12 Minecraft days of loaded, exposed game time** (80 minutes–4 hours at 20 TPS). Different blocks change at different times. Rain reaching the block, adjacent water/waterlogging, or neighboring moss counts as damp and accelerates aging by **2.5×**. Wood can grow moss slowly in dry conditions too; this is a visual building-aging mechanic rather than a biological simulation.

A surface is exposed when at least one neighboring block is air or contains water. Fully enclosed blocks pause. Unloaded chunks, a stopped server, frozen game time, and disabled weathering add no aging time. Existing supported blocks are discovered on chunk load; their age begins when discovered, since Minecraft does not record their original placement dates.

The scheduler scans at most one section per tick and checks at most 256 tracked blocks each 20 ticks by default. It never force-loads terrain. Enclosed natural stone is not added during discovery. The default cap is 50,000 tracked blocks per dimension; terrain discovery pauses at 75% capacity and placed blocks can evict an unprotected timer at the hard cap. Heavy workloads can delay a transition beyond its exposure threshold. No large-build performance benchmark is claimed.

Exposure and protection are saved in `<world>/mubble-weathering/<dimension-namespace>/<dimension-path>.json` every five minutes of game time and on a normal server stop. These files are independent of the world clock, so restarting does not apply offline aging. Block changes remain ordinary world block data. Abrupt crashes can lose aging/protection changes since the last save.

## Protecting and cleaning builds

- Right-click supported wood or masonry with **honeycomb** to protect that block from further aging. Survival consumes one honeycomb.
- **Sneak-right-click with an axe** to remove protection.
- Right-click custom weathered **wood or masonry** with an axe to scrape it back to its original wood block. Orientation and waterlogging are preserved. Survival axe actions use one durability.

Protection is tied to that placed block. Breaking or replacing it clears the protection and timer. Changing an orientation or waterlogged state preserves them. Disabling the mod pauses future changes and keeps already weathered blocks.

## Commands and configuration

`/mubbleweathering status` shows the enabled state, tracked count and changes. Operator commands:

| Command | Action |
|---|---|
| `/mubbleweathering on` | Resume aging and save the enabled setting |
| `/mubbleweathering off` | Pause aging and save the disabled setting |
| `/mubbleweathering reload` | Reload settings |
| `/mubbleweathering age x y z` | Apply one available stage immediately for a demonstration; protection still applies |

Settings are in `config/mubble-weathering.json`:

```json
{
  "enabled": true,
  "minDays": 4.0,
  "maxDays": 12.0,
  "wetSpeedMultiplier": 2.5,
  "checkIntervalTicks": 20,
  "checksPerInterval": 256,
  "scanSectionsPerTick": 1,
  "maxTrackedBlocksPerDimension": 50000,
  "weatherNaturalStone": true
}
```

`weatherNaturalStone: false` excludes smooth stone, stone and deepslate roughening while retaining wood and masonry weathering. Changed day ranges apply to newly tracked blocks and new stages; existing assigned deadlines are retained. Timing values are checked and clamped when loaded.

Custom mossy wood and custom masonry need this mod to remain registered. Restore custom weathered blocks with an axe before uninstalling if you want to retain those blocks in a world without the mod. Ordinary vanilla mossy/cracked masonry remains usable without it.

## Build and validation

Use a Java 25 JDK:

```sh
./gradlew build
# Direct build alternative, downloads official dependencies into a local cache:
python build-direct.py --java-home /path/to/jdk25
```

The generated JSON models/loot tables/tags are included. To regenerate them from your Minecraft 26.3 client JAR:

```sh
python generate-assets.py --client-jar /path/to/26.3-client.jar
python generate-masonry-assets.py --client-jar /path/to/26.3-client.jar
python generate-cracked-assets.py --client-jar /path/to/26.3-client.jar
python generate-moss-stages.py --client-jar /path/to/26.3-client.jar
```

Minecraft binaries are not redistributed. Base models reference the installed game's block textures; the moss texture is the user-provided edited PNG at `src/main/resources/assets/mubble_weathering/textures/block/moss.png`. Test observers under `src/integration/java` and `src/clientIntegration/java` are excluded from the playable JAR. See `VALIDATION.md` for actual test scope and results.
