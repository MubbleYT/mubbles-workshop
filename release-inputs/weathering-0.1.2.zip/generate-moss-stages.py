#!/usr/bin/env python3
"""Build nested organic moss geometry; preserves the artist's PNG unchanged.
Run after the wood/masonry generators: --client-jar /path/to/client.jar.
Existing moss block IDs stay registered. moss_stage=1/2/3 selects light/medium/full.
"""
import argparse,copy,hashlib,json,math,pathlib,random,zipfile
p=argparse.ArgumentParser();p.add_argument('--client-jar',required=True);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent/'src/main/resources'
def write(path,data):
    f=root/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(data,separators=(',',':'))+'\n')
def ranks(seed):
    r=random.Random(seed);paths=[]
    # Irregular vertical filaments rooted in the lower seam, with lateral branches.
    for _ in range(3):
        x=r.uniform(0,31);y=31.;path=[]
        for step in range(r.randrange(12,29)):
            path.append((x,y));x=max(0,min(31,x+r.uniform(-2.2,2.2)));y-=r.uniform(.6,1.4)
        paths+=path
        if path:
            x,y=r.choice(path)
            for step in range(r.randrange(6,14)):
                paths.append((x,y));x=max(0,min(31,x+r.uniform(-1.8,1.8)));y=max(0,y-r.uniform(-.8,1.3))
    scored=[]
    for y in range(32):
        for x in range(32):
            distance=min(math.hypot(x-px,y-py) for px,py in paths)
            # Smooth lobes and fine ragged edges, rather than rectangular islands.
            noise=.9*math.sin(x*.49+y*.25+seed%37)+.6*math.cos(y*.71-x*.22)+r.uniform(-.65,.65)
            scored.append((distance+noise,x,y))
    scored.sort();return {(x,y):i for i,(_,x,y) in enumerate(scored)}
with zipfile.ZipFile(a.client_jar) as vanilla:
    def read(path):return json.loads(vanilla.read(path))
    def resolve(name):
        namespace,path=(name.split(':',1) if ':' in name else ('minecraft',name))
        d=read('assets/'+namespace+'/models/'+path+'.json')
        return d['elements'] if 'elements' in d else resolve(d['parent'])
    total=0
    for file,prefix in [('weathering-materials.json','mossy_'),('weathering-masonry.json','aged_mossy_')]:
        for d in json.loads((root/file).read_text()):
            base=d['base'];name=prefix+base;original=read('assets/minecraft/blockstates/'+base+'.json');models=set()
            def replace(value,stage):
                if isinstance(value,dict):
                    if 'model' in value:
                        m=value['model'];models.add(m);new=[]
                        for variation in range(2):
                            v=copy.deepcopy(value);v['model']='mubble_weathering:block/'+prefix+m.split('/')[-1]+f'_stage{stage}_{variation}';v['weight']=1;new.append(v)
                        return new
                    return {k:replace(v,stage) for k,v in value.items()}
                if isinstance(value,list):
                    out=[]
                    for v in value:
                        q=replace(v,stage);out.extend(q if isinstance(q,list) else [q])
                    return out
                return value
            if 'variants' in original:
                states={'variants':{}}
                for key,value in original['variants'].items():
                    for stage in range(1,4):states['variants'][','.join(filter(None,[key,f'moss_stage={stage}']))]=replace(copy.deepcopy(value),stage)
            else:
                states={'multipart':[]}
                for part in original['multipart']:
                    for stage in range(1,4):
                        q=copy.deepcopy(part);condition={'moss_stage':str(stage)}
                        q['when']={'AND':[q['when'],condition]} if 'when' in q else condition;q['apply']=replace(q['apply'],stage);states['multipart'].append(q)
            write(pathlib.Path('assets/mubble_weathering/blockstates')/(name+'.json'),states)
            item=read('assets/minecraft/items/'+base+'.json')['model']['model'];models.add(item)
            itemname='mubble_weathering:block/'+prefix+item.split('/')[-1]
            write(pathlib.Path('assets/mubble_weathering/items')/(name+'.json'),{'model':{'type':'minecraft:select','property':'minecraft:block_state','block_state_property':'moss_stage','cases':[{'when':str(i),'model':{'type':'minecraft:model','model':itemname+f'_stage{i}_0'}} for i in range(1,4)],'fallback':{'type':'minecraft:model','model':itemname+'_stage3_0'}}})
            lootpath=pathlib.Path('data/mubble_weathering/loot_table/blocks')/(name+'.json')
            loot=json.loads((root/lootpath).read_text());entry=loot['pools'][0]['entries'][0]
            modifiers=[x for x in entry.get('modifier',[]) if x.get('type')!='minecraft:copy_state']
            entry['modifier']=modifiers+[{'type':'minecraft:copy_state','block':'mubble_weathering:'+name,'properties':['moss_stage']}]
            write(lootpath,loot)
            for model in models:
                seed=int.from_bytes(hashlib.sha256(model.encode()).digest()[:4],'big')
                elements=resolve(model)
                for variation in range(2):
                    fields={face:ranks(seed+variation*7907+i*2017) for i,face in enumerate(['west','east','down','up','north','south'])}
                    for stage,coverage in [(1,.15),(2,.45),(3,.95)]:
                        overlays=[]
                        for e in elements:
                            start,end=e['from'],e['to']
                            for face,definition in e['faces'].items():
                                n={'west':0,'east':0,'down':1,'up':1,'north':2,'south':2}[face];t=[i for i in range(3) if i!=n];uaxis,vaxis=t;sign=1 if face in ['east','up','south'] else -1
                                plane=(end[n] if sign>0 else start[n])+sign*.008
                                u0=max(0,round(start[uaxis]*2));u1=min(32,round(end[uaxis]*2));v0=max(0,round(start[vaxis]*2));v1=min(32,round(end[vaxis]*2));field=fields[face]
                                mask={(u,v) for v in range(v0,v1) for u in range(u0,u1) if field[u,v]<int(1024*coverage)}
                                while mask:
                                    u,v=min(mask,key=lambda xy:(xy[1],xy[0]));right=u+1
                                    while right<u1 and (right,v) in mask:right+=1
                                    bottom=v+1
                                    while bottom<v1 and all((x,bottom) in mask for x in range(u,right)):bottom+=1
                                    mask.difference_update((x,y) for y in range(v,bottom) for x in range(u,right))
                                    frm=list(start);to=list(end);frm[n]=to[n]=plane;frm[uaxis]=u/2;to[uaxis]=right/2;frm[vaxis]=v/2;to[vaxis]=bottom/2
                                    quad={'texture':'#weathering_moss','uv':[u/2,v/2,right/2,bottom/2]}
                                    if 'cullface' in definition:quad['cullface']=definition['cullface']
                                    overlays.append({'from':frm,'to':to,'faces':{face:quad}})
                        write(pathlib.Path('assets/mubble_weathering/models/block')/(prefix+model.split('/')[-1]+f'_stage{stage}_{variation}.json'),{'parent':model,'textures':{'weathering_moss':'mubble_weathering:block/moss'},'elements':copy.deepcopy(elements)+overlays});total+=1
    for obsolete in (root/'assets/mubble_weathering/models/block').glob('*.json'):
        if obsolete.stem.startswith(('mossy_','aged_mossy_')) and '_stage' not in obsolete.stem: obsolete.unlink()
    print('Generated',total,'nested moss stage models')
