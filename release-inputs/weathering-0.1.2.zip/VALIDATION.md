# Validation — 0.1.2

Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.161.0+26.3, Java 25.

- 2,871 dedicated-server checks passed: existing wood/masonry states and collision/drops, all 282 moss block types light→medium→full, final-stage stop, per-stage restoration, dry masonry pause, stage-preserving drops, actual automatic completion of all three wood and damp stone stages, neighbor dampness, protection, scheduler pause/unload, and placement priority at a full cap.
- Four real restart checks passed for protection, custom block persistence and no offline exposure.
- 489 graphical client checks passed on Mesa llvmpipe OpenGL 4.6: every state of all 483 custom blocks has a baked model, honeycomb/axe interactions work, and clean/light/medium/full walls and shaped blocks render. Gallery inspected visually. No new Sodium/Iris compatibility or hardware/FPS benchmark is claimed.
- Supplied moss PNG copied byte-for-byte. Regeneration and packaged asset paths checked.

Logs and gallery are in validation/. Earlier 0.1.1 logs remain as historical evidence. Only the current checks apply to this release.
