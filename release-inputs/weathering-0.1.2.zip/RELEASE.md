# 0.1.2

Uses Mubble's edited moss PNG unchanged. Adds light, medium and full moss stages across all 282 custom mossy wood/masonry types, with fine branching half-pixel geometry and two growth patterns. Mining retains stage; creative and item models expose every stage. Medium/full moss spreads dampness to neighbors. Existing moss IDs remain; older moss blocks load fully mossy. Retains all 201 masonry materials and never creates infested blocks.

Validated with 2,871 dedicated-server checks, four real restart checks, and 489 graphical client checks. New gallery inspected in-game on OpenGL llvmpipe. Default timing is 4–12 Minecraft days per growth step, dampness 2.5×. Minecraft 26.3, Fabric Loader 0.19.5+, Fabric API 0.161.0+26.3, Java 25; server and all clients need the mod.
