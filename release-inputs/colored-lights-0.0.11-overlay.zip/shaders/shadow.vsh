#version 430 compatibility

#define LIGHT_COLOR_MODE 14 // [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14]
#define CUSTOM_LIGHT_R 1.0 // [0.0 0.25 0.50 0.75 1.0]
#define CUSTOM_LIGHT_G 0.50 // [0.0 0.25 0.50 0.75 1.0]
#define CUSTOM_LIGHT_B 0.25 // [0.0 0.25 0.50 0.75 1.0]

#define SUN_SHADOWS 1 // [0 1]
#define SHADOW_QUALITY 1 // [0 1 2] 512 / 1024 / 2048
#if SUN_SHADOWS == 0
const int shadowMapResolution = 64;
#elif SHADOW_QUALITY == 0
const int shadowMapResolution = 512;
#elif SHADOW_QUALITY == 1
const int shadowMapResolution = 1024;
#else
const int shadowMapResolution = 2048;
#endif
#define WIND_STRENGTH 0.80 // [0.0 0.30 0.50 0.65 0.80 1.0 1.25 1.5 0.60]
uniform float frameTimeCounter;
uniform float rainStrength;
out vec2 shadowUV;
flat out int shadowWater;
#define LIGHT_VIEW_DISTANCE 96 // [24 48 64 96 128]
const float shadowDistance = LIGHT_VIEW_DISTANCE;
const float shadowDistanceRenderMul = 1.0;

in vec2 mc_Entity;
in vec4 at_midBlock;
uniform mat4 shadowModelViewInverse;
uniform vec3 cameraPosition;

layout(std430, binding = 0) buffer NearbyLights {
    uint count;
    uint seen[8192];
    vec4 positions[256];
    vec4 colors[256];
    float screenWet;
    float pad0;
    vec4 lingeringSmoke[16];
    vec4 smokeBirth[16];
} lights;

layout(std430, binding = 1) buffer SceneVoxels {
    uint occupiedCount;
    uint bits[65536];
} voxels;

vec3 sourceColor(int kind, vec3 position) {
#if LIGHT_COLOR_MODE == 0
    return vec3(0.40, 1.00, 0.42);
#elif LIGHT_COLOR_MODE == 1
    return vec3(0.74, 0.42, 1.00);
#elif LIGHT_COLOR_MODE == 2
    return vec3(1.00, 0.88, 0.35);
#elif LIGHT_COLOR_MODE == 4
    return vec3(0.45, 0.72, 1.00);
#elif LIGHT_COLOR_MODE == 5
    return vec3(0.19, 0.35, 0.72);
#elif LIGHT_COLOR_MODE == 6
    return vec3(0.32);
#elif LIGHT_COLOR_MODE == 7
    return vec3(1.65);
#elif LIGHT_COLOR_MODE == 8
    return vec3(0.62, 0.35, 0.17);
#elif LIGHT_COLOR_MODE == 9
    return vec3(1.00, 0.24, 0.20);
#elif LIGHT_COLOR_MODE == 10
    return vec3(1.00, 0.58, 0.75);
#elif LIGHT_COLOR_MODE == 11
    return vec3(1.00, 0.15, 0.58);
#elif LIGHT_COLOR_MODE == 12
    float h = fract(sin(dot(floor(position), vec3(12.9898, 78.233, 37.719))) * 43758.5453);
    return 0.45 + 0.55 * vec3(0.5 + 0.5 * sin(h * 6.283 + 0.0),
                               0.5 + 0.5 * sin(h * 6.283 + 2.1),
                               0.5 + 0.5 * sin(h * 6.283 + 4.2));
#elif LIGHT_COLOR_MODE == 13
    return vec3(CUSTOM_LIGHT_R, CUSTOM_LIGHT_G, CUSTOM_LIGHT_B);
#else
    if (kind == 1) return vec3(1.00, 0.12, 0.18);
    if (kind == 2) return vec3(0.15, 0.27, 1.00);
    if (kind == 3) return vec3(0.26, 0.76, 1.00);
    if (kind == 4) return vec3(1.00, 0.78, 0.33);
    if (kind == 5) return vec3(1.00, 0.46, 0.18);  // torch base (flicker applied in composite)
    if (kind == 6) return vec3(1.00, 0.49, 0.80);
    if (kind == 7) return vec3(0.37, 1.00, 0.42);
    if (kind == 8)  return vec3(1.00, 0.55, 0.28);
    if (kind == 9)  return vec3(0.82, 0.48, 0.32);
    if (kind == 10) return vec3(0.48, 0.68, 0.36);
    if (kind == 11) return vec3(0.22, 0.72, 0.58);
    if (kind == 20) return vec3(1.00, 0.42, 0.12); // open fire, never smoke
    if (kind == 12) return vec3(1.00, 0.42, 0.12);  // campfire/fire base
    if (kind == 13) return vec3(1.00, 0.85, 0.55);
    if (kind == 14) return vec3(0.0); // chain emits no light
    if (kind == 15) return vec3(1.00, 0.46, 0.18); // hanging lantern = torch color
    if (kind == 16) return vec3(0.15, 0.27, 1.00); // soul lantern
    if (kind == 17) return vec3(0.15, 0.27, 1.00); // soul campfire
    if (kind == 18) return vec3(1.00, 0.42, 0.12); // signal campfire
    if (kind == 19) return vec3(0.15, 0.27, 1.00); // soul signal campfire
    return vec3(0.37, 1.00, 0.42);
#endif
}

void main() {
    shadowUV=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
    shadowWater=abs(mc_Entity.x-10001.0)<0.5?1:0;
    vec4 vertex=gl_Vertex;
    bool leaves=abs(mc_Entity.x-10002.0)<0.5;
    bool grass=abs(mc_Entity.x-10003.0)<0.5;
    if (WIND_STRENGTH>0.0 && (leaves || grass)) {
        vec3 world=(shadowModelViewInverse*(gl_ModelViewMatrix*vertex)).xyz+cameraPosition;
        float tip=clamp(0.5-at_midBlock.y/64.0,0.0,1.0);
        float phase=dot(world.xz,vec2(0.27,0.19))+frameTimeCounter*(1.0+rainStrength*0.9);
        float gust=0.72+0.28*sin(frameTimeCounter*0.31+world.x*0.027);
        float amount=WIND_STRENGTH*gust*(1.0+rainStrength*0.65);
        amount*=grass?0.14*tip:0.06*(0.5+0.5*tip);
        vertex.xz+=amount*vec2(sin(phase),cos(phase*0.81+0.5));
    }
    gl_Position = gl_ModelViewProjectionMatrix*vertex;
    vec4 centerView = gl_ModelViewMatrix * vec4(gl_Vertex.xyz + at_midBlock.xyz / 64.0, 1.0);
    vec3 relative = (shadowModelViewInverse * centerView).xyz;
    vec3 world = relative + cameraPosition;
    // Record opaque terrain in a world-aligned block grid. Plants, water,
    // flames and lamps do not act as full-cube light occluders.
    int blockId = int(mc_Entity.x + 0.5);
    bool partial = (blockId >= 10001 && blockId <= 10003) ||
                   (blockId >= 11001 && blockId <= 11024);
    ivec3 grid = ivec3(floor(world)) - ivec3(floor(cameraPosition)) + ivec3(64);
    if (!partial && all(greaterThanEqual(grid, ivec3(0))) &&
        all(lessThan(grid, ivec3(128)))) {
        uint bit = uint(grid.x) | (uint(grid.y) << 7u) | (uint(grid.z) << 14u);
        uint mask = 1u << (bit & 31u);
        if ((atomicOr(voxels.bits[bit >> 5u], mask) & mask) == 0u)
            atomicAdd(voxels.occupiedCount, 1u);
    }
    int kind = blockId - 11000;
    if (kind == 21) kind = 11; // copper lantern: matching green light
    if (kind == 22) kind = 15; // standing lantern
    if (kind == 23) kind = 16; // standing soul lantern
    if (kind == 24) kind = 11; // standing copper lantern
    if (kind < 1 || kind > 20 || kind == 14) return;
    if (dot(relative, relative) > float(LIGHT_VIEW_DISTANCE * LIGHT_VIEW_DISTANCE)) return;
    ivec3 cell = ivec3(floor(world));
    uint hash = uint(cell.x) * 73856093u ^ uint(cell.y) * 19349663u ^ uint(cell.z) * 83492791u;
    uint slot = hash & 8191u;
    if (atomicCompSwap(lights.seen[slot], 0u, 1u) == 0u) {
        uint index = atomicAdd(lights.count, 1u);
        if (index < 256u) {
            lights.positions[index] = vec4(floor(world) + 0.5, float(kind));
            lights.colors[index] = vec4(sourceColor(kind, world), float(kind));
        }
    }
}
