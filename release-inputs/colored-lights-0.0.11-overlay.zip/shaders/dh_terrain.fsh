#version 330 compatibility
/* DRAWBUFFERS:01234 */
#include "/lib/strict_lighting.glsl"
in vec4 terrainColor;
in vec2 lightUV;
void main() {
    vec2 levels = clamp((lightUV-vec2(1.0/32.0))*(32.0/30.0),0.0,1.0);
    gl_FragData[1]=vec4(0.0);
    gl_FragData[2]=vec4(0.0);
    gl_FragData[3]=vec4(levels,0.0,1.0);
    gl_FragData[4]=vec4(terrainColor.rgb,1.0);
    vec3 color = terrainColor.rgb * mubbleSurfaceLight(lightUV);
    
    gl_FragData[0] = vec4(color, terrainColor.a);
}
