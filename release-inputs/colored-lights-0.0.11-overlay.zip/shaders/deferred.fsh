#version 430 compatibility
/* DRAWBUFFERS:0 */
// Relight opaque surfaces before water/glass are blended over them.
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
uniform mat4 dhProjectionInverse;
#endif
in vec2 texcoord;
#include "/lib/daylight.glsl"

vec3 surfacePosition(vec2 uv, float depth, mat4 inverseProjection) {
    vec4 view = inverseProjection * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return (gbufferModelViewInverse * vec4(view.xyz / view.w, 1.0)).xyz;
}

void main() {
    vec4 previous = texture(colortex0, texcoord);
    float depth = texture(depthtex0, texcoord).r;
    vec3 relative = surfacePosition(texcoord, depth, gbufferProjectionInverse);
    bool surface = depth < 0.99999;
#ifdef DISTANT_HORIZONS
    if (!surface) {
        float distantDepth = texture(dhDepthTex0, texcoord).r;
        surface = distantDepth < 0.99999;
        if (surface) relative = surfacePosition(texcoord, distantDepth, dhProjectionInverse);
    }
#endif
    // Derivatives must be evaluated before any per-pixel branch.
    vec3 geometric = cross(dFdx(relative), dFdy(relative));
    vec3 normal = mubbleSafeDirection(geometric);
    if (dot(normal, -relative) < 0.0) normal = -normal;
    vec4 material = texture(colortex4, texcoord);
    vec4 levels = texture(colortex3, texcoord);
    if (!surface || !hasSkylight || hasCeiling || material.a < 0.99 || levels.a < 0.99) {
        gl_FragData[0] = previous;
        return;
    }
    vec3 irradiance = mubbleDaylight(relative, normal, levels.g, levels.b > 0.5)
                    + mubbleBlockIrradiance(levels.r);
    vec3 albedo = pow(max(material.rgb, vec3(0.0)), vec3(2.2));
    vec3 emission = texture(colortex1, texcoord).rgb;
    gl_FragData[0] = vec4(mubbleDisplayRadiance(albedo * irradiance + emission * 0.65), previous.a);
}
