#version 430 compatibility

uniform float currentPlayerHealth;
layout(std430, binding = 0) buffer NearbyLightsFX {
    uint count;
    uint seen[8192];
    vec4 positions[256];
    vec4 colors[256];
    float screenWet;
    float pad0;
    vec4 lingeringSmoke[16];
    vec4 smokeBirth[16];
} fxLights;


// Values in brackets become controls in Iris Shader Pack Settings.
#define CLOUD_STEPS 12 // [0 4 6 12 16 20 24] 0=off, 6=fast, 12=default, 24=cinema
#define CLOUD_STYLE 0 // [0 1 2 3] Volumetric, Minecraft Earth, Layered Vanilla, Dungeons 2
#define CLOUD_COVERAGE 0.52 // [0.30 0.42 0.52 0.62 0.72 0.48 0.58]
#define OVERWORLD_LOOK 0 // [0 1] Standard / Sunlit Realism
#define GODRAY_SAMPLES 8 // [0 4 8 12]
#define STORM_FOG 1 // [0 1 2] 0=off, 1=natural, 2=heavy
#define LIGHT_COLOR_MODE 14 // [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14]
#define CUSTOM_LIGHT_R 1.0 // [0.0 0.25 0.50 0.75 1.0]
#define CUSTOM_LIGHT_G 0.50 // [0.0 0.25 0.50 0.75 1.0]
#define CUSTOM_LIGHT_B 0.25 // [0.0 0.25 0.50 0.75 1.0]
#define VHS_MODE 0 // [0 1 2] 0=off, 1=4:3, 2=16:9
#define CAMERA_EXPOSURE 0.0 // [-2.0 -1.0 -0.5 0.0 0.5 1.0 2.0]
#define CAMERA_GAMMA 1.0 // [0.75 0.85 1.0 1.15 1.3]
#define CAMERA_SHARPNESS 0.0 // [0.0 0.25 0.5 0.75 1.0]
#define CAMERA_ZOOM 1.0 // [1.0 1.25 1.5 2.0 3.0]
#define CAMERA_FOCUS 0.0 // [0.0 2.0 4.0 8.0 16.0 32.0]
#define CAMERA_FILM 0 // [0 1 2] off, 35mm, Super 8
#define CAMERA_GRAIN 0.0 // [0.0 0.015 0.03 0.06 0.10]
#define CAMERA_LENS 0.0 // [0.0 0.04 0.08 0.12]
#define CAMERA_CHROMATIC 0.0 // [0.0 0.5 1.0 2.0 3.0] pixel offset at frame edge
#define CAMERA_BARS 0 // [0 1 2] off, 1.85:1, 2.39:1
#define BLOOD_EFFECT 1 // [0 1 2] Off / Subtle / Strong
#define NETHER_HEAT 1 // [0 1 2] 0=off, 1=hot, 2=blazing
#define BLOOM 1 // [0 1 2] 0=off, 1=soft, 2=strong
#define BLOOM_STRENGTH 0.24 // [0.0 0.12 0.24 0.36 0.42 0.48]
#define COLOR_STRENGTH 0.60 // [0.0 0.25 0.60 0.85 1.0]
#define CONTRAST 1.06 // [0.95 1.0 1.06 1.12 1.20]
#define SATURATION 1.08 // [0.85 1.0 1.08 1.16 1.25]
#define VIGNETTE 0.10 // [0.0 0.05 0.10 0.16 0.22]

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
uniform float dhNearPlane;
uniform float dhFarPlane;
#endif
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferProjection;
uniform float near;
uniform float far;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 skyColor;
uniform float frameTimeCounter;
uniform float frameTime;
uniform float rainStrength;
uniform float wetness;
uniform float thunderStrength;
uniform float temperature;
uniform float rainfall;
uniform int biome_precipitation;
uniform bool hasSkylight;
uniform bool hasCeiling;
uniform vec3 fogColor;
uniform int isEyeInWater;
uniform float viewWidth;
uniform float viewHeight;

in vec2 texcoord;

float weatherStrength() {
    return clamp(max(rainStrength, max(thunderStrength, wetness * 0.45)), 0.0, 1.0);
}

vec3 viewRay(vec2 uv) {
    vec4 view = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, 1.0, 1.0);
    return normalize(view.xyz / view.w);
}

float linearDepth(float d) {
    return (2.0 * near * far) / (far + near - (d * 2.0 - 1.0) * (far - near));
}

float sceneDepth(vec2 uv) {
    float vanilla = texture(depthtex0, uv).r;
#ifdef DISTANT_HORIZONS
    if (vanilla > 0.99999) return texture(dhDepthTex0, uv).r;
#endif
    return vanilla;
}

float sceneDistance(vec2 uv) {
    float vanilla = texture(depthtex0, uv).r;
    if (vanilla < 0.99999) return linearDepth(vanilla);
#ifdef DISTANT_HORIZONS
    float distant = texture(dhDepthTex0, uv).r;
    if (distant < 0.99999)
        return (2.0 * dhNearPlane * dhFarPlane) /
               (dhFarPlane + dhNearPlane - (distant * 2.0 - 1.0) * (dhFarPlane - dhNearPlane));
#endif
    return 220.0;
}

float hash2(vec2 p) {
    p = fract(p * vec2(0.1031, 0.1030));
    p += dot(p, p.yx + 33.33);
    return fract((p.x + p.y) * p.x);
}

float steamNoise(vec2 p) {
    vec2 cell = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float low = mix(hash2(cell), hash2(cell + vec2(1.0, 0.0)), f.x);
    float high = mix(hash2(cell + vec2(0.0, 1.0)), hash2(cell + vec2(1.0)), f.x);
    return mix(low, high, f.y);
}

vec3 sunDisc(vec2 uv, float weather) {
    vec3 sunWorld = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    if (sunWorld.y <= 0.0) return vec3(0.0);
    float alignment = dot(viewRay(uv), normalize(sunPosition));
    float radius = 0.0090;
    float edge = max(fwidth(alignment) * 1.3, 0.000012);
    float disc = smoothstep(cos(radius) - edge, cos(radius) + edge, alignment);
    float halo = pow(max(alignment, 0.0), 620.0) * 0.30;
    vec3 sunlight = mix(vec3(1.0, 0.55, 0.30), vec3(1.0, 0.95, 0.82), smoothstep(0.02, 0.36, sunWorld.y));
    return sunlight * (disc * 0.92 + halo) * (1.0 - weather * 0.94);
}

#if GODRAY_SAMPLES > 0
vec3 sunShafts(vec2 uv, float weather) {
    vec4 projected = gbufferProjection * vec4(sunPosition, 1.0);
    if (projected.w <= 0.0) return vec3(0.0);
    vec2 sunUV = projected.xy / projected.w * 0.5 + 0.5;
    if (any(lessThan(sunUV, vec2(-0.15))) || any(greaterThan(sunUV, vec2(1.15)))) return vec3(0.0);
    float skyOpen = 0.0;
    for (int i = 0; i < GODRAY_SAMPLES; ++i) {
        vec2 sampleUV = mix(uv, sunUV, (float(i) + 0.5) / float(GODRAY_SAMPLES));
        if (all(greaterThanEqual(sampleUV, vec2(0.0))) && all(lessThanEqual(sampleUV, vec2(1.0))))
            skyOpen += step(0.99999, sceneDepth(sampleUV));
    }
    float visible = skyOpen / float(GODRAY_SAMPLES);
    float distanceFade = exp(-length((uv - sunUV) * vec2(viewWidth / viewHeight, 1.0)) * 3.7);
    vec3 sunWorld = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    float daylight = smoothstep(0.01, 0.19, sunWorld.y);
    return vec3(1.0, 0.83, 0.60) * visible * distanceFade * daylight * (1.0 - weather) * 0.20;
}
#endif


#include "/lib/clouds.glsl"



vec3 paletteColor(vec2 uv) {
#if LIGHT_COLOR_MODE == 0
    return vec3(0.40, 1.00, 0.42); // green
#elif LIGHT_COLOR_MODE == 1
    return vec3(0.74, 0.42, 1.00); // purple
#elif LIGHT_COLOR_MODE == 2
    return vec3(1.00, 0.88, 0.35); // yellow
#elif LIGHT_COLOR_MODE == 14
    return vec3(1.00); // white / neutral
#elif LIGHT_COLOR_MODE == 4
    return vec3(0.45, 0.72, 1.00); // blue
#elif LIGHT_COLOR_MODE == 5
    return vec3(0.19, 0.35, 0.72); // dark blue
#elif LIGHT_COLOR_MODE == 6
    return vec3(0.32); // dim
#elif LIGHT_COLOR_MODE == 7
    return vec3(1.65); // blinding
#elif LIGHT_COLOR_MODE == 8
    return vec3(0.62, 0.35, 0.17); // brown
#elif LIGHT_COLOR_MODE == 9
    return vec3(1.00, 0.24, 0.20); // red
#elif LIGHT_COLOR_MODE == 10
    return vec3(1.00, 0.58, 0.75); // pink
#elif LIGHT_COLOR_MODE == 11
    return vec3(1.00, 0.15, 0.58); // hot pink
#elif LIGHT_COLOR_MODE == 12
    float d = texture(depthtex0, uv).r;
    vec4 world = gbufferModelViewInverse * (gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0));
    vec3 p = world.xyz / world.w + cameraPosition;
    float h = hash2(floor(p.xz * 0.25) + floor(p.y * 0.25) * 0.73);
    return 0.4 + 0.6 * vec3(0.5 + 0.5 * sin(h * 6.283 + 0.0),
                             0.5 + 0.5 * sin(h * 6.283 + 2.1),
                             0.5 + 0.5 * sin(h * 6.283 + 4.2));
#elif LIGHT_COLOR_MODE == 13
    return vec3(CUSTOM_LIGHT_R, CUSTOM_LIGHT_G, CUSTOM_LIGHT_B);
#else
    return vec3(1.0); // native source colors
#endif
}

float luminance(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

vec2 cameraLensUV(vec2 uv) {
    vec2 q = (uv - 0.5) * vec2(viewWidth / viewHeight, 1.0);
    float r2 = dot(q, q);
    return clamp(0.5 + (uv - 0.5) * (1.0 - CAMERA_LENS * r2), vec2(0.001), vec2(0.999));
}

vec3 cameraFilmFinish(vec3 color, vec2 uv) {
    float frame = floor(frameTimeCounter * 24.0);
    vec2 pixel = floor(uv * vec2(viewWidth, viewHeight));
    float grain = hash2(pixel + vec2(frame * 17.0, frame * 31.0)) - 0.5;
    float amount = CAMERA_GRAIN + float(CAMERA_FILM) * 0.012;
    color += grain * amount * (0.60 + 0.40 * sqrt(max(luminance(color), 0.0)));
#if CAMERA_FILM > 0
    // Subtle exposure pulse and intermittent emulsion dust.
    float pulse = sin(frame * 1.37) * (CAMERA_FILM == 2 ? 0.016 : 0.006);
    color *= 1.0 + pulse;
    float speck = hash2(floor(pixel / 2.0) + vec2(frame * 4.0, frame * 9.0));
    float dust = step(CAMERA_FILM == 2 ? 0.99955 : 0.99985, speck);
    color *= 1.0 - dust * (CAMERA_FILM == 2 ? 0.42 : 0.22);
#if CAMERA_FILM == 2
    float scratchX = hash2(vec2(floor(frame / 11.0), 35.0));
    float scratch = 1.0 - smoothstep(0.0, 1.4, abs(uv.x * viewWidth - scratchX * viewWidth));
    color += vec3(0.025, 0.020, 0.012) * scratch * step(0.83, hash2(vec2(floor(frame / 11.0), 12.0)));
#endif
#endif
    return color;
}

#if VHS_MODE > 0
vec2 tapeUV(vec2 uv) {
    float line = floor(uv.y * viewHeight * 0.5);
    float noise = hash2(vec2(line, floor(frameTimeCounter * 24.0)));
    float wobble = sin(uv.y * viewHeight * 0.16 + frameTimeCounter * 11.0) * 0.00028;
    float tracking = exp(-abs(uv.y - fract(frameTimeCounter * 0.115)) * 115.0);
    float offset = wobble + (noise - 0.5) * 0.0010 + tracking * 0.0028;
    return clamp(uv + vec2(offset, 0.0), vec2(0.001), vec2(0.999));
}

vec3 tapeFinish(vec3 color, vec2 screenUV, vec2 imageUV) {
    float tracking = exp(-abs(screenUV.y - fract(frameTimeCounter * 0.115)) * 115.0);
    vec2 bleed = vec2((1.3 + tracking * 2.6) / viewWidth, 0.0);
    vec3 left = texture(colortex0, clamp(imageUV - bleed, vec2(0.001), vec2(0.999))).rgb;
    vec3 right = texture(colortex0, clamp(imageUV + bleed, vec2(0.001), vec2(0.999))).rgb;
    color.r = mix(color.r, left.r, 0.27);
    color.b = mix(color.b, right.b, 0.32);
    color = mix(vec3(luminance(color)), color, 0.77);

    float scanline = sin(screenUV.y * viewHeight * 3.14159265) * 0.034;
    float grain = hash2(floor(screenUV * vec2(viewWidth, viewHeight)) +
                        vec2(floor(frameTimeCounter * 24.0) * 17.0, 0.0));
    float dropout = step(0.9985, hash2(vec2(floor(screenUV.y * viewHeight),
                                            floor(frameTimeCounter * 18.0))));
    color = color * (0.965 + scanline - tracking * 0.12 - dropout * 0.18)
                  + (grain - 0.5) * 0.065;
    float edge = length((screenUV - 0.5) * vec2(viewWidth / viewHeight, 1.0));
    color *= 1.0 - smoothstep(0.30, 1.12, edge) * 0.18;
    return clamp(color, 0.0, 1.0);
}
#endif

#if BLOOM > 0
vec3 brightSample(vec2 uv) {
    vec2 sampleUV=clamp(uv,vec2(0.001),vec2(0.999));
    vec3 c=texture(colortex0,sampleUV).rgb;
    vec3 emission=texture(colortex1,sampleUV).rgb;
    float peak=max(max(c.r,c.g),c.b);
    float isWorld=1.0-step(0.99999,sceneDepth(sampleUV));
    return max(emission*0.72,c*smoothstep(0.97,1.15,peak)*0.12)*isWorld;
}
#endif


// --- Water exit drips + low health blood ---



float dripHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

vec3 applyWaterDrips(vec3 color, vec2 uv, float wet) {
    if (wet < 0.01) return color;
    float elapsed = (1.0 - wet) * 2.8;
    vec2 pixel = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    // Each drop has its own speed, path, short wake, and tiny lens highlight.
    for (int i = 0; i < 11; ++i) {
        float seed = float(i) * 17.3 + 3.1;
        float originX = 0.035 + 0.93 * dripHash(vec2(seed, 1.7));
        float speed = 0.26 + 0.31 * dripHash(vec2(seed, 2.3));
        float yHead = 1.13 + dripHash(vec2(seed, 4.1)) * 0.22 - elapsed * speed;
        float behind = uv.y - yHead; // The wake stays above a downward-moving drop.
        float bend = sin(behind * 16.0 + seed) * min(max(behind, 0.0), 0.16) * 0.025;
        float dx = uv.x - originX - bend;
        if (abs(dx) > 0.035 || behind < -0.035 || behind > 0.27) continue;
        float radius = 0.005 + 0.006 * dripHash(vec2(seed, 5.5));
        vec2 glass = vec2(dx / (radius * 0.80), behind / (radius * 1.28));
        float dropR = length(glass);
        float bulb = 1.0 - smoothstep(0.65, 1.10, dropR);
        float wake = smoothstep(0.0, 0.025, behind) *
                     (1.0 - smoothstep(0.10, 0.25, behind)) *
                     (1.0 - smoothstep(radius * 0.30, radius * 0.85, abs(dx)));
        float coverage = clamp(bulb * 0.70 + wake * 0.42, 0.0, 1.0) * wet;
        if (coverage < 0.003) continue;
        vec2 normal = normalize(vec2(glass.x * 0.9, glass.y * 0.7) + vec2(0.001));
        vec2 refractedUV = clamp(uv + normal * pixel * (3.2 * bulb + 1.3 * wake),
                                 vec2(0.001), vec2(0.999));
        vec3 refracted = texture(colortex0, refractedUV).rgb;
        color = mix(color, refracted * 0.91, coverage * 0.69);
        float rim = exp(-pow((dropR - 0.80) * 7.0, 2.0));
        float lightSide = max(dot(normal, normalize(vec2(-0.55, 0.84))), 0.0);
        color += vec3(0.84, 0.92, 1.0) * rim * lightSide * bulb * wet * 0.12;
    }
    // A fast, uneven splash sheet crosses the top of the lens on surfacing.
    float sheetY = 0.94 - 0.025 * sin(uv.x * 31.0) - 0.018 * sin(uv.x * 83.0 + 1.8);
    float sheet = smoothstep(sheetY - 0.018, sheetY + 0.020, uv.y) *
                  exp(-elapsed * 6.0);
    vec3 shifted = texture(colortex0, clamp(uv + vec2(0.0, 3.0 * pixel.y),
                                           vec2(0.001), vec2(0.999))).rgb;
    color = mix(color, shifted * 0.92 + vec3(0.028), sheet * 0.22);
    return color;
}

vec3 applyBloodOverlay(vec3 color, vec2 uv, float health) {
#if BLOOD_EFFECT == 0
    return color;
#else
    if (health < 0.0 || health >= 0.35) return color;
    float severity = 1.0 - smoothstep(0.06, 0.35, health);
    float critical = 1.0 - smoothstep(0.06, 0.22, health);
    float aspect = viewWidth / max(viewHeight, 1.0);
    vec2 center = (uv - 0.5) * vec2(aspect, 1.0);
    float angle = atan(center.y, center.x);
    float irregular = 0.023 * sin(angle * 7.0 + 1.6) +
                      0.013 * sin(angle * 17.0 - 0.8);
    float rim = smoothstep(0.40 + irregular, 0.91, length(center));
    float pulse = 0.89 + 0.11 * sin(frameTimeCounter * (2.8 + severity * 1.6));
    float amount = rim * severity * pulse * (BLOOD_EFFECT == 2 ? 0.59 : 0.33);
    vec3 edgeTint = color * vec3(0.72, 0.40, 0.43) + vec3(0.052, 0.002, 0.003);
    color = mix(color, edgeTint, amount);

    // Thin translucent stains remain at the frame edge instead of coating
    // the view. Each trickle has a different width, bend and length.
    for (int i = 0; i < 5; ++i) {
        float seed = float(i) * 11.7 + 2.0;
        float x = 0.08 + 0.84 * dripHash(vec2(seed, 4.2));
        float lengthY = 0.055 + 0.095 * dripHash(vec2(seed, 9.4));
        float width = 0.002 + 0.0035 * dripHash(vec2(seed, 7.3));
        float travel = clamp((1.0 - uv.y) / lengthY, 0.0, 1.0);
        float dx = abs(uv.x - x - sin(travel * 2.6 + seed) * travel * 0.004);
        float taper = (1.0 - smoothstep(0.64, 1.0, travel)) *
                      smoothstep(0.0, 0.08, travel);
        float stain = (1.0 - smoothstep(width, width * 2.1, dx)) * taper *
                      critical * (BLOOD_EFFECT == 2 ? 0.40 : 0.23);
        color = mix(color, color * vec3(0.52, 0.16, 0.18) + vec3(0.04, 0.001, 0.002), stain);
    }
    return color;
#endif
}

void main() {
    vec2 imageUV = cameraLensUV((texcoord-0.5)/CAMERA_ZOOM+0.5);
#if VHS_MODE > 0
    imageUV = tapeUV(imageUV);
#endif
    vec3 color = texture(colortex0, imageUV).rgb;
    float depth = sceneDepth(imageUV);
    if (CAMERA_SHARPNESS>0.0 || CAMERA_FOCUS>0.0) {
    vec2 cameraPixel=1.0/vec2(viewWidth,viewHeight);
    vec3 neighbors=vec3(0.0); float weight=0.0;
    float centerDistance=sceneDistance(imageUV);
    for (int tap=0; tap<4; ++tap) {
        vec2 direction=tap==0?vec2(1,0):tap==1?vec2(-1,0):tap==2?vec2(0,1):vec2(0,-1);
        vec2 sampleUV=clamp(imageUV+direction*cameraPixel,vec2(0.001),vec2(0.999));
        float compatible=1.0-smoothstep(0.10,0.5,abs(sceneDistance(sampleUV)-centerDistance));
        neighbors+=texture(colortex0,sampleUV).rgb*compatible; weight+=compatible;
    }
    vec3 average=weight>0.0?neighbors/weight:color;
    if (CAMERA_SHARPNESS>0.0) color=max(color+(color-average)*CAMERA_SHARPNESS,vec3(0.0));
    if (CAMERA_FOCUS>0.0 && depth<0.99999) {
        float blur=clamp(abs(centerDistance-CAMERA_FOCUS)/max(CAMERA_FOCUS,1.0),0.0,1.0);
        color=mix(color,average,blur*0.8);
    }

    }
    float storm = weatherStrength();
    bool nether = hasCeiling && !hasSkylight;
    bool openSky = hasSkylight && isEyeInWater == 0 && depth > 0.99999;
    if (openSky) {
        color = mix(color, color * vec3(0.52, 0.58, 0.67), storm * 0.68);
#if OVERWORLD_LOOK == 1
        vec3 skyRay = normalize((gbufferModelViewInverse * vec4(viewRay(imageUV), 0.0)).xyz);
        vec3 sunWorld = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
        float clearDay = smoothstep(0.08, 0.32, sunWorld.y) * (1.0 - storm);
        vec3 daylightBlue = mix(vec3(0.27, 0.52, 0.72), vec3(0.065, 0.20, 0.43),
            smoothstep(-0.02, 0.84, skyRay.y));
        color = mix(color, daylightBlue, clearDay * 0.72);
#endif
        color += sunDisc(imageUV, storm);

    }
    // Clear-weather aerial perspective, gated by skylight so interiors stay dark.
    if (hasSkylight && !hasCeiling && isEyeInWater==0 && depth<0.99999) {
        float skyAccess=texture(colortex3,imageUV).g;
        float distanceAir=max(sceneDistance(imageUV)-24.0,0.0);
        float fog=(1.0-exp(-distanceAir*(0.00075+storm*0.00070)))*smoothstep(0.08,0.70,skyAccess);
        vec3 sunWorld=normalize((gbufferModelViewInverse*vec4(sunPosition,0.0)).xyz);
        float day=smoothstep(-0.08,0.12,sunWorld.y);
        vec3 airColor=mix(vec3(0.018,0.027,0.050),mix(vec3(0.48,0.64,0.80),vec3(0.56,0.60,0.65),storm),day);
        color=mix(color,airColor,clamp(fog,0.0,0.72));
    }
    if (hasSkylight && isEyeInWater==0) {
        vec4 cloud=stableClouds(imageUV);
        color=color*(1.0-cloud.a)+cloud.rgb;
    }
#if GODRAY_SAMPLES > 0
    if (hasSkylight && isEyeInWater == 0) color += sunShafts(imageUV, storm);
#endif
#if STORM_FOG > 0
    if (hasSkylight && isEyeInWater == 0 && storm > 0.01) {
        float desert = (1.0 - smoothstep(0.02, 0.12, rainfall)) * smoothstep(1.25, 1.55, temperature);
        float snow = biome_precipitation == 2 ? 1.0 : 0.0;
        float weatherFog = max(desert, snow);
        if (weatherFog > 0.0) {
            float distanceFog = sceneDistance(imageUV);
            float intensity = storm * float(STORM_FOG) * weatherFog;
            float fog = (1.0 - exp(-distanceFog * 0.018 * intensity));
            float windNoise = hash2(floor(imageUV * vec2(viewWidth, viewHeight) * 0.1 +
                                        vec2(frameTimeCounter * 7.0, frameTimeCounter * 1.8)));
            fog *= 0.92 + 0.08 * windNoise;
            vec3 stormColor = mix(vec3(0.69, 0.54, 0.29), vec3(0.78, 0.84, 0.90), snow);
            color = mix(color, stormColor, clamp(fog, 0.0, 0.94));
        }
    }
#endif

#if NETHER_HEAT > 0
    if (nether && isEyeInWater == 0) {
        float distanceFog = sceneDistance(imageUV);
        vec2 moving = imageUV * vec2(viewWidth / viewHeight, 1.0) * 8.0 +
                      frameTimeCounter * vec2(0.07, -0.10);
        float vapor = steamNoise(moving) * 0.7 + steamNoise(moving * 2.1 + 7.0) * 0.3;
        float heat = float(NETHER_HEAT);
        float haze = (1.0 - exp(-distanceFog * (0.010 + 0.006 * heat))) *
                     (0.64 + vapor * 0.45);
        vec3 hotFog = mix(fogColor, vec3(0.43, 0.19, 0.10), 0.65);
        color = mix(color, hotFog, clamp(haze, 0.0, 0.88));
        float steam = smoothstep(0.51, 0.78, vapor) * (0.035 + 0.035 * heat);
        color = mix(color, vec3(0.72, 0.53, 0.43), steam);
        color *= vec3(1.05, 0.98, 0.89);
    }
#endif

#if BLOOM > 0
    vec2 pixel = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    vec3 glow = brightSample(imageUV) * 0.16;
    vec2 nearRadius = pixel * 4.0 * (viewHeight/1080.0);
    vec2 farRadius = pixel * 11.0 * (viewHeight/1080.0);
    glow += brightSample(imageUV + vec2( nearRadius.x, 0.0)) * 0.11;
    glow += brightSample(imageUV + vec2(-nearRadius.x, 0.0)) * 0.11;
    glow += brightSample(imageUV + vec2(0.0,  nearRadius.y)) * 0.11;
    glow += brightSample(imageUV + vec2(0.0, -nearRadius.y)) * 0.11;
    glow += brightSample(imageUV + vec2( farRadius.x,  farRadius.y)) * 0.0675;
    glow += brightSample(imageUV + vec2(-farRadius.x,  farRadius.y)) * 0.0675;
    glow += brightSample(imageUV + vec2( farRadius.x, -farRadius.y)) * 0.0675;
    glow += brightSample(imageUV + vec2(-farRadius.x, -farRadius.y)) * 0.0675;
    glow += brightSample(imageUV + vec2( farRadius.x, 0.0)) * 0.045;
    glow += brightSample(imageUV + vec2(-farRadius.x, 0.0)) * 0.045;
    glow += brightSample(imageUV + vec2(0.0,  farRadius.y)) * 0.045;
    glow += brightSample(imageUV + vec2(0.0, -farRadius.y)) * 0.045;
#if NETHER_HEAT > 0
    if (nether) {
        vec2 heatRadius = pixel * 24.0;
        glow += brightSample(imageUV + vec2( heatRadius.x, 0.0)) * 0.065;
        glow += brightSample(imageUV + vec2(-heatRadius.x, 0.0)) * 0.065;
        glow += brightSample(imageUV + vec2(0.0,  heatRadius.y)) * 0.065;
        glow += brightSample(imageUV + vec2(0.0, -heatRadius.y)) * 0.065;
    }
#endif
#if BLOOM == 2
    glow *= 1.6;
#endif
    // Screen blend keeps the output in display range and avoids white clipping.
    float glowStrength = BLOOM_STRENGTH;

    // Soft-cap bloom so campfires/torches don't bleach the whole frame
    color += max(1.0 - color, vec3(0.0)) * clamp(glow * glowStrength, 0.0, 0.55);
#endif

    float luma = luminance(color);
    // Cool shadows, warm highlights; neutral midtones retain texture colors.
    // Multiplicative grading preserves black instead of adding a violet glow.
    vec3 grade=mix(vec3(0.96,1.0,1.055),vec3(1.025,1.0,0.965),smoothstep(0.10,0.85,luma));
    color*=mix(vec3(1.0),grade,COLOR_STRENGTH);

    color = (color - 0.5) * CONTRAST + 0.5;
    color = mix(vec3(luminance(color)), color, SATURATION);
#if OVERWORLD_LOOK == 1
    // Apply the reference's fresh green daylight without raising caves at night.
    float sunlight = smoothstep(0.10, 0.35,
        normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz).y) *
        (1.0 - storm * 0.7);
    if (depth < 0.99999) {
        color *= mix(vec3(1.0), vec3(1.015, 1.055, 0.99), sunlight);
    }
#endif

    vec2 centered = (imageUV - 0.5) * vec2(viewWidth / viewHeight, 1.0);
    float edge = smoothstep(0.16, 0.75, dot(centered, centered));
    color *= 1.0 - VIGNETTE * edge;

    if (CAMERA_CHROMATIC > 0.0) {
    // Restrict channel separation to geometry. The End sky is generated in
    // this pass, so reading colortex0 at its neighboring sky pixels is invalid.
    if (depth < 0.99999) {
        vec2 displacement = (imageUV - 0.5) *
            (CAMERA_CHROMATIC * 2.0 / max(viewWidth, viewHeight));
        vec2 redUV = clamp(imageUV + displacement, vec2(0.001), vec2(0.999));
        vec2 blueUV = clamp(imageUV - displacement, vec2(0.001), vec2(0.999));
        if (sceneDepth(redUV) < 0.99999) color.r +=
            (texture(colortex0, redUV).r - texture(colortex0, imageUV).r) * 0.75;
        if (sceneDepth(blueUV) < 0.99999) color.b +=
            (texture(colortex0, blueUV).b - texture(colortex0, imageUV).b) * 0.75;
    }
    }
    if (CAMERA_GRAIN > 0.0 || CAMERA_FILM > 0) color = cameraFilmFinish(color, texcoord);

#if VHS_MODE > 0
    color = tapeFinish(color, texcoord, imageUV);
#if VHS_MODE == 1
    // Crop the wide frame to a centered 4:3 picture with opaque side bars.
    float halfWidth = min(0.5, 2.0 / (3.0 * (viewWidth / viewHeight)));
    if (abs(texcoord.x - 0.5) >= halfWidth) color = vec3(0.0);
#endif
#endif
#if CAMERA_BARS > 0
    float barHeight = max(0.0, 0.5 - viewWidth / (2.0 * viewHeight * (CAMERA_BARS == 1 ? 1.85 : 2.39)));
    if (texcoord.y < barHeight || texcoord.y > 1.0 - barHeight) color = vec3(0.0);
#endif
    // Postprocessing must not lift a completely unlit surface above black.
    if (depth < 0.99999 && !nether &&
        dot(texture(colortex0, imageUV).rgb, vec3(0.2126, 0.7152, 0.0722)) < 0.0001)
        color = vec3(0.0);

    // The negative state means submerged. Flip to a positive timer on exit.
    // Keep the effect off while underwater, then fade over about 2.8 seconds.
    if (texcoord.x < 1.5 / viewWidth && texcoord.y < 1.5 / viewHeight) {
        if (isEyeInWater == 1) fxLights.screenWet = -1.0;
        else if (fxLights.screenWet < -0.5) fxLights.screenWet = 1.0;
        else fxLights.screenWet = max(fxLights.screenWet - clamp(frameTime, 0.0, 0.1) / 2.8, 0.0);
    }
    float wetAmt = isEyeInWater == 0 ? clamp(fxLights.screenWet, 0.0, 1.0) : 0.0;
    color = applyWaterDrips(color, texcoord, wetAmt);
    color = applyBloodOverlay(color, texcoord, currentPlayerHealth);
    color = pow(max(color*exp2(CAMERA_EXPOSURE),vec3(0.0)),vec3(1.0/CAMERA_GAMMA));
    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
