// Original implementation: directional light, sky fill and filtered depth shadows.
// Inputs and outputs here are linear radiance; material textures remain display RGB.
#define SUN_SHADOWS 1 // [0 1]
#define SHADOW_QUALITY 1 // [0 1 2] 512 / 1024 / 2048
#define SUNLIGHT_STRENGTH 1.0 // [0.5 0.75 1.0 1.25 1.5]
#define SKYLIGHT_STRENGTH 1.0 // [0.5 0.75 1.0 1.25 1.5]
uniform bool hasSkylight;
uniform bool hasCeiling;
uniform float sunAngle;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform float rainStrength;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform sampler2D shadowtex0;

vec3 mubbleSafeDirection(vec3 direction) {
    return direction * inversesqrt(max(dot(direction, direction), 0.000001));
}

float mubbleSunVisibility(vec3 relativePosition, vec3 normal, vec3 lightDirection) {
#if SUN_SHADOWS == 0
    return 1.0;
#else
    // Bias in world units follows surface slope, rather than screen depth.
    float slope = 1.0 - max(dot(normal, lightDirection), 0.0);
    vec3 biased = relativePosition + normal * (0.025 + slope * 0.035);
    vec4 clip = shadowProjection * shadowModelView * vec4(biased, 1.0);
    if (abs(clip.w) < 0.00001) return 1.0;
    vec3 projected = clip.xyz / clip.w * 0.5 + 0.5;
    if (any(lessThanEqual(projected, vec3(0.0))) ||
        any(greaterThanEqual(projected, vec3(1.0)))) return 1.0;
    vec2 pixel = 1.0 / vec2(textureSize(shadowtex0, 0));
    float visibility = 0.0;
#if SHADOW_QUALITY == 0
    visibility = step(projected.z - 0.00004, texture(shadowtex0, projected.xy).r);
#else
    // Separable tent kernel; fixed sampling avoids swimming noise on still frames.
    for (int y = -1; y <= 1; ++y) {
        for (int x = -1; x <= 1; ++x) {
            float weight = float((x == 0 ? 2 : 1) * (y == 0 ? 2 : 1));
            vec2 uv = clamp(projected.xy + vec2(x, y) * pixel * 1.25, pixel, 1.0 - pixel);
            visibility += weight * step(projected.z - 0.00004, texture(shadowtex0, uv).r);
        }
    }
    visibility *= 0.0625;
#endif
    // Outside the shadow-map coverage, transition to skylight-gated direct light.
    float edge = min(min(projected.x, projected.y), min(1.0-projected.x, 1.0-projected.y));
    return mix(1.0, visibility, smoothstep(0.0, 0.035, edge));
#endif
}

vec3 mubbleBlockIrradiance(float level) {
    return vec3(1.0, 0.58, 0.27) * pow(clamp(level, 0.0, 1.0), 2.0) * 0.85;
}

vec3 mubbleDaylight(vec3 relativePosition, vec3 normal, float skyLevel, bool hand) {
    float sky = pow(clamp(skyLevel, 0.0, 1.0), 2.0);
    float day = smoothstep(-0.04, 0.15, sin(sunAngle * 6.2831853));
    vec3 sun = mubbleSafeDirection(mat3(gbufferModelViewInverse) * sunPosition);
    vec3 light = mubbleSafeDirection(mat3(gbufferModelViewInverse) * shadowLightPosition);
    // Useful fallback for shader engines providing sunPosition only.
    if (dot(light, light) < 0.5) light = day > 0.5 ? sun : -sun;
    float facing = max(dot(normal, light), 0.0);
    float visible = hand ? 1.0 : mubbleSunVisibility(relativePosition, normal, light);
    float rain = clamp(rainStrength, 0.0, 1.0);
    vec3 sunColor = mix(vec3(1.0, 0.54, 0.28), vec3(1.0, 0.92, 0.78),
                       smoothstep(0.02, 0.42, max(sun.y, 0.0)));
    vec3 keyColor = mix(vec3(0.34, 0.48, 0.78) * 0.055, sunColor * 1.70, day);
    keyColor *= (1.0 - rain * 0.80) * SUNLIGHT_STRENGTH;
    // Upward-facing sky fill and a small ground bounce, both gated by skylight.
    // No constant brightness floor: sealed, unlit caves stay black.
    float skyFacing = 0.48 + 0.52 * max(normal.y, 0.0);
    vec3 skyColor = mix(vec3(0.24, 0.36, 0.60), vec3(0.34, 0.37, 0.42), rain);
    vec3 fill = skyColor * skyFacing * mix(0.020, 0.72, day);
    vec3 bounce = vec3(0.06, 0.052, 0.034) * (1.0 - max(normal.y, 0.0)) * day;
    return sky * ((fill + bounce) * SKYLIGHT_STRENGTH + keyColor * facing * visible);
}

vec3 mubbleDisplayRadiance(vec3 radiance) {
    // Smooth highlight shoulder preserves bright texture detail instead of clipping.
    vec3 x = max(radiance, vec3(0.0));
    vec3 mapped = (x * (2.51*x + 0.03)) / (x * (2.43*x + 0.59) + 0.14);
    return pow(clamp(mapped, 0.0, 1.0), vec3(1.0 / 2.2));
}
