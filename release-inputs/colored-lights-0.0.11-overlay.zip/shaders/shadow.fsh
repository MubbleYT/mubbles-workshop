#version 430 compatibility
uniform sampler2D gtexture;
in vec2 shadowUV;
flat in int shadowWater;
void main() {
    if (shadowWater==1 || texture(gtexture,shadowUV).a<0.1) discard;
    gl_FragData[0]=vec4(1.0);
}
